<?php
require_once 'includes/auth.php';
checkLogin();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exporta Fácil – Gerenciador de Remessas</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/auth.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            background-color: #0a0a0c;
            color: #e2e8f0;
            display: block;
            padding: 1.5rem;
            min-height: 100vh;
            font-family: 'Poppins', sans-serif;
            overflow-x: auto;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .header h1 {
            font-size: 1.8rem;
            font-weight: 700;
            background: linear-gradient(135deg, #6366f1 0%, #a855f7 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .nav-links {
            display: flex;
            gap: 1rem;
            align-items: center;
        }
        .btn {
            padding: 8px 16px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
            cursor: pointer;
            border: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }
        .btn-primary {
            background: #6366f1;
            color: white;
        }
        .btn-primary:hover {
            background: #4f46e5;
            transform: translateY(-2px);
        }
        .btn-secondary {
            background: rgba(255, 255, 255, 0.05);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.1);
        }
        
        /* List View Layout */
        .board {
            display: flex;
            flex-direction: column;
            gap: 2rem;
            padding-bottom: 2rem;
        }
        .status-section {
            background: #111116;
            border-radius: 12px;
            padding: 1.5rem;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }
        .status-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }
        .status-header h3 {
            font-size: 1rem;
            font-weight: 600;
            color: #6366f1;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .status-header .count {
            background: rgba(99, 102, 241, 0.1);
            color: #6366f1;
            padding: 2px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        .shipment-list {
            display: flex;
            flex-direction: column;
            gap: 0.8rem;
        }
        
        .shipment-row {
            background: #1e1e26;
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 12px;
            padding: 1.25rem;
            display: grid;
            grid-template-columns: 80px 1.5fr 1fr 1fr 1.2fr 100px 200px; /* Refined columns for better fit */
            align-items: center;
            gap: 1.5rem;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            margin-bottom: 0.5rem;
        }
        .shipment-row:hover {
            border-color: #6366f1;
            background: #252530;
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3);
        }
        .shipment-row .col-id { 
            color: #6366f1; 
            font-weight: 700; 
            font-size: 0.95rem;
            background: rgba(99, 102, 241, 0.1);
            padding: 4px 8px;
            border-radius: 6px;
            width: fit-content;
        }
        .shipment-row .col-main { color: #fff; font-weight: 600; font-size: 1rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .shipment-row .col-info { color: #94a3b8; font-size: 0.85rem; display: flex; align-items: center; gap: 8px; }
        .shipment-row .col-info i { color: #6366f1; font-size: 1.1rem; }
        .shipment-row .col-price { color: #22c55e; font-weight: 700; font-size: 0.95rem; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
        .shipment-row .col-weight { color: #94a3b8; font-weight: 500; font-size: 0.85rem; }
        .shipment-row .col-dims { color: #94a3b8; font-size: 0.85rem; white-space: nowrap; }
        .card-id {
            font-size: 0.85rem;
            color: #6366f1;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: rgba(99, 102, 241, 0.1);
            display: inline-block;
            padding: 2px 8px;
            border-radius: 4px;
        }
        .card-title {
            font-size: 1rem;
            font-weight: 600;
            color: #fff;
            margin-bottom: 0.5rem;
        }
        .card-details {
            font-size: 0.85rem;
            color: #94a3b8;
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        .card-details span {
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .card-details i {
            color: #6366f1;
            font-size: 1rem;
        }
        .card-footer {
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .payment-badge {
            font-size: 0.75rem;
            padding: 2px 8px;
            border-radius: 6px;
            font-weight: 500;
        }
        .pb-aguardando { background: rgba(234, 179, 8, 0.1); color: #eab308; border: 1px solid rgba(234, 179, 8, 0.2); }
        .pb-pago-confirmacao { background: rgba(59, 130, 246, 0.1); color: #3b82f6; border: 1px solid rgba(59, 130, 246, 0.2); }
        .pb-pago-confirmado { background: rgba(34, 197, 94, 0.1); color: #22c55e; border: 1px solid rgba(34, 197, 94, 0.2); }
        .pb-faturado { background: rgba(168, 85, 247, 0.1); color: #a855f7; border: 1px solid rgba(168, 85, 247, 0.2); }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.82);
            backdrop-filter: blur(8px);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            background: #111116;
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 2rem;
            width: 95%;
            max-width: 900px;
            max-height: 90vh;
            overflow-y: auto;
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }
        .close-modal {
            background: none;
            border: none;
            color: #94a3b8;
            font-size: 1.8rem;
            cursor: pointer;
        }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 1.5rem;
        }
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .form-group.full-width { grid-column: span 3; }
        .form-group.two-thirds { grid-column: span 2; }
        .form-group label {
            font-size: 0.85rem;
            color: #94a3b8;
            font-weight: 500;
        }
        .form-group input, .form-group select, .form-group textarea {
            background: #0a0a0c;
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 10px 12px;
            color: #fff;
            outline: none;
            font-size: 0.9rem;
        }
        .form-group input:focus, .form-group select:focus {
            border-color: #6366f1;
            box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.2);
        }
        .btn-group {
            grid-column: span 3;
            display: flex;
            justify-content: flex-end;
            gap: 1rem;
            margin-top: 1rem;
        }
        .photo-preview {
            width: 100%;
            height: 150px;
            border: 2px dashed rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 8px;
            overflow: hidden;
            background-size: contain;
            background-repeat: no-repeat;
            background-position: center;
        }
        
        /* Wizard Specific */
        .step-indicator {
            font-size: 0.8rem;
            color: #94a3b8;
            padding: 4px 12px;
            border-radius: 20px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: all 0.3s;
            cursor: pointer;
        }
        .step-indicator:hover { background: rgba(255, 255, 255, 0.1); }
        .step-indicator.active {
            background: rgba(99, 102, 241, 0.2);
            color: #6366f1;
            border-color: rgba(99, 102, 241, 0.5);
            font-weight: 600;
        }
        
        /* Price Chips in Shipments */
        .shipment-price-suggestions { display: flex; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 1rem; }
        .price-chip { 
            background: rgba(255,255,255,0.05); 
            border: 1px solid rgba(255,255,255,0.1); 
            padding: 4px 10px; 
            border-radius: 6px; 
            font-size: 0.8rem; 
            cursor: pointer; 
            transition: 0.3s;
            color: #94a3b8;
        }
        .price-chip:hover { background: #6366f1; color: #fff; border-color: #6366f1; }
        /* Observations & Files */
        .modal-tabs {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            padding-bottom: 0.5rem;
        }
        .tab-btn {
            background: none;
            border: none;
            color: #94a3b8;
            padding: 8px 16px;
            cursor: pointer;
            font-size: 0.9rem;
            border-bottom: 2px solid transparent;
            transition: 0.3s;
        }
        .tab-btn.active {
            color: #6366f1;
            border-bottom-color: #6366f1;
        }
        .notes-list {
            display: flex;
            flex-direction: column;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        .note-item {
            background: rgba(255,255,255,0.02);
            border: 1px solid rgba(255,255,255,0.05);
            border-radius: 10px;
            padding: 1rem;
        }
        .note-date {
            font-size: 0.75rem;
            color: #6366f1;
            margin-bottom: 4px;
            font-weight: 600;
        }
        .note-text { font-size: 0.9rem; color: #e2e8f0; }

        .files-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 1rem;
        }
        .file-card {
            background: #1e1e26;
            border: 1px solid rgba(255,255,255,0.05);
            border-radius: 10px;
            padding: 10px;
            text-align: center;
            transition: 0.3s;
        }
        .file-card:hover { border-color: #6366f1; }
        .file-icon { font-size: 2rem; color: #6366f1; margin-bottom: 8px; }
        .file-name { font-size: 0.75rem; color: #94a3b8; word-break: break-all; }
        .file-actions { margin-top: 8px; display: flex; gap: 5px; justify-content: center; }
        .file-btn { padding: 4px; border-radius: 4px; cursor: pointer; background: rgba(255,255,255,0.05); color: #fff; }
        .file-btn:hover { background: #6366f1; }
        .linked-quote-info strong { color: #6366f1; }
        .wizard-step {
            animation: fadeIn 0.3s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Chat Styles Phase 8 */
        .notes-list {
            display: flex;
            flex-direction: column;
            gap: 1rem;
            max-height: 400px;
            overflow-y: auto;
            padding-right: 10px;
            margin-bottom: 1.5rem;
        }
        .chat-bubble {
            max-width: 85%;
            padding: 12px 16px;
            border-radius: 18px;
            position: relative;
            font-size: 0.9rem;
            line-height: 1.4;
            background: #1e1e26;
            border: 1px solid rgba(255,255,255,0.05);
            align-self: flex-start;
        }
        .chat-bubble.mine {
            align-self: flex-end;
            background: rgba(99, 102, 241, 0.15);
            border-color: rgba(99, 102, 241, 0.2);
        }
        .chat-author {
            font-size: 0.75rem;
            font-weight: 700;
            color: #6366f1;
            margin-bottom: 4px;
            display: block;
        }
        .chat-time {
            font-size: 0.7rem;
            color: #64748b;
            margin-top: 6px;
            text-align: right;
            display: block;
        }
        .chat-file {
            margin-top: 8px;
            padding: 8px;
            background: rgba(0,0,0,0.2);
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            color: #34d399;
            font-size: 0.8rem;
        }
        .chat-file i { font-size: 1.2rem; }
    </style>
</head>
<body>
    <div class="header">
        <div style="display: flex; align-items: center; gap: 1rem;">
            <a href="index.php" style="color: #94a3b8; text-decoration: none; font-size: 1.5rem;"><i class='bx bx-arrow-back'></i></a>
            <h1>Gerenciador de Remessas</h1>
        </div>
        <div class="nav-links">
            <a href="shipment_label.php?tab=history" class="btn btn-secondary" style="background: rgba(34, 197, 94, 0.1); color: #22c55e; border-color: rgba(34, 197, 94, 0.2);">
                <i class='bx bx-history'></i> Histórico de Envios
            </a>
            <button class="btn btn-primary" onclick="openShipmentModal()">
                <i class='bx bx-plus'></i> Adicionar Remessa
            </button>
            <a href="customers.php" class="btn btn-secondary"><i class='bx bx-user-plus'></i> Clientes</a>
        </div>
    </div>

    <div class="board" id="mainBoard">
        <?php
$statuses = ['Aguardando', 'Juntando mercadorias', 'Aguardando Dados', 'Preparar Envio', 'Aguardando Coleta', 'Rastreio', 'Entregues'];
foreach ($statuses as $s):
    $safeId = str_replace(' ', '-', $s);
?>
        <div class="status-section" id="section-<?php echo $safeId; ?>" data-status="<?php echo $s; ?>">
            <div class="status-header">
                <h3><i class='bx bx-circle'></i> <?php echo $s; ?></h3>
                <span class="count" id="count-<?php echo $safeId; ?>">0</span>
            </div>
            <div class="shipment-list" id="container-<?php echo $safeId; ?>">
                <!-- List items will be injected here -->
            </div>
        </div>
        <?php
endforeach; ?>
    </div>


    <!-- Modal Adicionar/Editar Remessa -->
    <div id="shipmentModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <div style="display: flex; flex-direction: column;">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <h2 id="modalTitle" style="margin: 0;">Nova Remessa</h2>
                        <span id="modalIdBadge" style="display: none; background: rgba(99, 102, 241, 0.2); color: #6366f1; padding: 4px 10px; border-radius: 8px; font-weight: 700; font-size: 0.9rem;"></span>
                    </div>
                    <div class="wizard-progress" style="display: flex; gap: 1rem; margin-top: 10px;">
                        <span class="step-indicator active" id="ind-1" onclick="goToStep(1)">1. Clientes</span>
                        <span class="step-indicator" id="ind-2" onclick="goToStep(2)">2. Detalhes</span>
                        <span class="step-indicator" id="ind-3" onclick="goToStep(3)">3. Finalização</span>
                        <span class="step-indicator" id="ind-4" onclick="goToStep(4)">4. Observação</span>
                        <span class="step-indicator" id="ind-5" onclick="goToStep(5)">5. Files</span>
                    </div>
                </div>
                <button class="close-modal" onclick="closeShipmentModal()"><i class='bx bx-x'></i></button>
            </div>
            <form id="shipmentForm" enctype="multipart/form-data">
                <input type="hidden" id="shipmentId" name="id">
                <input type="hidden" id="quote_id_input" name="quote_id">

                <div id="linked-quote-display" class="linked-quote-info" style="display: none;">
                    <i class='bx bx-link'></i>
                    <span>Vinculada à Cotação <strong id="linked-quote-id">#00000</strong></span>
                </div>

                <!-- Passo 1: Clientes -->
                <div class="wizard-step" id="step-1">
                    <div class="form-grid">
                        <div class="form-group two-thirds">
                            <label>Responsável (Nome)</label>
                            <input type="text" id="responsible_name" name="responsible_name" placeholder="Nome do responsável">
                        </div>
                        <div class="form-group">
                            <label>Telefone Responsável</label>
                            <input type="text" id="responsible_phone" name="responsible_phone" placeholder="Ex: (00) 00000-0000">
                        </div>
                        
                        <div class="form-group full-width">
                            <label>Remetente (Salvo no Sistema)</label>
                            <select id="sender_id" name="sender_id" style="width: 100%; box-sizing: border-box; background: #0a0a0c; border: 1px solid rgba(255,255,255,0.1); color: #fff; padding: 10px 12px; border-radius: 8px;">
                                <option value="">Selecione um cliente...</option>
                            </select>
                        </div>
                        
                        <div class="form-group full-width">
                            <label>Destinatário (Salvo no Sistema)</label>
                            <select id="recipient_id" name="recipient_id" style="width: 100%; box-sizing: border-box; background: #0a0a0c; border: 1px solid rgba(255,255,255,0.1); color: #fff; padding: 10px 12px; border-radius: 8px;">
                                <option value="">Selecione um cliente...</option>
                            </select>
                        </div>

                        <div class="form-group two-thirds">
                            <label>Vendedor Responsável</label>
                            <input type="text" id="responsible_salesperson" name="responsible_salesperson" value="<?php echo htmlspecialchars($_SESSION['name'] ?? ''); ?>" readonly style="background: rgba(255,255,255,0.05); color: #94a3b8; cursor: not-allowed;">
                        </div>
                        <div class="form-group">
                            <label>Entregador</label>
                            <input type="text" id="delivery_person" name="delivery_person" placeholder="Nome do entregador">
                        </div>
                    </div>
                </div>

                <!-- Passo 2: Detalhes -->
                <div class="wizard-step" id="step-2" style="display: none;">
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Qtd. de Volumes</label>
                            <input type="number" id="quantity" name="quantity" min="1" placeholder="Ex: 1">
                        </div>
                        <div class="form-group">
                            <label>Dimensões (AxLxC)</label>
                            <input type="text" id="dimensions" name="dimensions" placeholder="Ex: 20x30x40">
                            <small id="dim-hint" style="font-size: 0.7rem; color: var(--muted); display: none;">Para múltiplos volumes, separe por ponto e vírgula (Ex: 20x20x20; 10x10x10)</small>
                        </div>
                        <div class="form-group">
                            <label>Peso Total (Kg)</label>
                            <input type="number" step="0.01" id="weight" name="weight" placeholder="Ex: 2.5">
                        </div>

                        <div class="form-group full-width">
                            <label>Descrição do Conteúdo</label>
                            <textarea id="description" name="description" rows="2" placeholder="O que está sendo enviado?" style="width: 100%; box-sizing: border-box; background: #0a0a0c; border: 1px solid rgba(255,255,255,0.1); color: #fff; padding: 10px 12px; border-radius: 8px;"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label>Valor Declarado (R$)</label>
                            <input type="number" step="0.01" id="declared_value" name="declared_value" placeholder="0.00">
                        </div>
                        
                        <div class="form-group two-thirds">
                            <label>País de Destino</label>
                            <input type="text" id="destination_country" name="destination_country" placeholder="Ex: Estados Unidos" list="countries-list">
                        </div>
                        
                        <div class="form-group full-width" id="quote-prices-section" style="display: none;">
                            <label>Valores da Cotação</label>
                            <div id="shipment-price-picker" class="shipment-price-suggestions"></div>
                        </div>
                        
                        <div class="form-group full-width">
                            <label>Status da Remessa</label>
                            <select id="status" name="status">
                                <option value="Aguardando">Aguardando</option>
                                <option value="Juntando mercadorias">Juntando mercadorias</option>
                                <option value="Aguardando Dados">Aguardando Dados</option>
                                <option value="Preparar Envio">Preparar Envio</option>
                                <option value="Aguardando Coleta">Aguardando Coleta</option>
                                <option value="Rastreio">Rastreio</option>
                                <option value="Entregues">Entregues</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Passo 3: Finalização -->
                <div class="wizard-step" id="step-3" style="display: none;">
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Status de Pagamento</label>
                            <select id="payment_status" name="payment_status">
                                <option value="Aguardando Pagamento">Aguardando Pagamento</option>
                                <option value="Pago, aguardando confirmação">Pago, aguardando confirmação</option>
                                <option value="Pagamento confirmado">Pagamento confirmado</option>
                                <option value="Faturado">Faturado</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Valor do Frete / Recebido (R$)</label>
                            <input type="number" step="0.01" id="freight_value" name="freight_value" placeholder="0.00" style="width: 100%; box-sizing: border-box; background: #0a0a0c; border: 1px solid rgba(255,255,255,0.1); color: #fff; padding: 10px 12px; border-radius: 8px;">
                        </div>
                        <div class="form-group">
                            <label>Tipo de Pagamento</label>
                            <select id="payment_type" name="payment_type">
                                <option value="">Selecione...</option>
                                <option value="PIX">PIX</option>
                                <option value="Credito">Cartão de Crédito</option>
                                <option value="Debito">Cartão de Débito</option>
                                <option value="Boleto">Boleto</option>
                                <option value="Faturado">Faturado</option>
                                <option value="Link">Link de Pagamento</option>
                                <option value="Pagamento internacional">Pagamento Internacional</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Foto da Remessa</label>
                            <input type="file" id="shipment_photo" name="shipment_photo" accept="image/*">
                        </div>
                        <div class="form-group full-width">
                            <div id="photoPreview" class="photo-preview">
                                <i class='bx bx-image-alt' style="font-size: 2rem; color: rgba(255,255,255,0.1);"></i>
                            </div>
                        </div>
                    </div>
                </div>

                 <!-- Seção de Observações (Multi-notas) -->
                 <div id="tab-notes" class="tab-content" style="display: none;">
                    <div class="notes-list" id="shipment-notes-container">
                        <!-- Notes will be injected here -->
                    </div>
                    <div class="form-group">
                        <label>Nova Observação</label>
                        <textarea id="new_note_text" rows="3" placeholder="Digite uma nova observação..."></textarea>
                        <div style="margin-top: 10px; display: flex; gap: 10px; align-items: center;">
                            <input type="file" id="note_file" accept="image/*,.pdf" style="display: none;">
                            <button type="button" class="btn btn-secondary" onclick="$('#note_file').click()"><i class='bx bx-paperclip'></i> Anexar Foto/PDF</button>
                            <button type="button" class="btn btn-primary" onclick="addNote()"><i class='bx bx-plus'></i> Adicionar Nota</button>
                        </div>
                        <div id="note-file-preview" style="margin-top: 10px; font-size: 0.8rem; color: #34d399; display: none;">Arquivo selecionado.</div>
                    </div>
                 </div>

                 <!-- Seção de Arquivos -->
                 <div id="tab-files" class="tab-content" style="display: none;">
                    <div class="files-grid" id="shipment-files-container">
                        <!-- Files will be injected here -->
                    </div>
                    <div class="form-group" style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid rgba(255,255,255,0.1);">
                        <label>Adicionar Arquivo/Foto</label>
                        <input type="file" id="modal_upload_file" accept="image/*,.pdf">
                        <button type="button" class="btn btn-primary" style="margin-top: 10px; width: fit-content;" onclick="uploadFile()">
                            <i class='bx bx-upload'></i> Enviar Arquivo
                        </button>
                    </div>
                 </div>

                <div class="btn-group">
                    <div class="nav-arrows">
                        <button type="button" class="arrow-btn" id="btnPrev" onclick="changeStep(-1)"><i class='bx bx-chevron-left'></i></button>
                        <button type="button" class="arrow-btn" id="btnNext" onclick="changeStep(1)"><i class='bx bx-chevron-right'></i></button>
                    </div>
                    
                    <div style="display: flex; gap: 10px; align-items: center;">
                        <a href="#" id="btnViewQuote" target="_blank" class="btn btn-secondary" style="background: rgba(34, 197, 94, 0.1); color: #22c55e; border-color: rgba(34, 197, 94, 0.2); display: none;">Ver Cotação</a>
                        <button type="button" class="btn btn-secondary" id="btnGenerateQuote" style="background: rgba(99, 102, 241, 0.1); color: #6366f1; border-color: rgba(99, 102, 241, 0.2); display: none;" onclick="generateQuoteFromShipment()">Gerar Nova Cotação</button>
                        <button type="button" class="btn btn-primary" id="btnGenerateShipping" style="background: #10b981; border-color: #10b981; color: white; display: none;" onclick="generateShipping()">Gerar Envio Oficial</button>
                        <button type="button" class="btn btn-secondary" id="btnWinShipment" style="background: #22c55e; color: white; border: none; display: none;" onclick="openWinShipmentModal()"><i class='bx bx-trophy'></i> Fechar Cotação</button>
                        <button type="button" class="btn btn-secondary" id="btnDeleteShipment" style="color: #ef4444; border-color: rgba(239, 68, 68, 0.2); display: none;" onclick="deleteShipment()">Excluir</button>
                        <button type="submit" class="btn btn-primary" id="btnSubmit" style="display: none;">Salvar Remessa</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Win/Close Modal within Shipments -->
    <div id="shipmentWinModal" class="modal" style="display: none; z-index: 1050;">
        <div class="modal-content" style="max-width: 400px; padding: 2rem;">
            <div class="modal-header" style="margin-bottom: 1.5rem; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 1rem;">
                <h2 style="margin: 0; font-size: 1.2rem; color: #22c55e;"><i class='bx bx-trophy'></i> Fechar Cotação</h2>
            </div>
            <p style="font-size: 0.9rem; color: #94a3b8; margin-bottom: 1.5rem;">Confirme o valor final pago pelo cliente para confirmar o pagamento desta remessa e fechar a cotação vinculada.</p>
            
            <label style="font-size: 0.75rem; color: #94a3b8; text-transform: uppercase; font-weight: 600; display: block; margin-bottom: 0.5rem;">Opções da Cotação</label>
            <div id="shipment-win-price-suggestions" class="price-suggestions" style="margin-bottom: 1rem; display: flex; flex-wrap: wrap; gap: 0.5rem;">
                <!-- Suggestions will be injected here -->
            </div>

            <div class="form-group" style="margin-bottom: 1.5rem;">
                <label>Valor Pago (R$)</label>
                <input type="number" step="0.01" id="shipment_paid_value_input" style="width: 100%; box-sizing: border-box; background: #0a0a0c; border: 1px solid rgba(255,255,255,0.1); color: #fff; padding: 10px 12px; border-radius: 8px;">
            </div>
            <div style="display: flex; gap: 1rem;">
                <button type="button" class="btn btn-primary" onclick="confirmShipmentWin()" style="flex: 1; background: #22c55e; border: none;">Confirmar</button>
                <button type="button" class="btn btn-secondary" onclick="closeShipmentWinModal()" style="flex: 1;">Cancelar</button>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
    
    <script>
        let allShipments = [];
        let customers = [];
        let currentStep = 1;
        const statuses = ['Aguardando', 'Juntando mercadorias', 'Aguardando Dados', 'Preparar Envio', 'Aguardando Coleta', 'Rastreio', 'Entregues'];

        $(document).ready(function() {
            loadCustomers();
            loadShipments();
            initDragAndDrop();
            checkUrlForQuote();

            $('#shipmentForm').on('submit', function(e) {
                e.preventDefault();
                saveShipment();
            });

            $('#recipient_id').on('change', function() {
                const selectedId = $(this).val();
                if (selectedId && customers.length > 0) {
                    const c = customers.find(cust => cust.id == selectedId);
                    if (c && c.country) {
                        $('#destination_country').val(c.country);
                    }
                }
            });

            $('#shipment_photo').on('change', function(e) {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(event) {
                        $('#photoPreview').html('').css('background-image', `url(${event.target.result})`);
                    };
                    reader.readAsDataURL(file);
                }
            });

            $('#note_file').on('change', function() {
                if (this.files.length) $('#note-file-preview').show();
                else $('#note-file-preview').hide();
            });
        });

        function changeStep(n) {
            goToStep(currentStep + n);
        }

        function goToStep(step) {
            if (step < 1 || step > 5) return;

            // Hide all steps and tabs
            $('.wizard-step, .tab-content').hide();
            $('.step-indicator').removeClass('active');

            // Show current step
            currentStep = step;
            
            if (currentStep <= 3) {
                $(`#step-${currentStep}`).show();
            } else if (currentStep === 4) {
                $('#tab-notes').show();
                loadNotes();
            } else if (currentStep === 5) {
                $('#tab-files').show();
                loadFiles();
            }

            $(`#ind-${currentStep}`).addClass('active');

            // Update navigation arrows
            $('#btnPrev').attr('disabled', currentStep === 1);
            
            // "Save" button always visible as requested
            $('#btnSubmit').show();

            if (currentStep < 5) {
                $('#btnNext').show();
            } else {
                $('#btnNext').hide();
            }
        }

        function switchTab(tab) {
            $('.wizard-step, .tab-content').hide();
            $('.tab-btn').removeClass('active');
            
            if (tab === 'details') {
                $(`#step-${currentStep}`).show();
                $('.tab-btn:first').addClass('active');
            } else {
                $(`#tab-${tab}`).show();
                $(`.tab-btn[onclick*="${tab}"]`).addClass('active');
                if (tab === 'notes') loadNotes();
                if (tab === 'files') loadFiles();
            }
        }

        function checkUrlForQuote() {
            const urlParams = new URLSearchParams(window.location.search);
            const quoteId = urlParams.get('quote_id');
            if (quoteId) {
                $.get('api/get_quote_details.php', { id: quoteId }, function(response) {
                    if (response.success) {
                        openShipmentModal();
                        $('#quote_id_input').val(quoteId);
                        $('#linked-quote-id').text('#' + String(quoteId).padStart(5, '0'));
                        $('#linked-quote-display').show();

                        // Load options
                        if (response.quote.freight_options) {
                            const options = JSON.parse(response.quote.freight_options);
                            renderPricePicker(options);
                        }

                        // Client data from quote goes to Responsible
                        $('#responsible_name').val(response.quote.client_name);
                        $('#responsible_phone').val(response.quote.client_phone);
                        
                        $('#destination_country').val(response.quote.destination);
                        $('#weight').val(response.quote.total_weight);
                        $('#freight_value').val(response.quote.total_price);
                        
                        // Sync initial payment status if quote is already won
                        if (response.quote.status === 'won') {
                            $('#payment_status').val('Pagamento confirmado');
                        }
                        
                        if (response.items && response.items.length > 0) {
                            const dims = response.items.map(i => `${i.height}x${i.width}x${i.length}`).join('; ');
                            $('#dimensions').val(dims);
                            $('#quantity').val(response.items.length);
                            if (response.items.length > 1) $('#dim-hint').show();
                        }
                    }
                }, 'json');
            }
        }

        function renderPricePicker(options) {
            const picker = $('#shipment-price-picker');
            const section = $('#quote-prices-section');
            picker.empty();
            if (options && options.length > 0) {
                options.forEach(opt => {
                    const chip = $(`<div class="price-chip">R$ ${parseFloat(opt.price).toFixed(2)}</div>`);
                    chip.on('click', () => $('#freight_value').val(opt.price));
                    picker.append(chip);
                });
                section.show();
            } else {
                section.hide();
            }
        }

        function generateQuoteFromShipment() {
            const weight = $('#weight').val();
            const destination = $('#destination_country').val();
            const quantity = $('#quantity').val();
            const dimensions = $('#dimensions').val();
            const senderName = $('#responsible_name').val();
            const senderPhone = $('#responsible_phone').val();
            
            // Redirect to quote.php with params
            const url = `quote.php?from_shipment=1&weight=${weight}&destination=${destination}&qty=${quantity}&dims=${encodeURIComponent(dimensions)}&client_name=${encodeURIComponent(senderName)}&client_phone=${encodeURIComponent(senderPhone)}`;
            window.location.href = url;
        }

        function generateShipping() {
            const id = $('#shipmentId').val();
            if(!id) return;
            
            Swal.fire({
                title: 'Redirecionando...',
                text: 'Abrindo Sistema de Envios...',
                icon: 'info',
                timer: 1500,
                showConfirmButton: false
            });

            setTimeout(() => {
                window.location.href = `shipment_label.php?prefill_shipment=${id}`;
            }, 800);
        }

        function loadCustomers() {
            $.get('api/get_customers.php', function(data) {
                if(data.success) {
                    customers = data.customers;
                    let options = '<option value="">Selecione um cliente...</option>';
                    customers.forEach(c => {
                        options += `<option value="${c.id}">${c.name} - ${c.document || 'S/ Doc'}</option>`;
                    });
                    $('#sender_id').html(options);
                    $('#recipient_id').html(options);
                }
            }, 'json');
        }

        function loadShipments() {
            $.get('api/get_shipments.php', function(response) {
                if (response.success) {
                    allShipments = response.shipments;
                    renderShipments();
                }
            }, 'json');
        }

        function renderShipments() {
            // Clear all containers
            statuses.forEach(s => {
                const safeId = s.replace(/\s+/g, '-');
                $(`#container-${safeId}`).empty();
                $(`#count-${safeId}`).text('0');
            });

            allShipments.forEach(s => {
                const safeId = s.status.replace(/\s+/g, '-');
                const container = $(`#container-${safeId}`);
                if (!container.length) return;

                const countSpan = $(`#count-${safeId}`);
                countSpan.text(parseInt(countSpan.text()) + 1);
                
                const row = $(`
                    <div class="shipment-row" data-id="${s.id}">
                        <div class="col-id">#${String(s.id).padStart(5, '0')}</div>
                        <div class="col-main" title="${s.sender_name || s.responsible_name || 'S/ Cliente'}">${s.sender_name || s.responsible_name || 'S/ Cliente'}</div>
                        <div class="col-info"><i class='bx bx-map-pin'></i> ${s.recipient_name || 'S/ Destinatário'}</div>
                        <div class="col-info"><i class='bx bx-globe'></i> ${s.destination_country || '-'}</div>
                        <div class="col-dims"><i class='bx bx-package'></i> ${s.dimensions || '-'}</div>
                        <div class="col-weight">${s.weight || '0'} kg</div>
                        <div class="col-price">
                            R$ ${parseFloat(s.freight_value || 0).toFixed(2)}
                            <span class="payment-badge pb-${getPaymentClass(s.payment_status)}">
                                ${s.payment_status || 'Aguardando'}
                            </span>
                        </div>
                    </div>
                `);

                row.on('click', function() {
                    const sid = $(this).data('id');
                    const shipment = allShipments.find(x => x.id == sid);
                    if (shipment) editShipment(shipment);
                });

                container.append(row);
            });
        }

        function getPaymentClass(status) {
            const s = status.toLowerCase();
            if (s.includes('aguardando')) return 'aguardando';
            if (s.includes('confirmação')) return 'pago-confirmacao';
            if (s.includes('confirmado')) return 'pago-confirmado';
            if (s.includes('faturado')) return 'faturado';
            return 'aguardando';
        }

        function initDragAndDrop() {
            statuses.forEach(s => {
                const safeId = s.replace(/\s+/g, '-');
                const el = document.getElementById(`container-${safeId}`);
                if (!el) return;

                new Sortable(el, {
                    group: 'shipments',
                    animation: 150,
                    onEnd: function (evt) {
                        const shipmentId = evt.item.getAttribute('data-id');
                        const newStatus = evt.to.parentElement.getAttribute('data-status');
                        updateShipmentStatus(shipmentId, newStatus);
                    }
                });
            });
        }

        function updateShipmentStatus(id, status) {
            $.post('api/update_shipment_status.php', { id, status }, function(response) {
                if (!response.success) {
                    alert(response.message);
                    loadShipments();
                } else {
                    loadShipments();
                }
            }, 'json');
        }

        function openShipmentModal() {
            $('#modalTitle').text('Nova Remessa');
            $('#shipmentForm')[0].reset();
            $('#shipmentId').val('');
            $('#quote_id_input').val('');
            $('#modalIdBadge').hide();
            $('#linked-quote-display').hide();
            $('#quote-prices-section').hide();
            $('#dim-hint').hide();
            $('#btnDeleteShipment').hide();
            $('#btnGenerateQuote').hide();
            $('#btnGenerateShipping').hide();
            $('#btnViewQuote').hide();
            $('#btnWinShipment').hide();
            $('#photoPreview').html("<i class='bx bx-image-alt' style='font-size: 2rem; color: rgba(255,255,255,0.1);'></i>").css('background-image', 'none');
            
            // Hide tabs for new shipment
            $('#tab-notes-btn, #tab-files-btn').hide();
            
            // Wizard reset
            goToStep(1);
            $('#shipmentModal').css('display', 'flex');
        }

        function closeShipmentModal() {
            $('#shipmentModal').hide();
            // Clear URL params
            window.history.replaceState({}, document.title, window.location.pathname);
        }

        function editShipment(s) {
            $('#modalTitle').text('Editar Remessa');
            $('#modalIdBadge').text('#' + String(s.id).padStart(5, '0')).show();
            $('#shipmentId').val(s.id);
            $('#quote_id_input').val(s.quote_id || '');
            
            if (s.quote_id) {
                $('#linked-quote-id').text('#' + String(s.quote_id).padStart(5, '0'));
                $('#linked-quote-display').show();
                // Fetch quote options for picker
                $.get('api/get_quote_details.php', { id: s.quote_id }, function(response) {
                    if (response.success && response.quote.freight_options) {
                        renderPricePicker(JSON.parse(response.quote.freight_options));
                    }
                }, 'json');
            } else {
                $('#linked-quote-display').hide();
                $('#quote-prices-section').hide();
            }
            
            // Manual customer fields
            $('#sender_name').val(s.sender_name || '');
            $('#sender_phone').val(s.sender_phone || '');
            $('#recipient_name').val(s.recipient_name || '');
            $('#recipient_phone').val(s.recipient_phone || '');
            
            // New fields
            $('#responsible_name').val(s.responsible_name || '');
            $('#responsible_phone').val(s.responsible_phone || '');
            $('#sender_id').val(s.sender_id || '');
            $('#recipient_id').val(s.recipient_id || '');
            $('#description').val(s.description || '');
            $('#declared_value').val(s.declared_value || '');

            $('#status').val(s.status);
            $('#delivery_person').val(s.delivery_person);
            $('#responsible_salesperson').val(s.responsible_salesperson);
            $('#quantity').val(s.quantity);
            $('#dimensions').val(s.dimensions);
            $('#weight').val(s.weight);
            $('#destination_country').val(s.destination_country);
            $('#freight_value').val(s.freight_value);
            $('#payment_status').val(s.payment_status);
            $('#payment_type').val(s.payment_type || '');

            if (parseInt(s.quantity) > 1) $('#dim-hint').show();
            else $('#dim-hint').hide();
            
            if (s.quote_id) {
                // If it was downloaded originally, it might be in follow up
                $('#btnViewQuote').attr('href', 'kanban.php?search=' + s.quote_id).show();
            } else {
                $('#btnViewQuote').hide();
            }
            
            if (s.quote_id && s.payment_status !== 'Pagamento confirmado') {
                $('#btnWinShipment').show();
            } else {
                $('#btnWinShipment').hide();
            }
            
            if (s.shipment_photo) {
                $('#photoPreview').html('').css('background-image', `url(${s.shipment_photo})`);
            } else {
                $('#photoPreview').html("<i class='bx bx-image-alt' style='font-size: 2rem; color: rgba(255,255,255,0.1);'></i>").css('background-image', 'none');
            }

            // Show tabs for existing shipment
            $('#tab-notes-btn, #tab-files-btn').show();

            // Wizard state (show submit button when editing)
            goToStep(1);

            $('#btnDeleteShipment').show();
            $('#btnGenerateQuote').show();
            
            if (s.status === 'Preparar Envio') {
                $('#btnGenerateShipping').show();
            } else {
                $('#btnGenerateShipping').hide();
            }

            $('#shipmentModal').css('display', 'flex');
        }

        async function loadNotes() {
            const id = $('#shipmentId').val();
            const container = $('#shipment-notes-container');
            container.html('<p>Carregando observações...</p>');
            
            try {
                const response = await $.get('api/get_shipment_details_full.php', { id });
                if (response.success) {
                    container.empty();
                    if (response.notes.length === 0) {
                        container.append('<p style="color: #94a3b8; font-size: 0.9rem; text-align: center; margin-top: 2rem;">Nenhuma observação ainda.</p>');
                    }
                    response.notes.forEach(n => {
                        const date = new Date(n.created_at).toLocaleString('pt-BR');
                        const isMine = n.user_name === "<?php echo $_SESSION['name'] ?? ''; ?>";
                        
                        let fileHtml = '';
                        if (n.file_path) {
                            const isImg = n.file_path.match(/\.(jpg|jpeg|png|gif|webp)$/i);
                            const icon = isImg ? 'bx-image' : 'bx-file-blank';
                            fileHtml = `
                                <a href="${n.file_path}" target="_blank" class="chat-file">
                                    <i class='bx ${icon}'></i>
                                    <span>${n.file_name || 'Ver anexo'}</span>
                                </a>
                            `;
                        }

                        container.append(`
                            <div class="chat-bubble ${isMine ? 'mine' : ''}">
                                <span class="chat-author">${n.user_name || 'Sistema'}</span>
                                <div class="chat-content">${n.note}</div>
                                ${fileHtml}
                                <span class="chat-time">${date}</span>
                            </div>
                        `);
                    });
                    // Scroll to bottom
                    container.scrollTop(container[0].scrollHeight);
                }
            } catch(e) { container.html('<p>Erro ao carregar notas.</p>'); }
        }

        function addNote() {
            const shipment_id = $('#shipmentId').val();
            const note = $('#new_note_text').val();
            if (!note) return;

            const formData = new FormData();
            formData.append('shipment_id', shipment_id);
            formData.append('note', note);
            
            const fileInput = $('#note_file')[0];
            if (fileInput.files.length) {
                formData.append('file', fileInput.files[0]);
            }

            $.ajax({
                url: 'api/save_note.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        $('#new_note_text').val('');
                        $('#note_file').val('');
                        $('#note-file-preview').hide();
                        loadNotes();
                        loadFiles(); // Refresh files tab too
                    } else alert(response.message);
                }
            });
        }

        async function loadFiles() {
            const id = $('#shipmentId').val();
            const container = $('#shipment-files-container');
            container.html('<p>Carregando arquivos...</p>');
            
            try {
                const response = await $.get('api/get_shipment_details_full.php', { id });
                if (response.success) {
                    container.empty();
                    
                    // 1. Linked Quote Image
                    if (response.quote_image) {
                        container.append(renderFileCard(response.quote_image, 'Cotação'));
                    }

                    // 2. Main Shipment Photo
                    if (response.shipment.shipment_photo) {
                        container.append(renderFileCard({
                            file_path: response.shipment.shipment_photo,
                            file_name: 'Foto da Remessa',
                            file_type: 'image'
                        }, 'Foto Principal'));
                    }
                    
                    // 3. All uploaded shipment_files (from notes and general)
                    response.files.forEach(f => {
                        container.append(renderFileCard(f));
                    });

                    if (container.children().length === 0) {
                        container.append('<p style="color: #94a3b8; font-size: 0.9rem; grid-column: span 3; text-align: center;">Nenhum arquivo ainda.</p>');
                    }
                }
            } catch(e) { container.html('<p>Erro ao carregar arquivos.</p>'); }
        }

        function renderFileCard(f, label = null) {
            const path = f.file_path;
            const name = label || f.file_name || 'Arquivo';
            const isImg = f.file_type?.includes('image') || path.match(/\.(jpg|jpeg|png|gif|webp)$/i);
            const isPdf = f.file_type?.includes('pdf') || path.match(/\.pdf$/i);
            
            let icon = 'bx-file';
            if (isImg) icon = 'bx-image';
            if (isPdf) icon = 'bx-file-blank'; // Better icon for PDF if available or use generic

            return `
                <div class="file-card">
                    <div class="file-icon"><i class='bx ${icon}'></i></div>
                    <div class="file-name" title="${name}">${name}</div>
                    <div class="file-actions">
                        <a href="${path}" target="_blank" class="file-btn"><i class='bx bx-show'></i></a>
                        <a href="${path}" download class="file-btn"><i class='bx bx-download'></i></a>
                    </div>
                </div>
            `;
        }

        function uploadFile() {
            const id = $('#shipmentId').val();
            const fileInput = $('#modal_upload_file')[0];
            if (!fileInput.files.length) return;

            const formData = new FormData();
            formData.append('shipment_id', id);
            formData.append('file', fileInput.files[0]);

            $.ajax({
                url: 'api/upload_shipment_file.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        $('#modal_upload_file').val('');
                        loadFiles();
                    } else alert(response.message);
                }
            });
        }

        function deleteShipment() {
            const id = $('#shipmentId').val();
            if (!id) return;
            if (confirm('Tem certeza que deseja excluir esta remessa?')) {
                $.post('api/delete_shipment.php', { id }, function(response) {
                    if (response.success) {
                        alert(response.message);
                        closeShipmentModal();
                        loadShipments();
                    } else {
                        alert(response.message);
                    }
                }, 'json');
            }
        }

        function saveShipment(callback = null) {
            const form = document.getElementById('shipmentForm');
            const formData = new FormData(form);
            
            // Don't auto-save if it's a new empty shipment
            if (!$('#shipmentId').val() && !$('#sender_id').val() && !$('#recipient_id').val() && !$('#responsible_name').val()) {
                if (callback) callback();
                return;
            }

            $.ajax({
                url: 'api/save_shipment.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        loadShipments();
                        if (callback) callback();
                        else closeShipmentModal();
                    } else {
                        if (!callback) alert(response.message);
                    }
                },
                dataType: 'json'
            });
        }

        function openWinShipmentModal() {
            const currentPrice = $('#freight_value').val();
            $('#shipment_paid_value_input').val(currentPrice);
            $('#shipmentWinModal').css('display', 'flex');
            
            const suggestions = $('#shipment-win-price-suggestions');
            suggestions.html('<span style="font-size: 0.8rem; color: #94a3b8;">Carregando opções...</span>');

            const quoteId = $('#quote_id_input').val();
            if (quoteId) {
                $.get('api/get_quote_details.php', { id: quoteId }, function(data) {
                    if (data.success) {
                        suggestions.empty();
                        if (data.quote.freight_options) {
                            const options = JSON.parse(data.quote.freight_options);
                            options.forEach(opt => {
                                const chip = $(`<div class="price-chip">R$ ${parseFloat(opt.price).toFixed(2)}</div>`);
                                chip.on('click', () => $('#shipment_paid_value_input').val(opt.price));
                                suggestions.append(chip);
                            });
                        } else {
                            suggestions.html('<span style="font-size: 0.8rem; color: #94a3b8;">Sem opções extras.</span>');
                        }
                    }
                }, 'json').fail(() => suggestions.empty());
            } else {
                suggestions.html('<span style="font-size: 0.8rem; color: #94a3b8;">Sem cotação vinculada.</span>');
            }
        }

        function closeShipmentWinModal() {
            $('#shipmentWinModal').hide();
        }

        function confirmShipmentWin() {
            const val = $('#shipment_paid_value_input').val();
            if (!val) { alert("Informe o valor pago."); return; }
            $('#freight_value').val(val);
            $('#payment_status').val('Pagamento confirmado');
            closeShipmentWinModal();
            // Automatically save the shipment to apply changes
            saveShipment(() => {
                closeShipmentModal();
            });
        }

        // Fechar modal ao clicar fora
        window.onclick = function(event) {
            const modal = document.getElementById('shipmentModal');
            const winModal = document.getElementById('shipmentWinModal');
            if (event.target == winModal) {
                closeShipmentWinModal();
            } else if (event.target == modal) {
                // Auto-save on click outside
                saveShipment(() => {
                    closeShipmentModal();
                });
            }
        }
    </script>
    <datalist id="countries-list">
        <option value="Anguila">
        <option value="Antigua">
        <option value="Argentina">
        <option value="Aruba">
        <option value="Bahamas">
        <option value="Barbados">
        <option value="Belize">
        <option value="Bolivia">
        <option value="Bonaire">
        <option value="Bermudas">
        <option value="Granada">
        <option value="Guadalupe">
        <option value="Guatemala">
        <option value="Guiana Inglesa">
        <option value="Haiti">
        <option value="Honduras">
        <option value="Canada">
        <option value="Chile">
        <option value="Colombia">
        <option value="Ilhas Cayman">
        <option value="Cuba">
        <option value="Curacao">
        <option value="Dominica">
        <option value="Equador">
        <option value="Costa Rica">
        <option value="Estados Unidos">
        <option value="El Salvador">
        <option value="Republica Dominicana">
        <option value="Guiana Francesa">
        <option value="Martinica">
        <option value="Mexico">
        <option value="Montserrat">
        <option value="Nevis">
        <option value="Nicaragua">
        <option value="Panama">
        <option value="Paraguai">
        <option value="Peru">
        <option value="Porto Rico">
        <option value="Trinidad e Tobago">
        <option value="St. Maarten">
        <option value="Sao Bartolomeu">
        <option value="Santo Eustaquio">
        <option value="Sao Cristovao">
        <option value="Santa Lucia">
        <option value="Sao Vicente">
        <option value="Uruguai">
        <option value="Venezuela">
        <option value="Ilhas Virgens Britanicas">
        <option value="Ilhas Virgens Americanas">
        <option value="Jamaica">
        <option value="Suriname">
        <option value="Ilhas Turcas e Caicos">
        <option value="Andorra">
        <option value="Angola">
        <option value="Australia">
        <option value="Austria">
        <option value="Belgica">
        <option value="Bulgaria">
        <option value="China">
        <option value="Croacia">
        <option value="Chipre">
        <option value="Russia">
        <option value="Republica Tcheca">
        <option value="Dinamarca">
        <option value="Estonia">
        <option value="Finlandia">
        <option value="Franca">
        <option value="Alemanha">
        <option value="Gibraltar">
        <option value="Grecia">
        <option value="Guine">
        <option value="Hong Kong (RAE China)">
        <option value="Indonesia">
        <option value="Hungria">
        <option value="Islandia">
        <option value="Italia">
        <option value="Irlanda">
        <option value="Japao">
        <option value="Coreia do Sul">
        <option value="Letonia">
        <option value="Liechtenstein">
        <option value="Lituania">
        <option value="Luxemburgo">
        <option value="Macau (RAE China)">
        <option value="Noruega">
        <option value="Filipinas">
        <option value="Polonia">
        <option value="Portugal">
        <option value="San Marino">
        <option value="Singapura">
        <option value="Eslovaquia">
        <option value="Eslovenia">
        <option value="Nigeria">
        <option value="Africa do Sul">
        <option value="Espanha">
        <option value="Suecia">
        <option value="Suica">
        <option value="Taiwan">
        <option value="Tailandia">
        <option value="Reino Unido">
        <option value="Vaticano">
        <option value="Monaco">
        <option value="Malta">
        <option value="Romania">
        <option value="Paises Baixos">
        <option value="Malasia">
        <option value="Afeganistao">
        <option value="Albania">
        <option value="Argelia">
        <option value="Samoa Americana">
        <option value="Armenia">
        <option value="Azerbaijao">
        <option value="Bahrein">
        <option value="Bangladesh">
        <option value="Bielorrussia">
        <option value="Benin">
        <option value="Butao">
        <option value="Bosnia e Herzegovina">
        <option value="Botsuana">
        <option value="Brunei">
        <option value="Burkina Faso">
        <option value="Burundi">
        <option value="Camboja">
        <option value="Camarones">
        <option value="Ilhas Canarias">
        <option value="Cabo Verde">
        <option value="Republica Centro-Africana">
        <option value="Chade">
        <option value="Comores">
        <option value="Congo">
        <option value="Republica Democratica do Congo">
        <option value="Ilhas Cook">
        <option value="Costa do Marfim">
        <option value="Djibuti">
        <option value="Egito">
        <option value="Eritreia">
        <option value="Essuatini">
        <option value="Etiopia">
        <option value="Ilhas Malvinas">
        <option value="Ilhas Faroe">
        <option value="Fiji">
        <option value="Gabon">
        <option value="Gambia">
        <option value="Georgia">
        <option value="Gana">
        <option value="Groenlandia">
        <option value="Guam">
        <option value="Guernsey">
        <option value="Guine-Bissau">
        <option value="Guine Equatorial">
        <option value="India">
        <option value="Ira">
        <option value="Iraque">
        <option value="Israel">
        <option value="Jersey">
        <option value="Jordania">
        <option value="Cazaquistao">
        <option value="Quenia">
        <option value="Quiribati">
        <option value="Coreia do Norte">
        <option value="Kosovo">
        <option value="Kuwait">
        <option value="Quirguistao">
        <option value="Laos">
        <option value="Libano">
        <option value="Lesoto">
        <option value="Liberia">
        <option value="Libia">
        <option value="Madagascar">
        <option value="Malaui">
        <option value="Maldivas">
        <option value="Mali">
        <option value="Ilhas Marshall">
        <option value="Mauritania">
        <option value="Mauricio">
        <option value="Mayotte">
        <option value="Micronesia">
        <option value="Moldavia">
        <option value="Mongolia">
        <option value="Montenegro">
        <option value="Marrocos">
        <option value="Mocambique">
        <option value="Mianmar">
        <option value="Namibia">
        <option value="Nauru">
        <option value="Nepal">
        <option value="Nova Caledonia">
        <option value="Nova Zelandia">
        <option value="Niger">
        <option value="Niue">
        <option value="Macedonia do Norte">
        <option value="Ilhas Marianas do Norte">
        <option value="Oma">
        <option value="Paquistao">
        <option value="Palau">
        <option value="Papua Nova Guine">
        <option value="Catar">
        <option value="Reuniao">
        <option value="Federacao Russa">
        <option value="Ruanda">
        <option value="Santa Helena">
        <option value="Samoa">
        <option value="Sao Tome e Principe">
        <option value="Arabia Saudita">
        <option value="Senegal">
        <option value="Servia">
        <option value="Seicheles">
        <option value="Serra Leoa">
        <option value="Ilhas Salomao">
        <option value="Somalia">
        <option value="Somalilandia">
        <option value="Sudao do Sul">
        <option value="Sri Lanka">
        <option value="Sudao">
        <option value="Siria">
        <option value="Polinesia Francesa">
        <option value="Taiti">
        <option value="Tajiquistao">
        <option value="Tanzania">
        <option value="Timor-Leste">
        <option value="Togo">
        <option value="Tonga">
        <option value="Tunisia">
        <option value="Turquia">
        <option value="Turcomenistao">
        <option value="Tuvalu">
        <option value="Uganda">
        <option value="Ucrania">
        <option value="Emirados Arabes Unidos">
        <option value="Uzbequistao">
        <option value="Vanuatu">
        <option value="Vietna">
        <option value="Iemen">
        <option value="Zambia">
        <option value="Zimbabwe">
    </datalist>
</body>
</html>
