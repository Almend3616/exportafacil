/* assets/js/shipment_label.js - TOTAL RESET */

$(document).ready(function() {
    let allCustomers = [];
    let allShipments = [];

    // 1. CARREGAMENTO DE DADOS
    function loadInitialData() {
        // Wait for both to finish so we can check URL for cross-linking safely
        $.when(
            $.get('api/get_customers.php'),
            $.get('api/get_shipments.php')
        ).done(function(custResp, shipResp) {
            if (custResp[0].success) allCustomers = custResp[0].customers;
            if (shipResp[0].success) allShipments = shipResp[0].shipments;
            
            checkUrlForPrefill();
        });
        loadHistory();
    }
    loadInitialData();

    function checkUrlForPrefill() {
        const urlParams = new URLSearchParams(window.location.search);
        
        // Tab routing
        const targetTab = urlParams.get('tab');
        if (targetTab === 'history') {
            $('.tab-btn[data-tab="history"]').trigger('click');
        }

        const prefillId = urlParams.get('prefill_shipment');
        if (prefillId) {
            triggerShipmentSelection(prefillId);
            // Optionally clean URL
            window.history.replaceState({}, document.title, window.location.pathname);
        }
    }

    // 2. NAVEGAÇÃO E TABS
    $('.tab-btn').on('click', function() {
        $('.tab-btn').removeClass('active');
        $(this).addClass('active');
        $('.tab-content').removeClass('active');
        $(`#tab-${$(this).data('tab')}`).addClass('active');
        if ($(this).data('tab') === 'history') loadHistory();
    });

    $('.btn-next-step').on('click', function() {
        const current = $(this).data('current');
        const next = $(this).data('next');
        const container = $(`#step-${current}`);
        
        if (validateSection(container)) {
            updateRightSummary(current);
            container.hide();
            $(`#step-${next}`).fadeIn();
            $(`#summary-${current}-card`).removeClass('empty').addClass('active');
        }
    });

    $(document).on('click', '.btn-edit-summary', function() {
        $('.form-step-container').hide();
        $(`#step-${$(this).data('step')}`).fadeIn();
    });

    // 3. BUSCA DE CLIENTES E REMESSAS
    $('#shipperSearch, #customerSearch').on('input', function() {
        const type = $(this).attr('id') === 'shipperSearch' ? 'shipper' : 'receiver';
        const term = $(this).val().toLowerCase();
        const box = type === 'shipper' ? $('#shipper-search-results') : $('#search-results');
        
        if (term.length < 2) { box.hide(); return; }
        const filtered = allCustomers.filter(c => c.name.toLowerCase().includes(term)).slice(0, 10);
        
        box.empty().show();
        filtered.forEach(c => {
            box.append(`<div class="search-item search-row-customer" data-id="${c.id}" data-type="${type}"><span class="name">${c.name}</span><span class="info">${c.city || ''}</span></div>`);
        });
    });

    function fillCustomer(type, c) {
        if (!c) return;
        const p = type === 'shipper' ? '#r_' : '#d_';
        $(p + 'nome').val(c.name);
        $(p + 'l1').val(c.address_line1 || '');
        $(p + 'cidade').val(c.city || '');
        $(p + 'estado').val(c.state || '');
        $(p + (type === 'shipper' ? 'cep' : 'zip')).val(c.zip_code || '');
        $(p + 'pais').val(c.country || '');
        $(p + 'tel').val(c.phone || '');
    }

    $(document).on('click', '.search-row-customer', function() {
        const type = $(this).data('type');
        const c = allCustomers.find(item => item.id == $(this).data('id'));
        if (!c) return;
        fillCustomer(type, c);
        $('.search-results').hide();
    });

    // RESTORED SHIPMENT SEARCH
    $('#shipmentDataSearch').on('focus', function() {
        if ($(this).val().length === 0) {
            const f = allShipments.filter(s => s.status === 'Preparar Envio').slice(0, 10);
            renderShipmentRows(f);
        }
    });

    $('#shipmentDataSearch').on('input', function() {
        const t = $(this).val().toLowerCase();
        if (t.length === 0) {
            renderShipmentRows(allShipments.filter(s => s.status === 'Preparar Envio').slice(0, 10));
            return;
        }
        const f = allShipments.filter(s => s.id.toString().includes(t) || s.recipient_name.toLowerCase().includes(t)).slice(0, 10);
        renderShipmentRows(f);
    });

    function renderShipmentRows(filtered) {
        const box = $('#shipment-search-results');
        box.empty();
        if (filtered.length === 0) { box.hide(); return; }
        filtered.forEach(s => {
            const isTarget = s.status === 'Preparar Envio';
            box.append(`
                <div class="search-item search-row-shipment" data-id="${s.id}">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span class="name">#${s.id} - ${s.recipient_name}</span>
                        ${isTarget ? '<span style="font-size:0.7rem; background:rgba(99,102,241,0.2); color:#6366f1; padding:2px 6px; border-radius:4px;">Preparar Envio</span>' : ''}
                    </div>
                    <span class="info">${s.quantity} Vols | ${s.weight}kg | ${s.dimensions || ''}</span>
                </div>
            `);
        });
        box.show();
    }

    $(document).on('click', '.search-row-shipment', function() {
        triggerShipmentSelection($(this).data('id'));
    });

    function triggerShipmentSelection(id) {
        window.currentShipmentId = id; // Track for saving
        Swal.fire({
            title: 'Carregando Remessa...',
            info: 'Importando dados do remetente e destinatário.',
            timer: 1000,
            timerProgressBar: true,
            didOpen: () => { Swal.showLoading(); }
        });

        $.get('api/get_shipment_details_full.php', { id: id }, function(resp) {
            if (resp.success) {
                const s = resp.shipment;
                
                // Attempt to fill Shipper
                if (s.sender_id) {
                    const cShipper = allCustomers.find(item => item.id == s.sender_id);
                    if (cShipper) fillCustomer('shipper', cShipper);
                } else if (s.responsible_name) {
                    $('#r_nome').val(s.responsible_name);
                }

                // Attempt to fill Receiver
                if (s.recipient_id) {
                    const cReceiver = allCustomers.find(item => item.id == s.recipient_id);
                    if (cReceiver) fillCustomer('receiver', cReceiver);
                } else if (s.recipient_name) {
                    $('#d_nome').val(s.recipient_name);
                }

                // Fill Content
                if (s.description) {
                    if (!$('#content option[value="'+s.description.toUpperCase()+'"]').length) {
                        $('#content').append(`<option value="${s.description.toUpperCase()}">${s.description.toUpperCase()}</option>`);
                    }
                    $('#content').val(s.description.toUpperCase());
                }

                $('#weight').val(s.weight + ' kg').trigger('input');
                $('#total-weight-display').text(s.weight);
                $('#total-vols').text(s.quantity);
                
                $('#volumes-list').empty();
                if (s.dimensions) {
                    const dimsArray = s.dimensions.split(';');
                    dimsArray.forEach((d, idx) => {
                        const parts = d.toLowerCase().split('x');
                        addVolumeRow(idx + 1, 1, parts[0] || 0, parts[1] || 0, parts[2] || 0, (s.weight / s.quantity).toFixed(1));
                    });
                } else {
                    addVolumeRow(1, s.quantity || 1, 0, 0, 0, (s.weight / (s.quantity || 1)).toFixed(1));
                }
                
                $('#shipment-search-results').hide();
                updateTotals();

                // Skip directly to Step 3 so the user can review and generate
                setTimeout(() => {
                    updateRightSummary('shipper');
                    updateRightSummary('receiver');
                    $('.form-step-container').hide();
                    $('#step-shipment').fadeIn();
                    $('#summary-shipper-card').removeClass('empty').addClass('active');
                    $('#summary-receiver-card').removeClass('empty').addClass('active');

                    // Make sure the active tab correctly adjusts
                    $('.tab-btn').removeClass('active');
                    $('.tab-btn[data-tab="new"]').addClass('active');
                    $('.tab-content').removeClass('active');
                    $('#tab-new').addClass('active');
                }, 100);
            }
        });
    }

    // 4. LÓGICA DE VOLUMES
    $('#btn-add-volume').on('click', function() {
        const idx = $('#volumes-list .volume-row').length + 1;
        addVolumeRow(idx, 1, 0, 0, 0, 0);
    });

    $(document).on('click', '.btn-remove-vol', function() {
        $(this).closest('.volume-row').remove();
        updateTotals();
    });

    $(document).on('input', '.vol-qty, .vol-weight', updateTotals);

    function addVolumeRow(idx, qty, l, w, h, weight) {
        $('#volumes-list').append(`
            <div class="volume-row">
                <div class="vol-idx">${idx}</div>
                <div class="form-group"><input type="number" class="vol-qty" value="${qty}" min="1"></div>
                <div class="form-group"><input type="number" class="vol-len" value="${l}"></div>
                <div class="form-group"><input type="number" class="vol-wid" value="${w}"></div>
                <div class="form-group"><input type="number" class="vol-hei" value="${h}"></div>
                <div class="form-group"><input type="number" class="vol-weight" value="${weight}" step="0.1"></div>
                <button type="button" class="btn-remove-vol"><i class='bx bx-trash'></i></button>
            </div>
        `);
        $('#volumes-header').show();
        updateTotals();
    }

    function updateTotals() {
        let v = 0, w = 0;
        $('.volume-row').each(function() {
            const q = parseInt($(this).find('.vol-qty').val()) || 0;
            const weight = parseFloat($(this).find('.vol-weight').val()) || 0;
            v += q; w += (q * weight);
        });
        $('#total-vols').text(v);
        $('#total-weight-display').text(w.toFixed(1));
        $('#weight').val(w.toFixed(1) + ' kg');
    }

    // 5. GERAÇÃO DE PDF (O CORAÇÃO DO RESET)
    window.generatePDF = function() {
        console.log('PDF: Gerando e Salvando no Servidor...');
        const element = document.getElementById('dhl-label');
        if (!element) return;

        const waybill = ($('#waybill').val() || '0000000000').replace(/\s/g, '');
        
        const opt = {
            margin: 0, 
            filename: 'ETIQUETA_' + waybill + '.pdf',
            image: { type: 'jpeg', quality: 1.0 },
            html2canvas: { 
                scale: 2.0, // Reduced from 2.2 to stay under size limits
                useCORS: true, 
                letterRendering: true,
                y: -15, 
                scrollX: 0,
                scrollY: 0
            },
            jsPDF: { unit: 'mm', format: 'a4', orientation: 'landscape' }
        };

        generateBarcodes();

        // 1. Download Local para o Usuário (ALTA QUALIDADE)
        html2pdf().from(element).set(opt).save().then(() => {
            console.log('PDF: Download local concluído. Preparando versão leve para o servidor...');
            
            // LIMPEZA IMEDIATA: O usuário já baixou o arquivo, limpamos a tela agora
            resetAfterSuccess();

            // 2. Capturar Versão LEVE para o Servidor (Bypass server limits)
            const serverOpt = Object.assign({}, opt, {
                image: { type: 'jpeg', quality: 0.6 },
                html2canvas: Object.assign({}, opt.html2canvas, { scale: 0.8 }) 
            });

            html2pdf().from(element).set(serverOpt).output('datauristring').then(pdfDataUri => {
                // Fix for older html2pdf libs failing to output Blobs directly
                const byteString = atob(pdfDataUri.split(',')[1]);
                const mimeString = pdfDataUri.split(',')[0].split(':')[1].split(';')[0];
                const ab = new ArrayBuffer(byteString.length);
                const ia = new Uint8Array(ab);
                for (let i = 0; i < byteString.length; i++) {
                    ia[i] = byteString.charCodeAt(i);
                }
                const pdfBlob = new Blob([ab], {type: mimeString});

                const formData = new FormData();
                formData.append('waybill', waybill);
                if (window.currentShipmentId) formData.append('shipment_id', window.currentShipmentId);
                formData.append('sender_name', $('#r_nome').val());
                formData.append('recipient_name', $('#d_nome').val());
                formData.append('destination_country', $('#d_pais').val());
                formData.append('status', 'Envio feito');
                formData.append('form_all', JSON.stringify($('#labelForm').serializeArray()));
                formData.append('pdf_file', pdfBlob, 'label.pdf');

                $.ajax({
                    url: 'api/save_shipment_label.php',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(resp) {
                        if(!resp.success) {
                            Swal.fire('Erro no Servidor', resp.message, 'error');
                            console.error('Server Logic Error:', resp);
                        } else {
                            console.log('AJAX Success:', resp);
                            // Refresh history and show confirmation!
                            loadHistory();
                            Swal.fire({
                                title: 'Salvo!',
                                text: 'Cópia salva no Histórico de Envios.',
                                icon: 'success',
                                toast: true,
                                position: 'top-end',
                                timer: 3000,
                                showConfirmButton: false
                            });
                        }
                    },
                    error: function(xhr, status, err) {
                        Swal.fire('Erro de Conexão', 'O arquivo original (PDF) era muito grande para o seu servidor PHP processar de uma vez.', 'error');
                        console.error('AJAX Error:', err);
                    }
                });
            });
        }).catch(err => {
            console.error('Erro no PDF Local:', err);
            Swal.fire('Erro', 'Falha ao gerar o PDF: ' + err.message, 'error');
        });
    };

    function resetAfterSuccess() {
        setTimeout(() => {
            resetForm();
            loadHistory();
        }, 300);
    }

    $('#btn-final-save').on('click', generatePDF);

    // 6. UTILITÁRIOS
    function validateSection(section) {
        let valid = true;
        section.find('input[required], select[required]').each(function() {
            if (!$(this).val()) { valid = false; $(this).css('border-color', 'red'); }
            else { $(this).css('border-color', ''); }
        });
        return valid;
    }

    function updateRightSummary(step) {
        const card = $(`#summary-${step}-card`);
        let h = '';
        if (step === 'shipper') h = `<strong>${$('#r_nome').val()}</strong><br>${$('#r_cidade').val()}`;
        else if (step === 'receiver') h = `<strong>${$('#d_nome').val()}</strong><br>${$('#d_pais').val()}`;
        else if (step === 'shipment') h = `<strong>${$('#total-vols').text()} Vols</strong><br>${$('#total-weight-display').text()} kg`;
        
        card.find('.summary-card-body').html(`<div class="summary-info">${h}</div><button type="button" class="btn-edit-summary" data-step="${step}">Editar</button>`);
    }

    function generateBarcodes() {
        const wb = $('#waybill').val().replace(/\s/g, '');
        try { JsBarcode("#barcode-waybill", wb, { format: "CODE128", width: 2, height: 80, displayValue: false }); } catch(e){}
    }

    function generateAutomaticWaybill() {
        const n = Math.floor(Math.random() * 9000000000) + 1000000000;
        $('#waybill').val(n.toString().replace(/(\d{2})(\d{4})(\d{4})/, '$1 $2 $3'));
    }
    generateAutomaticWaybill();

    $('#btn-review').on('click', function() {
        if (!validateSection($('#step-receiver'))) return alert('Preencha os dados do destinatário.');
        updateRightSummary('shipment');
        
        // Populate Preview
        $('#prev_r_nome').text($('#r_nome').val().toUpperCase());
        $('#prev_r_addr').text($('#r_l1').val().toUpperCase());
        $('#prev_r_city').text($('#r_cidade').val().toUpperCase() + ', ' + $('#r_estado').val().toUpperCase());
        $('#prev_r_country').text($('#r_pais').val().toUpperCase());
        $('#prev_r_tel').text('TEL: ' + $('#r_tel').val().toUpperCase());

        $('#prev_d_nome').text($('#d_nome').val().toUpperCase());
        $('#prev_d_addr').text($('#d_l1').val().toUpperCase());
        $('#prev_d_city').text($('#d_cidade').val().toUpperCase());
        $('#prev_d_country').text($('#d_pais').val().toUpperCase());
        $('#prev_d_tel').text('TEL: ' + $('#d_tel').val().toUpperCase());
        $('#prev_d_phone_label').text('PH: ' + $('#d_tel').val().toUpperCase());

        $('#prev_content').text($('#content').val().toUpperCase());
        $('#prev_weight').text($('#total-weight-display').text() + ' KG');
        $('#prev_piece').text('1 / ' + $('#total-vols').text());
        $('#prev_waybill_title').text('WAYBILL ' + $('#waybill').val());

        // Dimensions Parsing for Preview
        let dimsStr = "";
        $('.volume-row').each(function(idx) {
            const l = $(this).find('.vol-len').val() || 0;
            const w = $(this).find('.vol-wid').val() || 0;
            const h = $(this).find('.vol-hei').val() || 0;
            if(l > 0) dimsStr += `${l}x${w}x${h}; `;
        });
        $('#prev_dims').text(dimsStr.trim() || 'N/A');
        
        generateBarcodes();
        $('#preview-modal').show();
    });

    function resetForm() {
        $('#labelForm')[0].reset();
        $('#volumes-list').empty();
        $('#total-vols').text('0');
        $('#total-weight-display').text('0.0');
        $('.summary-card').addClass('empty').removeClass('active');
        $('.summary-card-body').text('Aguardando preenchimento...');
        $('.form-step-container').hide();
        $('#step-shipper').fadeIn();
        generateAutomaticWaybill();
        window.currentShipmentId = null;
    }

    $('#btn-cancel-review').on('click', () => $('#preview-modal').hide());

    function loadHistory() {
        $.get('api/get_shipment_labels.php?v=' + Date.now(), function(resp) {
            console.log("HISTORY API RESPONSE:", resp);
            const container = $('#history-rows-container').empty();
            
            if (!resp.success || !resp.labels || resp.labels.length === 0) {
                container.append('<tr><td colspan="6" style="text-align:center; padding: 3rem; color: var(--text-muted); background: var(--card-bg); border-radius:12px;">Nenhum envio encontrado no histórico.</td></tr>');
                return;
            }

            resp.labels.forEach((l) => {
                let formDataJson = null;
                try { formDataJson = JSON.parse(l.form_data); } catch(e) {}
                const labelDataStr = formDataJson ? encodeURIComponent(JSON.stringify(formDataJson)) : '';
                const copyText = `WAYBILL: ${l.waybill}\nDestinatário: ${l.recipient_name}\nPaís: ${l.destination_country}`;
                const date = new Date(l.created_at).toLocaleDateString();
                
                let statusClass = 'status-done';
                if(l.status === 'Em Rota') statusClass = 'status-route';
                if(l.status === 'Entregue') statusClass = 'status-delivered';

                const row = `
                    <tr class="history-row-item">
                        <td class="waybill-cell">${l.waybill}</td>
                        <td class="history-card-date">${date}</td>
                        <td style="font-weight: 600;">${l.recipient_name}</td>
                        <td>${l.destination_country}</td>
                        <td style="text-align: center;">
                            <span class="status-badge ${statusClass}">${l.status || 'Envio feito'}</span>
                        </td>
                        <td>
                            <div class="table-actions">
                                <a href="${l.file_path}" target="_blank" class="btn-table-action pdf" title="Ver PDF"><i class='bx bxs-file-pdf'></i></a>
                                <button class="btn-table-action btn-edit-label" data-waybill="${l.waybill}" data-form='${labelDataStr}' title="Editar"><i class='bx bx-edit'></i></button>
                                <button class="btn-table-action btn-copy-label" data-text="${copyText}" title="Copiar"><i class='bx bx-copy'></i></button>
                                <button class="btn-table-action btn-delete-label" data-id="${l.id}" title="Excluir"><i class='bx bx-trash'></i></button>
                            </div>
                        </td>
                    </tr>
                `;
                container.append(row);
            });
        });
    }

    // Live Search for History
    $(document).on('keyup', '#historySearch', function() {
        const value = $(this).val().toLowerCase();
        $("#history-rows-container tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });

    // 7. HISTÓRICO ACTIONS (EXCLUIR, COPIAR, EDITAR)
    $(document).on('click', '.btn-delete-label', function() {
        const labelId = $(this).data('id');
        Swal.fire({
            title: 'Excluir Etiqueta?',
            text: "Esta ação apagará permanentemente a etiqueta gerada.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#ef4444',
            cancelButtonColor: '#94a3b8',
            confirmButtonText: 'Sim, excluir'
        }).then((result) => {
            if (result.isConfirmed) {
                $.post('api/delete_shipment_label.php', { id: labelId }, function(resp) {
                    if (resp.success) {
                        Swal.fire({ title: 'Excluído!', text: 'Etiqueta removida.', icon: 'success', toast: true, position: 'top-end', timer: 2000, showConfirmButton: false });
                        loadHistory();
                    } else {
                        Swal.fire('Erro', resp.message, 'error');
                    }
                }, 'json');
            }
        });
    });

    $(document).on('click', '.btn-copy-label', function() {
        const textToCopy = $(this).data('text');
        navigator.clipboard.writeText(textToCopy).then(() => {
            Swal.fire({ title: 'Copiado!', text: 'Dados da etiqueta copiados para a área de transferência.', icon: 'success', toast: true, position: 'top-end', timer: 2000, showConfirmButton: false });
        }).catch(err => {
            console.error('Falha ao copiar:', err);
        });
    });

    $(document).on('click', '.btn-edit-label', function() {
        const waybill = $(this).data('waybill');
        const formStr = $(this).attr('data-form');
        let formData = [];
        try { formData = JSON.parse(decodeURIComponent(formStr)); } catch(e){}

        if (formData && formData.length > 0) {
            Swal.fire({
                title: 'Editar Etiqueta',
                text: "Isso carregará os dados antigos no formulário. Você precisará gerar um novo PDF após editar.",
                icon: 'info',
                showCancelButton: true,
                confirmButtonText: 'Continuar'
            }).then((result) => {
                if (result.isConfirmed) {
                    resetForm();
                    $('#waybill').val(waybill);
                    
                    // Restore form values
                    formData.forEach(field => {
                        $(`[name="${field.name}"]`).val(field.value);
                    });
                    
                    // Because there are no dynamic volumes restored seamlessly right now, we just skip to step 1
                    $('.tab-btn[data-tab="new"]').trigger('click');
                    
                    Swal.fire({ title: 'Dados Carregados', text: 'Você pode agora revisar e ajustar os dados.', icon: 'success', toast: true, position: 'top-end', timer: 2000, showConfirmButton: false });
                }
            });
        } else {
            Swal.fire('Aviso', 'Nenhum dado original encontrado para esta etiqueta.', 'warning');
        }
    });
});
