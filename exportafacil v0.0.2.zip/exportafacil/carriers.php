<?php
require_once 'includes/auth.php';
require_once 'config/db.php';
checkAdmin();

// Handle Carrier CRUD
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_carrier'])) {
        $name = trim($_POST['name']);
        $logo = trim($_POST['logo']); // Simple URL or path for now
        $stmt = $pdo->prepare("INSERT INTO carriers (name, logo) VALUES (?, ?)");
        $stmt->execute([$name, $logo]);
    }
    elseif (isset($_POST['delete_carrier'])) {
        $id = (int)$_POST['carrier_id'];
        $stmt = $pdo->prepare("DELETE FROM carriers WHERE id = ?");
        $stmt->execute([$id]);
    }
    elseif (isset($_POST['add_method'])) {
        $carrier_id = (int)$_POST['carrier_id'];
        $name = trim($_POST['method_name']);
        $time = trim($_POST['delivery_time']);
        $stmt = $pdo->prepare("INSERT INTO shipping_methods (carrier_id, name, delivery_time) VALUES (?, ?, ?)");
        $stmt->execute([$carrier_id, $name, $time]);
    }
    header("Location: carriers.php");
    exit;
}

$carriers = $pdo->query("SELECT * FROM carriers ORDER BY name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Transportadoras - Exporta Fácil</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { background-color: #0a0a0c; color: #e2e8f0; font-family: 'Poppins', sans-serif; padding: 2rem; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; border-bottom: 1px solid rgba(255, 255, 255, 0.1); padding-bottom: 1rem; }
        .header a { color: #6366f1; text-decoration: none; font-weight: 500; }
        .card { background: #111116; border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 16px; padding: 1.5rem; margin-bottom: 2rem; }
        .form-group { margin-bottom: 1rem; }
        .form-group label { display: block; margin-bottom: 0.5rem; color: #94a3b8; }
        .form-group input { width: 100%; padding: 0.75rem; background: #1e1e24; border: 1px solid #333; border-radius: 8px; color: #fff; }
        .btn { border: none; padding: 0.75rem 1.5rem; border-radius: 8px; cursor: pointer; font-weight: 600; }
        .btn-primary { background: #6366f1; color: #fff; }
        .btn-danger { background: #ef4444; color: #fff; padding: 0.5rem 1rem; }
        table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
        th, td { padding: 1rem; text-align: left; border-bottom: 1px solid rgba(255, 255, 255, 0.05); }
        .method-list { list-style: none; padding-left: 0; }
        .method-item { display: flex; justify-content: space-between; align-items: center; background: rgba(255,255,255,0.02); padding: 0.5rem; margin-bottom: 0.25rem; border-radius: 4px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Gerenciar Transportadoras</h1>
        <a href="index.php">Voltar ao Dashboard</a>
    </div>

    <div class="card">
        <h2>Cadastrar Transportadora</h2>
        <form method="POST">
            <div class="form-group">
                <label>Nome da Transportadora</label>
                <input type="text" name="name" required placeholder="Ex: FedEx, DHL...">
            </div>
            <div class="form-group">
                <label>Link da Logo (Emoji ou URL)</label>
                <input type="text" name="logo" placeholder="Ex: 📦 ou assets/img/logo.png">
            </div>
            <button type="submit" name="add_carrier" class="btn btn-primary">Adicionar</button>
        </form>
    </div>

    <div class="card">
        <h2>Transportadoras Cadastradas</h2>
        <table>
            <thead>
                <tr>
                    <th>Logo</th>
                    <th>Nome</th>
                    <th>Tipos de Frete</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($carriers as $c): ?>
                <tr>
                    <td>
                        <?php 
                        $logo = $c['logo'];
                        if (strpos($logo, 'http') === 0 || strpos($logo, 'assets') === 0): ?>
                            <img src="<?php echo htmlspecialchars($logo); ?>" alt="Logo" style="max-height: 40px; border-radius: 4px;">
                        <?php else: ?>
                            <span style="font-size: 1.5rem;"><?php echo htmlspecialchars($logo); ?></span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo htmlspecialchars($c['name']); ?></td>
                    <td>
                        <ul class="method-list">
                            <?php
    $methods = $pdo->prepare("SELECT * FROM shipping_methods WHERE carrier_id = ?");
    $methods->execute([$c['id']]);
    foreach ($methods->fetchAll() as $m):
?>
                                <li class="method-item">
                                    <span><?php echo htmlspecialchars($m['name']); ?> (<?php echo htmlspecialchars($m['delivery_time']); ?>)</span>
                                    <a href="rates.php?method_id=<?php echo $m['id']; ?>" style="color: #6366f1; font-size: 0.8rem;">Ver Preços</a>
                                </li>
                            <?php
    endforeach; ?>
                        </ul>
                        <form method="POST" style="margin-top: 1rem;">
                            <input type="hidden" name="carrier_id" value="<?php echo $c['id']; ?>">
                            <input type="text" name="method_name" placeholder="Novo Tipo (Ex: Express)" required style="width: 120px; padding: 4px;">
                            <input type="text" name="delivery_time" placeholder="Prazo (Ex: 2-5 dias)" required style="width: 100px; padding: 4px;">
                            <button type="submit" name="add_method" class="btn btn-primary" style="padding: 4px 8px; font-size: 0.8rem;">+</button>
                        </form>
                    </td>
                    <td>
                        <form method="POST" onsubmit="return confirm('Excluir esta transportadora e todos os seus métodos/preços?')">
                            <input type="hidden" name="carrier_id" value="<?php echo $c['id']; ?>">
                            <button type="submit" name="delete_carrier" class="btn btn-danger">Excluir</button>
                        </form>
                    </td>
                </tr>
                <?php
endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
