<?php
require_once 'includes/auth.php';
require_once 'config/db.php';
checkLogin();

// Fetch all carriers and methods for the initial select
$carriers = $pdo->query("SELECT * FROM carriers ORDER BY name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nova Cotação - Exporta Fácil</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/boxicons/css/boxicons.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <style>
        :root {
            --bg-color: #050507;
            --card-bg: rgba(17, 17, 22, 0.8);
            --accent: #6366f1;
            --accent-glow: rgba(99, 102, 241, 0.3);
            --text: #e2e8f0;
            --muted: #94a3b8;
            --border: rgba(255, 255, 255, 0.08);
            --glass: rgba(255, 255, 255, 0.03);
        }
        body { 
            background-color: var(--bg-color); 
            background-image: 
                radial-gradient(circle at 20% 20%, rgba(99, 102, 241, 0.05) 0%, transparent 40%),
                radial-gradient(circle at 80% 80%, rgba(168, 85, 247, 0.05) 0%, transparent 40%);
            color: var(--text); 
            font-family: 'Poppins', sans-serif; 
            padding: 2rem; 
            margin: 0;
            min-height: 100vh;
        }
        .container { max-width: 1000px; margin: 0 auto; position: relative; z-index: 1; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 3rem; }
        .header h1 { font-weight: 700; background: linear-gradient(to right, #fff, var(--muted)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin: 0; }
        .header a { background: var(--glass); padding: 0.6rem 1.2rem; border-radius: 12px; border: 1px solid var(--border); color: var(--text); text-decoration: none; font-size: 0.9rem; transition: all 0.3s; }
        .header a:hover { background: var(--accent); border-color: var(--accent); }
        
        .card { 
            background: var(--card-bg); 
            backdrop-filter: blur(12px);
            border: 1px solid var(--border); 
            border-radius: 24px; 
            padding: 2rem; 
            margin-bottom: 2rem; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        h2 { font-size: 1.25rem; font-weight: 600; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.75rem; }
        h2 i { color: var(--accent); }
        
        .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; }
        .form-group { display: flex; flex-direction: column; gap: 0.5rem; }
        label { color: var(--muted); font-size: 0.85rem; font-weight: 500; }
        input, select { 
            background: rgba(255,255,255,0.03); 
            border: 1px solid var(--border); 
            border-radius: 12px; 
            padding: 0.8rem 1rem; 
            color: #fff; 
            font-size: 0.95rem; 
            outline: none; 
            transition: all 0.3s;
        }
        input:focus, select:focus { border-color: var(--accent); background: rgba(255,255,255,0.06); box-shadow: 0 0 0 4px var(--accent-glow); }
        
        .carrier-selection { display: flex; flex-wrap: wrap; gap: 1rem; margin-top: 0.5rem; }
        .carrier-chip { 
            background: var(--glass); 
            border: 1px solid var(--border); 
            padding: 0.5rem 1rem; 
            border-radius: 100px; 
            cursor: pointer; 
            display: flex; 
            align-items: center; 
            gap: 0.5rem;
            transition: all 0.2s;
            user-select: none;
        }
        .carrier-chip.active { background: var(--accent); border-color: var(--accent); }
        .carrier-chip img { height: 16px; border-radius: 2px; }

        .volume-row { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); 
            gap: 1.25rem; 
            align-items: flex-end; 
            margin-bottom: 1.50rem; 
            background: rgba(255,255,255,0.02); 
            padding: 1.5rem; 
            border-radius: 20px; 
            border: 1px solid rgba(255,255,255,0.03);
            position: relative;
        }
        .btn-remove { position: absolute; top: 10px; right: 10px; color: #ef4444; background: none; border: none; cursor: pointer; font-size: 1.2rem; }

        .btn { border: none; padding: 1rem 2rem; border-radius: 14px; cursor: pointer; font-weight: 600; transition: all 0.3s; display: flex; align-items: center; justify-content: center; gap: 0.5rem; }
        .btn-primary { background: linear-gradient(135deg, var(--accent), #818cf8); color: #fff; box-shadow: 0 4px 15px var(--accent-glow); }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 6px 20px var(--accent-glow); }
        .btn-add { background: var(--glass); color: #fff; border: 1px dashed var(--border); margin-top: -1rem; margin-bottom: 2rem; width: 100%; justify-content: center; }
        .btn-add:hover { background: rgba(255,255,255,0.05); border-color: var(--muted); }

        .result-box { margin-top: 3rem; display: none; }
        .quote-result-card { 
            background: linear-gradient(145deg, #16161c, #0d0d12); 
            border: 1px solid var(--border); 
            border-radius: 24px; 
            overflow: hidden; 
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            padding: 1.5rem;
            gap: 2rem;
            transition: all 0.3s;
        }
        .quote-result-card:hover { border-color: var(--accent); transform: scale(1.01); }
        .result-logo { width: 80px; height: 80px; background: #fff; border-radius: 16px; display: flex; align-items: center; justify-content: center; padding: 10px; flex-shrink: 0; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        .result-logo img { width: 100%; height: 100%; object-fit: contain; }
        .result-main { flex: 1; }
        .result-main h3 { margin: 0; font-size: 1.2rem; }
        .result-main p { margin: 0.25rem 0 0; color: var(--muted); font-size: 0.9rem; }
        .result-pricing { text-align: right; display: flex; flex-direction: column; align-items: flex-end; }
        .result-pricing .price { display: block; font-size: 1.5rem; font-weight: 700; color: #fff; }
        .result-pricing .deadline { font-size: 0.85rem; color: #22c55e; font-weight: 500; }
        
        /* Checkbox styling */
        .quote-select-wrapper { margin-right: -0.5rem; display: flex; align-items: center; }
        .custom-checkbox { width: 24px; height: 24px; border: 2px solid var(--border); border-radius: 6px; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.2s; background: var(--glass); }
        .custom-checkbox i { display: none; color: #fff; font-size: 16px; }
        .quote-result-card.selected .custom-checkbox { background: var(--accent); border-color: var(--accent); }
        .quote-result-card.selected .custom-checkbox i { display: block; }

        @media (max-width: 768px) {
            .quote-result-card { flex-direction: column; text-align: center; gap: 1rem; }
            .result-pricing { text-align: center; align-items: center; }
            .quote-select-wrapper { order: -1; margin: 0; }
        }

        /* Capture Template Styles Refined */
        #capture-template {
            position: fixed;
            left: -9999px;
            top: 0;
            width: 450px;
            background: #fff;
            color: #1a1a1a;
            padding: 40px;
            font-family: 'Poppins', sans-serif;
            box-sizing: border-box;
        }
        .capture-header { text-align: center; border-bottom: 3px solid #6366f1; padding-bottom: 25px; margin-bottom: 30px; }
        .capture-header h1 { margin: 0; font-size: 26px; color: #6366f1; text-transform: uppercase; font-weight: 800; letter-spacing: -0.5px; }
        .capture-body { display: flex; flex-direction: column; gap: 20px; }
        .cap-info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 10px; }
        .capture-section { display: flex; flex-direction: column; gap: 4px; border-bottom: 1px solid #f0f0f0; padding-bottom: 12px; }
        .capture-section label { font-size: 10px; text-transform: uppercase; color: #a0a0a0; font-weight: 700; letter-spacing: 1px; }
        .capture-section span { font-size: 15px; font-weight: 600; color: #333; }
        
        .cap-options-list { display: flex; flex-direction: column; gap: 15px; }
        .cap-option-row { display: flex; align-items: center; gap: 20px; background: #fbfbff; padding: 18px; border-radius: 16px; border: 1px solid #eef0ff; }
        .cap-opt-logo-box { width: 55px; height: 55px; background: #fff; border-radius: 12px; display: flex; align-items: center; justify-content: center; padding: 8px; flex-shrink: 0; border: 1px solid #f0f0f0; }
        .cap-opt-logo-box img { width: 100%; height: 100%; object-fit: contain; }
        .cap-opt-info { flex: 1; }
        .cap-opt-info h4 { margin: 0; font-size: 15px; font-weight: 700; color: #1a1a1a; }
        .cap-opt-info p { margin: 2px 0 0; font-size: 12px; color: #666; font-weight: 500; }
        .cap-opt-price { text-align: right; }
        .cap-opt-price .v { font-size: 18px; font-weight: 800; color: #6366f1; display: block; }
        .cap-opt-price .l { font-size: 10px; color: #999; font-weight: 600; text-transform: uppercase; }

        .capture-footer { margin-top: 30px; text-align: center; border-top: 1px dashed #ddd; padding-top: 25px; }
        .cap-footer-badge { background: #6366f1; color: #fff; display: inline-block; padding: 8px 20px; border-radius: 100px; font-size: 12px; font-weight: 700; margin-bottom: 15px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Nova Cotação</h1>
            <a href="index.php">Voltar ao Início</a>
        </div>

        <div class="card">
            <h2><i class='bx bx-user'></i> Dados do Cliente</h2>
            <div class="form-grid">
                <div class="form-group">
                    <label>Nome do Cliente</label>
                    <input type="text" id="client_name" placeholder="Nome completo" required>
                </div>
                <div class="form-group">
                    <label>Telefone</label>
                    <input type="text" id="client_phone" placeholder="(00) 00000-0000">
                </div>
                <div class="form-group">
                    <label>Origem</label>
                    <input type="text" id="origin" placeholder="Cidade / UF">
                </div>
                <div class="form-group">
                    <label>Destino</label>
                    <input type="text" id="destination" placeholder="País / Cidade" list="countries-list">
                </div>
            </div>
            
            <div class="form-group" style="margin-top: 1.5rem;">
                <label>Transportadoras Disponíveis (Selecione)</label>
                <div class="carrier-selection" id="carrier-selection">
                    <?php foreach ($carriers as $c): ?>
                    <div class="carrier-chip active" onclick="this.classList.toggle('active')" data-id="<?php echo $c['id']; ?>">
                        <?php if (strpos($c['logo'], 'http') === 0 || strpos($c['logo'], 'assets') === 0): ?>
                            <img src="<?php echo htmlspecialchars($c['logo']); ?>" alt="">
                        <?php else: ?>
                            <span><?php echo $c['logo']; ?></span>
                        <?php endif; ?>
                        <span><?php echo htmlspecialchars($c['name']); ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <div class="card">
            <h2><i class='bx bx-package'></i> Volumes e Dimensões</h2>
            <div id="volumes-container">
                <!-- Volume rows will be injected here -->
            </div>
            <button type="button" class="btn btn-add" onclick="addVolume()"><i class='bx bx-plus'></i> Adicionar Novo Volume</button>
        </div>

        <button type="button" class="btn btn-primary" style="width: 100%; font-size: 1.1rem; padding: 1.5rem;" onclick="calculateQuote()">
            <i class='bx bx-calculator'></i> Calcular Fretes Disponíveis
        </button>

        <div id="results" class="result-box">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 2rem; gap: 1rem;">
                <h2 style="color: #fff; margin: 0;"><i class='bx bx-list-check'></i> Orçamentos Gerados</h2>
                <div style="display: flex; gap: 0.8rem;">
                    <button type="button" class="btn btn-secondary" id="btn-select-all" style="padding: 0.8rem 1.5rem; display: none;" onclick="toggleSelectAll()">
                        <i class='bx bx-check-double'></i> Selecionar Todos
                    </button>
                    <button type="button" class="btn btn-primary" id="btn-generate-multi" style="padding: 0.8rem 1.5rem; display: none;" onclick="processAndGenerate()">
                        <i class='bx bx-save'></i> Salvar e Gerar Imagem
                    </button>
                </div>
            </div>
            <div id="price-list"></div>
        </div>
    </div>

    <!-- Hidden Capture Template Refined -->
    <div id="capture-template">
        <div class="capture-header">
            <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                <h1 style="text-align: left;">Cotação Exporta Fácil</h1>
                <div style="text-align: right;">
                    <span style="font-size: 10px; color: #a0a0a0; font-weight: 700; text-transform: uppercase;">ID da Cotação</span>
                    <span id="cap-id" style="font-size: 16px; font-weight: 800; color: #6366f1; display: block;">#-----</span>
                </div>
            </div>
            <p style="margin: 5px 0 0; font-size: 13px; color: #666; font-weight: 600; text-align: left;" id="cap-date"></p>
        </div>
        <div class="capture-body">
            <div class="capture-section">
                <label>Cliente</label>
                <span id="cap-client">-</span>
            </div>
            <div class="cap-info-grid">
                <div class="capture-section">
                    <label>Origem</label>
                    <span id="cap-origin">-</span>
                </div>
                <div class="capture-section">
                    <label>Destino</label>
                    <span id="cap-dest">-</span>
                </div>
            </div>
            <div class="cap-info-grid">
                <div class="capture-section" style="border-bottom: none">
                    <label>Volumes</label>
                    <span id="cap-volumes">-</span>
                </div>
                <div class="capture-section" style="border-bottom: none">
                    <label>Peso Considerado</label>
                    <span id="cap-weight">-</span>
                </div>
            </div>

            <div style="margin: 10px 0 5px; font-size: 11px; font-weight: 800; color: #6366f1; text-transform: uppercase; letter-spacing: 1px;">Opções de Envio Disponíveis:</div>
            
            <div class="cap-options-list" id="cap-options-list">
                <!-- Options will be injected here -->
            </div>

            <div class="capture-footer">
                <div class="cap-footer-badge">Cotação válida por 48h</div>
                <p style="text-align: center; font-size: 11px; color: #888; line-height: 1.5; margin: 0;">
                    Para confirmar o envio, entre em contato conosco.<br>
                    <strong>Gerado via Exporta Fácil System</strong>
                </p>
            </div>
        </div>
    </div>

    <script>
        let volumeCount = 0;

        function addVolume() {
            volumeCount++;
            const container = document.getElementById('volumes-container');
            const row = document.createElement('div');
            row.className = 'volume-row';
            row.id = `volume-${volumeCount}`;
            row.innerHTML = `
                <div class="form-group" style="flex: 0.5;">
                    <label>Qtd</label>
                    <input type="number" class="v-qty" value="1" min="1" oninput="updateRow(${volumeCount})">
                </div>
                <div class="form-group">
                    <label>Alt (cm)</label>
                    <input type="number" class="v-h" placeholder="0" oninput="updateRow(${volumeCount})">
                </div>
                <div class="form-group">
                    <label>Larg (cm)</label>
                    <input type="number" class="v-w" placeholder="0" oninput="updateRow(${volumeCount})">
                </div>
                <div class="form-group">
                    <label>Comp (cm)</label>
                    <input type="number" class="v-l" placeholder="0" oninput="updateRow(${volumeCount})">
                </div>
                <div class="form-group">
                    <label>Peso Real Unit. (kg)</label>
                    <input type="number" class="v-weight" step="0.1" placeholder="0.0" oninput="updateRow(${volumeCount})">
                </div>
                <div class="form-group">
                    <label>Peso Considerado Total</label>
                    <input type="text" class="v-final" readonly value="0 kg" style="background: transparent; border: none; font-weight: 600; color: var(--accent)">
                </div>
                <button type="button" class="btn" style="background: transparent; color: #ef4444;" onclick="removeVolume(${volumeCount})"><i class='bx bx-trash'></i></button>
            `;
            container.appendChild(row);
        }

        function removeVolume(id) {
            document.getElementById(`volume-${id}`).remove();
        }

        function updateRow(id) {
            const row = document.getElementById(`volume-${id}`);
            const qty = parseInt(row.querySelector('.v-qty').value) || 1;
            const h = parseFloat(row.querySelector('.v-h').value) || 0;
            const w = parseFloat(row.querySelector('.v-w').value) || 0;
            const l = parseFloat(row.querySelector('.v-l').value) || 0;
            const weightRealUnit = parseFloat(row.querySelector('.v-weight').value) || 0;

            const cubedUnit = (h * w * l) / 5000;
            const weightConsideredUnit = Math.max(weightRealUnit, cubedUnit);
            const weightConsideredTotal = weightConsideredUnit * qty;
            
            let rounded = weightConsideredTotal;
            if (rounded > 0 && rounded <= 0.5) rounded = 0.5;
            else if (rounded > 0.5 && rounded <= 1.0) rounded = 1.0;
            else rounded = Math.ceil(rounded);

            row.querySelector('.v-final').value = `${rounded} kg`;
        }

        let calculatedResults = null;

        async function calculateQuote() {
            const client_name = document.getElementById('client_name').value;
            if(!client_name) { alert('Por favor, informe o nome do cliente.'); return; }

            const selectedChips = document.querySelectorAll('.carrier-chip.active');
            const selectedIds = Array.from(selectedChips).map(chip => chip.dataset.id);

            const volumes = [];
            const rows = document.querySelectorAll('.volume-row');
            let totalWeight = 0;

            rows.forEach(row => {
                const weightText = row.querySelector('.v-final').value;
                const weight = parseFloat(weightText);
                totalWeight += weight;
                volumes.push({
                    h: row.querySelector('.v-h').value,
                    w: row.querySelector('.v-w').value,
                    l: row.querySelector('.v-l').value,
                    weight: row.querySelector('.v-weight').value,
                    considered: weight
                });
            });

            if(totalWeight === 0) { alert('Adicione pelo menos um volume.'); return; }

            // Fetch prices from API
            try {
                const response = await fetch(`api/get_prices.php?weight=${totalWeight}&carriers=${selectedIds.join(',')}`);
                const data = await response.json();
                
                if(data.success) {
                    calculatedResults = data.options;
                    displayResults(data.options);
                } else {
                    alert('Nenhuma transportadora encontrada para este peso e seleção.');
                }
            } catch (error) {
                alert('Erro ao calcular preços.');
            }
        }

        let currentOptions = [];

        function displayResults(options) {
            currentOptions = options;
            const resultsBox = document.getElementById('results');
            const priceList = document.getElementById('price-list');
            const btnMulti = document.getElementById('btn-generate-multi');
            const btnAll = document.getElementById('btn-select-all');
            priceList.innerHTML = '';

            options.forEach((opt, index) => {
                const div = document.createElement('div');
                div.className = 'quote-result-card';
                div.id = `opt-card-${index}`;
                div.dataset.opt = JSON.stringify(opt);
                
                let logoHtml = `<span style="font-size: 2rem;">📦</span>`;
                if (opt.carrier_logo && (opt.carrier_logo.startsWith('http') || opt.carrier_logo.startsWith('assets'))) {
                    logoHtml = `<img src="${opt.carrier_logo}" alt="${opt.carrier}">`;
                } else if (opt.carrier_logo) {
                    logoHtml = `<span style="font-size: 2.5rem; font-weight: 800;">${opt.carrier_logo}</span>`;
                }

                div.innerHTML = `
                    <div class="quote-select-wrapper" onclick="toggleOption(${index}); event.stopPropagation();">
                        <div class="custom-checkbox"><i class='bx bx-check'></i></div>
                    </div>
                    <div class="result-logo">${logoHtml}</div>
                    <div class="result-main">
                        <h3>${opt.carrier} - ${opt.method}</h3>
                        <p><i class='bx bx-time'></i> Prazo estimado: ${opt.delivery_time}</p>
                    </div>
                    <div class="result-pricing">
                        <span class="price">R$ ${parseFloat(opt.price).toLocaleString('pt-BR', {minimumFractionDigits: 2})}</span>
                        <div style="display: flex; flex-direction: column; gap: 5px; align-items: flex-end;">
                            <span class="deadline">Valor Estimado</span>
                            <button class="btn btn-primary" style="padding: 4px 10px; font-size: 0.8rem;" onclick="saveResult(${index}); event.stopPropagation();">
                                <i class='bx bx-save'></i> Salvar
                            </button>
                        </div>
                    </div>
                `;

                // Single click on card also toggles selection
                div.onclick = () => toggleOption(index);

                priceList.appendChild(div);
            });

            resultsBox.style.display = 'block';
            resultsBox.scrollIntoView({ behavior: 'smooth' });
            btnMulti.style.display = 'block';
            btnAll.style.display = 'block';
        }

        function toggleOption(index) {
            const card = document.getElementById(`opt-card-${index}`);
            card.classList.toggle('selected');
        }

        let allSelected = false;
        function toggleSelectAll() {
            const cards = document.querySelectorAll('.quote-result-card');
            allSelected = !allSelected;
            cards.forEach(card => {
                if (allSelected) card.classList.add('selected');
                else card.classList.remove('selected');
            });
            document.getElementById('btn-select-all').innerHTML = allSelected ? 
                `<i class='bx bx-x'></i> Desmarcar Todos` : 
                `<i class='bx bx-check-double'></i> Selecionar Todos`;
        }

        async function processAndGenerate() {
            const selectedCards = document.querySelectorAll('.quote-result-card.selected');
            if (selectedCards.length === 0) {
                alert('Selecione pelo menos uma opção para salvar e gerar a imagem.');
                return;
            }

            const btn = document.getElementById('btn-generate-multi');
            btn.disabled = true;
            btn.innerHTML = `<i class='bx bx-loader-alt bx-spin'></i> Processando...`;

            try {
                // 1. Save the quote first to get an ID
                // We pick the first selected option's price as the "main" price or just use the first for the record
                const firstOpt = JSON.parse(selectedCards[0].dataset.opt);
                const quoteId = await saveQuoteBackground(firstOpt.price);

                if (quoteId) {
                    // 2. Generate the image with the new ID
                    await generateMultiImage(quoteId);

                    // 3. No longer redirecting automatically as per user request
                    // setTimeout(() => {
                    //     window.location.href = 'kanban.php';
                    // }, 1000);
                    console.log('Cotação salva e imagem gerada com sucesso!');
                }
            } catch (error) {
                console.error(error);
                alert('Erro ao processar cotação.');
            } finally {
                btn.disabled = false;
                btn.innerHTML = `<i class='bx bx-save'></i> Salvar e Gerar Imagem`;
            }
        }

        async function saveResult(index) {
            const opt = currentOptions[index];
            const btn = event.currentTarget;
            const originalHtml = btn.innerHTML;
            
            btn.disabled = true;
            btn.innerHTML = `<i class='bx bx-loader-alt bx-spin'></i>`;
            
            try {
                // 1. Save quote to background first
                const quoteId = await saveQuoteBackground(opt.price, [opt]);
                
                if (quoteId) {
                    // 2. Generate the image for this specific option
                    await generateMultiImage(quoteId, [opt]);
                    console.log('Cotação individual salva:', quoteId);
                }
            } catch (error) {
                console.error(error);
                alert('Erro ao salvar cotação: ' + error.message);
            } finally {
                btn.disabled = false;
                btn.innerHTML = originalHtml;
            }
        }

        async function saveQuoteBackground(price, overrideOptions = null) {
            const rows = document.querySelectorAll('.volume-row');
            const volumes = [];
            let totalWeight = 0;
            rows.forEach(row => {
                const weightText = row.querySelector('.v-final').value;
                const weight = parseFloat(weightText);
                totalWeight += weight;
                volumes.push({
                    h: row.querySelector('.v-h').value,
                    w: row.querySelector('.v-w').value,
                    l: row.querySelector('.v-l').value,
                    weight: row.querySelector('.v-weight').value,
                    considered: weight
                });
            });

            const quoteData = {
                client_name: document.getElementById('client_name').value,
                client_phone: document.getElementById('client_phone').value,
                origin: document.getElementById('origin').value,
                destination: document.getElementById('destination').value,
                total_weight: totalWeight,
                total_price: price,
                volumes: volumes,
                all_options: overrideOptions || currentOptions
            };

            const response = await fetch('api/save_quote.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(quoteData)
            });

            const result = await response.json();
            if (result.success) return result.quote_id;
            throw new Error(result.message || 'Erro ao salvar');
        }

        function generateMultiImage(quoteId = null, overrideOptions = null) {
            return new Promise((resolve) => {
                const selectedCards = overrideOptions ? [] : document.querySelectorAll('.quote-result-card.selected');
                if (!overrideOptions && selectedCards.length === 0) {
                    alert('Selecione pelo menos uma opção de frete para gerar a imagem.');
                    resolve();
                    return;
                }

                // Populate global info
                const today = new Date().toLocaleDateString('pt-BR');
                document.getElementById('cap-date').innerText = today;
                document.getElementById('cap-client').innerText = document.getElementById('client_name').value || '-';
                document.getElementById('cap-origin').innerText = document.getElementById('origin').value || '-';
                document.getElementById('cap-dest').innerText = document.getElementById('destination').value || '-';
                document.getElementById('cap-id').innerText = quoteId ? `#${String(quoteId).padStart(5, '0')}` : '#-----';

                // Calculate total weight and volumes for summary
                const rows = document.querySelectorAll('.volume-row');
                let totalWeight = 0;
                rows.forEach(row => totalWeight += parseFloat(row.querySelector('.v-final').value) || 0);
                document.getElementById('cap-weight').innerText = `${totalWeight.toFixed(1)} kg`;
                document.getElementById('cap-volumes').innerText = `${rows.length} volumes`;

                // Populate options list
                const capList = document.getElementById('cap-options-list');
                capList.innerHTML = '';

                const optionsToRender = overrideOptions || Array.from(selectedCards).map(card => JSON.parse(card.dataset.opt));

                optionsToRender.forEach(opt => {
                    let logoHtml = `<span style="font-size: 1.5rem;">📦</span>`;
                    if (opt.carrier_logo && (opt.carrier_logo.startsWith('http') || opt.carrier_logo.startsWith('assets'))) {
                        logoHtml = `<img src="${opt.carrier_logo}" crossOrigin="anonymous">`;
                    } else if (opt.carrier_logo) {
                        logoHtml = `<span style="font-weight: 800; font-size: 1.2rem; color: #6366f1;">${opt.carrier_logo}</span>`;
                    }

                    const item = document.createElement('div');
                    item.className = 'cap-option-row';
                    item.innerHTML = `
                        <div class="cap-opt-logo-box">${logoHtml}</div>
                        <div class="cap-opt-info">
                            <h4>${opt.carrier}</h4>
                            <p>${opt.method || ''} ${opt.delivery_time ? '(' + opt.delivery_time + ')' : ''}</p>
                        </div>
                        <div class="cap-opt-price">
                            <span class="v">R$ ${parseFloat(opt.price).toLocaleString('pt-BR', {minimumFractionDigits: 2})}</span>
                            <span class="l">Estimado</span>
                        </div>
                    `;
                    capList.appendChild(item);
                });

                // Re-render and capture
                const template = document.getElementById('capture-template');
                template.style.left = "0px";
                
                setTimeout(() => {
                    html2canvas(template, {
                        useCORS: true,
                        allowTaint: true,
                        scale: 3, 
                        backgroundColor: "#ffffff"
                    }).then(canvas => {
                        const link = document.createElement('a');
                        link.download = `Cotacoes_ExportaFacil_${quoteId || Date.now()}.png`;
                        link.href = canvas.toDataURL("image/png");
                        link.click();
                        template.style.left = "-9999px";
                        resolve();
                    });
                }, 500);
            });
        }

        // Initialize with one volume
        addVolume();

        // Check for pre-filled data from Shipment
        window.addEventListener('DOMContentLoaded', () => {
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.get('from_shipment')) {
                document.getElementById('client_name').value = urlParams.get('client_name') || '';
                document.getElementById('client_phone').value = urlParams.get('client_phone') || '';
                document.getElementById('origin').value = urlParams.get('origin') || 'Brasil'; // Default or from URL
                document.getElementById('destination').value = urlParams.get('destination') || '';
                
                const qty = parseInt(urlParams.get('qty')) || 1;
                const weight = parseFloat(urlParams.get('weight')) || 0;
                const dimsStr = decodeURIComponent(urlParams.get('dims') || '');

                // Clear default row if qty > 1 to avoid duplication with the loop below
                if (qty > 1 && dimsStr.includes(';')) {
                    document.getElementById('volumes-container').innerHTML = '';
                    volumeCount = 0;
                }

                if (dimsStr && dimsStr.includes(';')) {
                    const dimsArray = dimsStr.split(';');
                    dimsArray.forEach((d, i) => {
                        const dim = d.trim().split('x');
                        if (dim.length === 3) {
                            addVolume();
                            const row = document.getElementById(`volume-${volumeCount}`);
                            row.querySelector('.v-h').value = dim[0];
                            row.querySelector('.v-w').value = dim[1];
                            row.querySelector('.v-l').value = dim[2];
                            if (qty > 0 && weight > 0) {
                                row.querySelector('.v-weight').value = (weight / qty).toFixed(2);
                            }
                        }
                    });
                } else if (dimsStr && dimsStr.includes('x')) {
                    const dim = dimsStr.trim().split('x');
                    if (dim.length === 3) {
                        const row = document.getElementById('volume-1');
                        row.querySelector('.v-h').value = dim[0];
                        row.querySelector('.v-w').value = dim[1];
                        row.querySelector('.v-l').value = dim[2];
                        if (weight > 0) {
                            row.querySelector('.v-weight').value = weight;
                        }
                    }
                }
                
                // Trigger updates
                const firstWeight = document.querySelector('.v-weight');
                if (firstWeight) firstWeight.dispatchEvent(new Event('input'));
            }
        });
    </script>
    <datalist id="countries-list">
        <option value="Anguila">
        <option value="Antigua">
        <option value="Argentina">
        <option value="Aruba">
        <option value="Bahamas">
        <option value="Barbados">
        <option value="Belize">
        <option value="Bolivia">
        <option value="Bonaire">
        <option value="Bermudas">
        <option value="Granada">
        <option value="Guadalupe">
        <option value="Guatemala">
        <option value="Guiana Inglesa">
        <option value="Haiti">
        <option value="Honduras">
        <option value="Canada">
        <option value="Chile">
        <option value="Colombia">
        <option value="Ilhas Cayman">
        <option value="Cuba">
        <option value="Curacao">
        <option value="Dominica">
        <option value="Equador">
        <option value="Costa Rica">
        <option value="Estados Unidos">
        <option value="El Salvador">
        <option value="Republica Dominicana">
        <option value="Guiana Francesa">
        <option value="Martinica">
        <option value="Mexico">
        <option value="Montserrat">
        <option value="Nevis">
        <option value="Nicaragua">
        <option value="Panama">
        <option value="Paraguai">
        <option value="Peru">
        <option value="Porto Rico">
        <option value="Trinidad e Tobago">
        <option value="St. Maarten">
        <option value="Sao Bartolomeu">
        <option value="Santo Eustaquio">
        <option value="Sao Cristovao">
        <option value="Santa Lucia">
        <option value="Sao Vicente">
        <option value="Uruguai">
        <option value="Venezuela">
        <option value="Ilhas Virgens Britanicas">
        <option value="Ilhas Virgens Americanas">
        <option value="Jamaica">
        <option value="Suriname">
        <option value="Ilhas Turcas e Caicos">
        <option value="Andorra">
        <option value="Angola">
        <option value="Australia">
        <option value="Austria">
        <option value="Belgica">
        <option value="Bulgaria">
        <option value="China">
        <option value="Croacia">
        <option value="Chipre">
        <option value="Russia">
        <option value="Republica Tcheca">
        <option value="Dinamarca">
        <option value="Estonia">
        <option value="Finlandia">
        <option value="Franca">
        <option value="Alemanha">
        <option value="Gibraltar">
        <option value="Grecia">
        <option value="Guine">
        <option value="Hong Kong (RAE China)">
        <option value="Indonesia">
        <option value="Hungria">
        <option value="Islandia">
        <option value="Italia">
        <option value="Irlanda">
        <option value="Japao">
        <option value="Coreia do Sul">
        <option value="Letonia">
        <option value="Liechtenstein">
        <option value="Lituania">
        <option value="Luxemburgo">
        <option value="Macau (RAE China)">
        <option value="Noruega">
        <option value="Filipinas">
        <option value="Polonia">
        <option value="Portugal">
        <option value="San Marino">
        <option value="Singapura">
        <option value="Eslovaquia">
        <option value="Eslovenia">
        <option value="Nigeria">
        <option value="Africa do Sul">
        <option value="Espanha">
        <option value="Suecia">
        <option value="Suica">
        <option value="Taiwan">
        <option value="Tailandia">
        <option value="Reino Unido">
        <option value="Vaticano">
        <option value="Monaco">
        <option value="Malta">
        <option value="Romania">
        <option value="Paises Baixos">
        <option value="Malasia">
        <option value="Afeganistao">
        <option value="Albania">
        <option value="Argelia">
        <option value="Samoa Americana">
        <option value="Armenia">
        <option value="Azerbaijao">
        <option value="Bahrein">
        <option value="Bangladesh">
        <option value="Bielorrussia">
        <option value="Benin">
        <option value="Butao">
        <option value="Bosnia e Herzegovina">
        <option value="Botsuana">
        <option value="Brunei">
        <option value="Burkina Faso">
        <option value="Burundi">
        <option value="Camboja">
        <option value="Camarones">
        <option value="Ilhas Canarias">
        <option value="Cabo Verde">
        <option value="Republica Centro-Africana">
        <option value="Chade">
        <option value="Comores">
        <option value="Congo">
        <option value="Republica Democratica do Congo">
        <option value="Ilhas Cook">
        <option value="Costa do Marfim">
        <option value="Djibuti">
        <option value="Egito">
        <option value="Eritreia">
        <option value="Essuatini">
        <option value="Etiopia">
        <option value="Ilhas Malvinas">
        <option value="Ilhas Faroe">
        <option value="Fiji">
        <option value="Gabon">
        <option value="Gambia">
        <option value="Georgia">
        <option value="Gana">
        <option value="Groenlandia">
        <option value="Guam">
        <option value="Guernsey">
        <option value="Guine-Bissau">
        <option value="Guine Equatorial">
        <option value="India">
        <option value="Ira">
        <option value="Iraque">
        <option value="Israel">
        <option value="Jersey">
        <option value="Jordania">
        <option value="Cazaquistao">
        <option value="Quenia">
        <option value="Quiribati">
        <option value="Coreia do Norte">
        <option value="Kosovo">
        <option value="Kuwait">
        <option value="Quirguistao">
        <option value="Laos">
        <option value="Libano">
        <option value="Lesoto">
        <option value="Liberia">
        <option value="Libia">
        <option value="Madagascar">
        <option value="Malaui">
        <option value="Maldivas">
        <option value="Mali">
        <option value="Ilhas Marshall">
        <option value="Mauritania">
        <option value="Mauricio">
        <option value="Mayotte">
        <option value="Micronesia">
        <option value="Moldavia">
        <option value="Mongolia">
        <option value="Montenegro">
        <option value="Marrocos">
        <option value="Mocambique">
        <option value="Mianmar">
        <option value="Namibia">
        <option value="Nauru">
        <option value="Nepal">
        <option value="Nova Caledonia">
        <option value="Nova Zelandia">
        <option value="Niger">
        <option value="Niue">
        <option value="Macedonia do Norte">
        <option value="Ilhas Marianas do Norte">
        <option value="Oma">
        <option value="Paquistao">
        <option value="Palau">
        <option value="Papua Nova Guine">
        <option value="Catar">
        <option value="Reuniao">
        <option value="Federacao Russa">
        <option value="Ruanda">
        <option value="Santa Helena">
        <option value="Samoa">
        <option value="Sao Tome e Principe">
        <option value="Arabia Saudita">
        <option value="Senegal">
        <option value="Servia">
        <option value="Seicheles">
        <option value="Serra Leoa">
        <option value="Ilhas Salomao">
        <option value="Somalia">
        <option value="Somalilandia">
        <option value="Sudao do Sul">
        <option value="Sri Lanka">
        <option value="Sudao">
        <option value="Siria">
        <option value="Polinesia Francesa">
        <option value="Taiti">
        <option value="Tajiquistao">
        <option value="Tanzania">
        <option value="Timor-Leste">
        <option value="Togo">
        <option value="Tonga">
        <option value="Tunisia">
        <option value="Turquia">
        <option value="Turcomenistao">
        <option value="Tuvalu">
        <option value="Uganda">
        <option value="Ucrania">
        <option value="Emirados Arabes Unidos">
        <option value="Uzbequistao">
        <option value="Vanuatu">
        <option value="Vietna">
        <option value="Iemen">
        <option value="Zambia">
        <option value="Zimbabwe">
    </datalist>
</body>
</html>
