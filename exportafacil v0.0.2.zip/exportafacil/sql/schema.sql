CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') DEFAULT 'user',
    status ENUM('pending', 'approved') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Carriers Management
CREATE TABLE IF NOT EXISTS carriers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    logo VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Shipping Methods (e.g., Express, Economic)
CREATE TABLE IF NOT EXISTS shipping_methods (
    id INT AUTO_INCREMENT PRIMARY KEY,
    carrier_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    delivery_time VARCHAR(100),
    FOREIGN KEY (carrier_id) REFERENCES carriers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Weight-based Pricing
CREATE TABLE IF NOT EXISTS shipping_rates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    method_id INT NOT NULL,
    weight_up_to DECIMAL(10, 2) NOT NULL, -- e.g., 0.5, 1.0, 2.0
    price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (method_id) REFERENCES shipping_methods(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Quotes for Kanban and Follow-Up
CREATE TABLE IF NOT EXISTS quotes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    client_name VARCHAR(100) NOT NULL,
    client_phone VARCHAR(20),
    origin VARCHAR(100),
    destination VARCHAR(100),
    total_weight DECIMAL(10, 2),
    total_price DECIMAL(10, 2),
    paid_value DECIMAL(10, 2) DEFAULT NULL,
    is_duplicate BOOLEAN DEFAULT FALSE,
    status ENUM('pending', 'won', 'lost', 'follow_up') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Specific volumes in a quote
CREATE TABLE IF NOT EXISTS quote_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quote_id INT NOT NULL,
    height DECIMAL(10, 2),
    width DECIMAL(10, 2),
    length DECIMAL(10, 2),
    actual_weight DECIMAL(10, 2),
    cubed_weight DECIMAL(10, 2),
    FOREIGN KEY (quote_id) REFERENCES quotes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
-- Customers Management
CREATE TABLE IF NOT EXISTS customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    document VARCHAR(50),
    phone VARCHAR(50),
    email VARCHAR(255),
    address_line1 VARCHAR(255),
    address_line2 VARCHAR(255),
    address_line3 VARCHAR(255),
    zip_code VARCHAR(20),
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100),
    observations TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Shipments Manager
CREATE TABLE IF NOT EXISTS shipments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quote_id INT NULL,
    sender_id INT,
    recipient_id INT,
    sender_name VARCHAR(255),
    sender_phone VARCHAR(50),
    recipient_name VARCHAR(255),
    recipient_phone VARCHAR(50),
    status VARCHAR(100) DEFAULT 'Aguardando',
    delivery_person VARCHAR(255),
    shipment_photo VARCHAR(255),
    responsible_salesperson VARCHAR(100),
    shipment_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    received_by VARCHAR(100),
    quantity INT,
    dimensions VARCHAR(100), -- Format: AxLxC
    weight DECIMAL(10, 2),
    destination_country VARCHAR(100),
    freight_value DECIMAL(10, 2),
    payment_status ENUM('Aguardando Pagamento', 'Pago, aguardando confirmação', 'Pagamento confirmado', 'Faturado') DEFAULT 'Aguardando Pagamento',
    payment_type ENUM('PIX', 'Credito', 'Debito', 'Boleto', 'Faturado', 'Link', 'Pagamento internacional'),
    responsible_name VARCHAR(255),
    responsible_phone VARCHAR(50),
    description TEXT,
    declared_value DECIMAL(10, 2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (quote_id) REFERENCES quotes(id) ON DELETE SET NULL,
    FOREIGN KEY (sender_id) REFERENCES customers(id) ON DELETE SET NULL,
    FOREIGN KEY (recipient_id) REFERENCES customers(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
