# Exporta Fácil - Gestão de Logística de Exportação 🌍🦅

Sistema profissional para gestão de cotações, remessas e logística internacional.

## 🚀 Funcionalidades
- **Quadro Kanban**: Gestão visual de cotações e status de frete.
- **Gerador de Etiquetas**: Emissão de etiquetas de embarque PDF profissionais.
- **Gestão de Clientes**: Cadastro e histórico de movimentações por cliente.
- **Relatórios**: Analytics de faturamento e desempenho comercial.
- **PDV / Vendas**: Módulo para finalização de vendas de serviços de exportação.

## 🛠️ Tecnologias
- PHP (Lógica de servidor)
- MySQL (Banco de Dados PDO)
- Vanilla CSS & HTML5 (Design Moderno e Responsivo)
- FPDF (Geração de etiquetas PDF)

## ⚙️ Instalação
1. Clone o repositório ou baixe os arquivos.
2. Importe o arquivo SQL localizado em `sql/database.sql` para o seu banco MySQL.
3. Renomeie o arquivo `config/db.php.example` para `db.php`.
4. Edite o `db.php` com as credenciais do seu servidor.
5. Acesse o sistema pelo seu navegador.

---
*Desenvolvido com foco em agilidade e eficiência logística.*
