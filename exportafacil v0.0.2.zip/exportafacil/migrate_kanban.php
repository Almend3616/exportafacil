<?php
require_once 'config/db.php';
require_once 'includes/auth.php';
checkAdmin();

echo "<h2>Atualizando Banco de Dados...</h2>";

try {
    // Check if columns exist first to avoid errors
    $stmt = $pdo->query("SHOW COLUMNS FROM quotes LIKE 'paid_value'");
    if (!$stmt->fetch()) {
        $pdo->exec("ALTER TABLE quotes ADD COLUMN paid_value DECIMAL(10, 2) DEFAULT NULL AFTER total_price");
        echo "✅ Coluna 'paid_value' adicionada.<br>";
    } else {
        echo "ℹ️ Coluna 'paid_value' já existe.<br>";
    }

    $stmt = $pdo->query("SHOW COLUMNS FROM quotes LIKE 'is_duplicate'");
    if (!$stmt->fetch()) {
        $pdo->exec("ALTER TABLE quotes ADD COLUMN is_duplicate BOOLEAN DEFAULT FALSE AFTER paid_value");
        echo "✅ Coluna 'is_duplicate' adicionada.<br>";
    } else {
        echo "ℹ️ Coluna 'is_duplicate' já existe.<br>";
    }

    echo "<h3 style='color: green;'>Sucesso! Banco de Dados atualizado.</h3>";
    echo "<p><a href='kanban.php'>Ir para o Kanban</a></p>";

} catch (Exception $e) {
    echo "<p style='color: red;'>Erro: " . $e->getMessage() . "</p>";
}
?>
