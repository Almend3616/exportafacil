/* assets/js/shipment_label.js - TOTAL RESET */

$(document).ready(function() {
    let allCustomers = [];
    let allShipments = [];

    // 1. CARREGAMENTO DE DADOS
    function loadInitialData() {
        // Wait for both to finish so we can check URL for cross-linking safely
        $.when(
            $.get('api/get_customers.php'),
            $.get('api/get_shipments.php')
        ).done(function(custResp, shipResp) {
            if (custResp[0].success) allCustomers = custResp[0].customers;
            if (shipResp[0].success) allShipments = shipResp[0].shipments;
            
            checkUrlForPrefill();
        });
        loadHistory();
    }
    loadInitialData();

    function checkUrlForPrefill() {
        const urlParams = new URLSearchParams(window.location.search);
        
        // Tab routing
        const targetTab = urlParams.get('tab');
        if (targetTab === 'history') {
            $('.tab-btn[data-tab="history"]').trigger('click');
        }

        const prefillId = urlParams.get('prefill_shipment');
        if (prefillId) {
            triggerShipmentSelection(prefillId);
            // Optionally clean URL
            window.history.replaceState({}, document.title, window.location.pathname);
        }
    }

    // 2. NAVEGAÇÃO E TABS
    $('.tab-btn').on('click', function() {
        $('.tab-btn').removeClass('active');
        $(this).addClass('active');
        $('.tab-content').removeClass('active');
        $(`#tab-${$(this).data('tab')}`).addClass('active');
        if ($(this).data('tab') === 'history') loadHistory();
    });

    $('.btn-next-step').on('click', function() {
        const current = $(this).data('current');
        const next = $(this).data('next');
        const container = $(`#step-${current}`);
        
        if (validateSection(container)) {
            updateRightSummary(current);
            
            if (next === 'invoice') {
                populateInvoiceStep();
            }
            
            container.hide();
            $(`#step-${next}`).fadeIn();
            $(`#summary-${current}-card`).removeClass('empty').addClass('active');
        }
    });

    function populateInvoiceStep() {
        const r_nome = $('#r_nome').val().toUpperCase();
        const d_nome = $('#d_nome').val().toUpperCase();
        const waybill = $('#waybill').val();
        const dateStr = new Date().toLocaleDateString();
        const totalWeight = $('#total-weight-display').text();
        const totalVols = $('#total-vols').text();
        const content = $('#content').val() || 'GENERAL MERCHANDISE';
        const declared = window.currentFullShipmentData?.declared_value || 0;

        // Populate Invoice Step Fields
        $('#inv_step_number').text(waybill.replace(/\s/g, ''));
        $('#inv_step_date').text(dateStr);
        $('#inv_step_awb').text(waybill);
        
        $('#inv_step_shipper_name').text(r_nome);
        $('#inv_step_shipper_addr').text($('#r_l1').val().toUpperCase() + ', ' + $('#r_cidade').val().toUpperCase());
        $('#inv_step_shipper_country').text($('#r_pais').val().toUpperCase());
        $('#inv_step_shipper_tel').text($('#r_tel').val());
        $('#inv_step_shipper_tax').text($('#r_taxid').val());
        
        $('#inv_step_receiver_name').text(d_nome);
        $('#inv_step_receiver_addr').text($('#d_l1').val().toUpperCase() + ', ' + $('#d_cidade').val().toUpperCase());
        $('#inv_step_receiver_country').text($('#d_pais').val().toUpperCase());
        $('#inv_step_receiver_tel').text($('#d_tel').val());
        $('#inv_step_receiver_tax').text($('#d_taxid').val());

        $('#inv_step_reason').text($('#export_reason option:selected').text());
        $('#inv_step_incoterms').text($('#incoterms option:selected').text());
        
        $('#inv_step_total_weight').text(totalWeight + ' KG');
        $('#inv_step_total_vols').text(totalVols);
        
        const itemsBody = $('#inv_step_items_body').empty();
        itemsBody.append(`
            <tr>
                <td>${totalVols}</td>
                <td>${content.toUpperCase()}</td>
                <td>N/A</td>
                <td>BRAZIL</td>
                <td>USD ${(declared / (totalVols || 1)).toFixed(2)}</td>
                <td>USD ${parseFloat(declared).toFixed(2)}</td>
            </tr>
        `);
        $('#inv_step_subtotal, #inv_step_total_grand').text('USD ' + parseFloat(declared).toFixed(2));
        
        // Also update the hidden receipt fields just in case
        $('#rec_waybill').text(waybill);
        $('#rec_receiver').text(d_nome);
        $('#rec_country').text($('#d_pais').val().toUpperCase());
        $('#rec_date').text(dateStr);
        $('#rec_details').text(totalVols + ' VOLS - ' + content.toUpperCase());
        $('#rec_weight').text(totalWeight + ' KG');
        $('#rec_freight').text('R$ ' + (window.currentFullShipmentData?.freight_value || '0.00'));
        $('#rec_pay_method').text(window.currentFullShipmentData?.payment_type || 'PIX');

        // Update Label Preview Fields (Even if hidden, they are used for PDF generation)
        updateLabelPreviewFields();
    }

    function updateLabelPreviewFields() {
        $('#prev_r_nome').text($('#r_nome').val().toUpperCase());
        $('#prev_r_addr').text($('#r_l1').val().toUpperCase());
        $('#prev_r_city').text($('#r_cidade').val().toUpperCase() + ', ' + $('#r_estado').val().toUpperCase());
        $('#prev_r_country').text($('#r_pais').val().toUpperCase());
        $('#prev_r_tel').text('TEL: ' + $('#r_tel').val().toUpperCase());

        $('#prev_d_nome').text($('#d_nome').val().toUpperCase());
        $('#prev_d_addr').text($('#d_l1').val().toUpperCase());
        $('#prev_d_city').text($('#d_cidade').val().toUpperCase());
        $('#prev_d_country').text($('#d_pais').val().toUpperCase());
        $('#prev_d_tel').text('TEL: ' + $('#d_tel').val().toUpperCase());
        $('#prev_d_phone_label').text('PH: ' + $('#d_tel').val().toUpperCase());

        $('#prev_content').text($('#content').val().toUpperCase());
        $('#prev_weight').text($('#total-weight-display').text() + ' KG');
        $('#prev_piece').text('1 / ' + $('#total-vols').text());
        $('#prev_waybill_title').text('WAYBILL ' + $('#waybill').val());

        let dimsStr = "";
        $('.volume-row').each(function(idx) {
            const l = $(this).find('.vol-len').val() || 0;
            const w = $(this).find('.vol-wid').val() || 0;
            const h = $(this).find('.vol-hei').val() || 0;
            if(l > 0) dimsStr += `${l}x${w}x${h}; `;
        });
        $('#prev_dims').text(dimsStr.trim() || 'N/A');
        generateBarcodes();
    }

    $(document).on('click', '.btn-edit-summary', function() {
        $('.form-step-container').hide();
        $(`#step-${$(this).data('step')}`).fadeIn();
    });

    // 3. BUSCA DE CLIENTES E REMESSAS
    $('#shipperSearch, #customerSearch').on('input', function() {
        const type = $(this).attr('id') === 'shipperSearch' ? 'shipper' : 'receiver';
        const term = $(this).val().toLowerCase();
        const box = type === 'shipper' ? $('#shipper-search-results') : $('#search-results');
        
        if (term.length < 2) { box.hide(); return; }
        const filtered = allCustomers.filter(c => c.name.toLowerCase().includes(term)).slice(0, 10);
        
        box.empty().show();
        filtered.forEach(c => {
            box.append(`<div class="search-item search-row-customer" data-id="${c.id}" data-type="${type}"><span class="name">${c.name}</span><span class="info">${c.city || ''}</span></div>`);
        });
    });

    function fillCustomer(type, c) {
        if (!c) return;
        const p = type === 'shipper' ? '#r_' : '#d_';
        $(p + 'nome').val(c.name);
        $(p + 'l1').val(c.address_line1 || '');
        $(p + 'cidade').val(c.city || '');
        $(p + 'estado').val(c.state || '');
        $(p + (type === 'shipper' ? 'cep' : 'zip')).val(c.zip_code || '');
        $(p + 'pais').val(c.country || '');
        $(p + 'tel').val(c.phone || '');
        $(p + 'taxid').val(c.document || '');
    }

    $(document).on('click', '.search-row-customer', function() {
        const type = $(this).data('type');
        const c = allCustomers.find(item => item.id == $(this).data('id'));
        if (!c) return;
        fillCustomer(type, c);
        $('.search-results').hide();
    });

    // RESTORED SHIPMENT SEARCH
    $('#shipmentDataSearch').on('focus', function() {
        if ($(this).val().length === 0) {
            const f = allShipments.filter(s => s.status === 'Preparar Envio').slice(0, 10);
            renderShipmentRows(f);
        }
    });

    $('#shipmentDataSearch').on('input', function() {
        const t = $(this).val().toLowerCase();
        if (t.length === 0) {
            renderShipmentRows(allShipments.filter(s => s.status === 'Preparar Envio').slice(0, 10));
            return;
        }
        const f = allShipments.filter(s => s.id.toString().includes(t) || s.recipient_name.toLowerCase().includes(t)).slice(0, 10);
        renderShipmentRows(f);
    });

    function renderShipmentRows(filtered) {
        const box = $('#shipment-search-results');
        box.empty();
        if (filtered.length === 0) { box.hide(); return; }
        filtered.forEach(s => {
            const isTarget = s.status === 'Preparar Envio';
            box.append(`
                <div class="search-item search-row-shipment" data-id="${s.id}">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span class="name">#${s.id} - ${s.recipient_name}</span>
                        ${isTarget ? '<span style="font-size:0.7rem; background:rgba(99,102,241,0.2); color:#6366f1; padding:2px 6px; border-radius:4px;">Preparar Envio</span>' : ''}
                    </div>
                    <span class="info">${s.quantity} Vols | ${s.weight}kg | ${s.dimensions || ''}</span>
                </div>
            `);
        });
        box.show();
    }

    $(document).on('click', '.search-row-shipment', function() {
        triggerShipmentSelection($(this).data('id'));
    });

    function triggerShipmentSelection(id) {
        window.currentShipmentId = id; // Track for saving
        Swal.fire({
            title: 'Carregando Remessa...',
            info: 'Importando dados do remetente e destinatário.',
            timer: 1000,
            timerProgressBar: true,
            didOpen: () => { Swal.showLoading(); }
        });

        $.get('api/get_shipment_details_full.php', { id: id }, function(resp) {
            if (resp.success) {
                const s = resp.shipment;
                window.currentFullShipmentData = s; // Store for documents
                
                // Attempt to fill Shipper
                if (s.sender_id) {
                    const cShipper = allCustomers.find(item => item.id == s.sender_id);
                    if (cShipper) fillCustomer('shipper', cShipper);
                } else if (s.responsible_name) {
                    $('#r_nome').val(s.responsible_name);
                }

                // Attempt to fill Receiver
                if (s.recipient_id) {
                    const cReceiver = allCustomers.find(item => item.id == s.recipient_id);
                    if (cReceiver) fillCustomer('receiver', cReceiver);
                } else if (s.recipient_name) {
                    $('#d_nome').val(s.recipient_name);
                }

                // Fill Content
                if (s.description) {
                    if (!$('#content option[value="'+s.description.toUpperCase()+'"]').length) {
                        $('#content').append(`<option value="${s.description.toUpperCase()}">${s.description.toUpperCase()}</option>`);
                    }
                    $('#content').val(s.description.toUpperCase());
                }

                $('#weight').val(s.weight + ' kg').trigger('input');
                $('#total-weight-display').text(s.weight);
                $('#total-vols').text(s.quantity);
                
                $('#volumes-list').empty();
                if (s.dimensions) {
                    const dimsArray = s.dimensions.split(';');
                    dimsArray.forEach((d, idx) => {
                        const parts = d.toLowerCase().split('x');
                        addVolumeRow(idx + 1, 1, parts[0] || 0, parts[1] || 0, parts[2] || 0, (s.weight / s.quantity).toFixed(1));
                    });
                } else {
                    addVolumeRow(1, s.quantity || 1, 0, 0, 0, (s.weight / (s.quantity || 1)).toFixed(1));
                }
                
                $('#shipment-search-results').hide();
                updateTotals();

                // Skip directly to Step 3 so the user can review and generate
                setTimeout(() => {
                    updateRightSummary('shipper');
                    updateRightSummary('receiver');
                    $('.form-step-container').hide();
                    $('#step-shipment').fadeIn();
                    $('#summary-shipper-card').removeClass('empty').addClass('active');
                    $('#summary-receiver-card').removeClass('empty').addClass('active');

                    // Make sure the active tab correctly adjusts
                    $('.tab-btn').removeClass('active');
                    $('.tab-btn[data-tab="new"]').addClass('active');
                    $('.tab-content').removeClass('active');
                    $('#tab-new').addClass('active');
                }, 100);
            }
        });
    }

    // 4. LÓGICA DE VOLUMES
    $('#btn-add-volume').on('click', function() {
        const idx = $('#volumes-list .volume-row').length + 1;
        addVolumeRow(idx, 1, 0, 0, 0, 0);
    });

    $(document).on('click', '.btn-remove-vol', function() {
        $(this).closest('.volume-row').remove();
        updateTotals();
    });

    $(document).on('input', '.vol-qty, .vol-weight', updateTotals);

    function addVolumeRow(idx, qty, l, w, h, weight) {
        $('#volumes-list').append(`
            <div class="volume-row">
                <div class="vol-idx">${idx}</div>
                <div class="form-group"><input type="number" class="vol-qty" value="${qty}" min="1"></div>
                <div class="form-group"><input type="number" class="vol-len" value="${l}"></div>
                <div class="form-group"><input type="number" class="vol-wid" value="${w}"></div>
                <div class="form-group"><input type="number" class="vol-hei" value="${h}"></div>
                <div class="form-group"><input type="number" class="vol-weight" value="${weight}" step="0.1"></div>
                <button type="button" class="btn-remove-vol"><i class='bx bx-trash'></i></button>
            </div>
        `);
        $('#volumes-header').show();
        updateTotals();
    }

    function updateTotals() {
        let v = 0, w = 0;
        $('.volume-row').each(function() {
            const q = parseInt($(this).find('.vol-qty').val()) || 0;
            const weight = parseFloat($(this).find('.vol-weight').val()) || 0;
            v += q; w += (q * weight);
        });
        $('#total-vols').text(v);
        $('#total-weight-display').text(w.toFixed(1));
        $('#weight').val(w.toFixed(1) + ' kg');
    }

    // 5. GERAÇÃO DE PDF MULTI-PÁGINA (Label + Invoice + Receipt)
    window.generatePDF = function() {
        Swal.fire({
            title: 'Gerando Documentação...',
            text: 'Preparando arquivos de envio, invoice e recibo.',
            allowOutsideClick: false,
            didOpen: () => { Swal.showLoading(); }
        });

        const labelEl = document.getElementById('dhl-label');
        const invoiceEl = document.getElementById('invoice-doc-step'); // From Step 4
        const receiptEl = document.getElementById('receipt-doc');

        if (!labelEl || !invoiceEl) {
            Swal.fire('Erro', 'Elementos do documento não encontrados.', 'error');
            return;
        }

        const waybill = ($('#waybill').val() || '0000000000').replace(/\s/g, '');
        
        // ISOLATION LOGIC: Ensure only the currently captured element is visible to avoid spillover on Page 1
        const allDocs = [labelEl, invoiceEl, receiptEl];
        const hideOthers = (active) => {
            allDocs.forEach(d => { if(d) $(d).hide(); });
            $(active).show();
            if (active === labelEl) $(active).css('display', 'flex'); // Label uses flex
        };

        const opt = {
            margin: 0, 
            filename: 'DOCUMENTACAO_' + waybill + '.pdf',
            image: { type: 'jpeg', quality: 1.0 },
            html2canvas: { 
                scale: 2.0,
                useCORS: true, 
                letterRendering: true,
                logging: false
            },
            jsPDF: { unit: 'mm', format: 'a4', orientation: 'landscape' }
        };

        generateBarcodes();

        // Sequence: Page 1 (Label) -> Page 2 (Invoice) -> Page 3 (Receipt)
        hideOthers(labelEl);
        const worker = html2pdf().set(opt).from(labelEl).toPdf().get('pdf').then(function (pdf) {
            
            pdf.addPage();
            hideOthers(invoiceEl);
            return html2pdf().set(opt).from(invoiceEl).toContainer().toCanvas().toImg().get('img').then(function(img) {
                pdf.addImage(img.src, 'JPEG', 0, 0, 297, 210);
                
                pdf.addPage();
                hideOthers(receiptEl);
                return html2pdf().set(opt).from(receiptEl).toContainer().toCanvas().toImg().get('img').then(function(img2) {
                    pdf.addImage(img2.src, 'JPEG', 0, 0, 297, 210);
                });
            });
        });

        worker.save().then(() => {
            // Restore visibility for the UI (Step 4 shows the Invoice)
            hideOthers(invoiceEl);
            
            worker.output('blob').then(pdfBlob => {
                const formData = new FormData();
                formData.append('waybill', waybill);
                if (window.currentShipmentId) formData.append('shipment_id', window.currentShipmentId);
                formData.append('sender_name', $('#r_nome').val());
                formData.append('recipient_name', $('#d_nome').val());
                formData.append('destination_country', $('#d_pais').val());
                formData.append('status', 'Envio feito');
                formData.append('form_all', JSON.stringify($('#labelForm').serializeArray()));
                formData.append('pdf_file', pdfBlob, 'documentation.pdf');

                $.ajax({
                    url: 'api/save_shipment_label.php',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(resp) {
                        if(resp.success) {
                            Swal.fire({
                                title: 'Sucesso!',
                                text: 'Documentação completa gerada e salva com sucesso!',
                                icon: 'success',
                                confirmButtonText: 'Ver Histórico'
                            }).then(() => {
                                window.location.href = 'shipment_label.php?tab=history';
                            });
                        } else {
                            Swal.fire('Erro no Servidor', resp.message, 'error');
                        }
                    },
                    error: function() {
                        Swal.fire('Erro', 'Falha ao salvar no servidor. O PDF foi baixado localmente.', 'warning');
                    }
                });
            });
        });
    };

    function resetAfterSuccess() {
        setTimeout(() => {
            resetForm();
            loadHistory();
        }, 300);
    }

    $('#btn-final-save').on('click', generatePDF);

    // 6. UTILITÁRIOS
    function validateSection(section) {
        let valid = true;
        section.find('input[required], select[required]').each(function() {
            if (!$(this).val()) { valid = false; $(this).css('border-color', 'red'); }
            else { $(this).css('border-color', ''); }
        });
        return valid;
    }

    function updateRightSummary(step) {
        const card = $(`#summary-${step}-card`);
        let h = '';
        if (step === 'shipper') h = `<strong>${$('#r_nome').val()}</strong><br>${$('#r_cidade').val()}`;
        else if (step === 'receiver') h = `<strong>${$('#d_nome').val()}</strong><br>${$('#d_pais').val()}`;
        else if (step === 'shipment') h = `<strong>${$('#total-vols').text()} Vols</strong><br>${$('#total-weight-display').text()} kg`;
        
        card.find('.summary-card-body').html(`<div class="summary-info">${h}</div><button type="button" class="btn-edit-summary" data-step="${step}">Editar</button>`);
    }

    function generateBarcodes() {
        const wb = $('#waybill').val().replace(/\s/g, '');
        try { JsBarcode("#barcode-waybill", wb, { format: "CODE128", width: 2, height: 80, displayValue: false }); } catch(e){}
    }

    function generateAutomaticWaybill() {
        const n = Math.floor(Math.random() * 9000000000) + 1000000000;
        $('#waybill').val(n.toString().replace(/(\d{2})(\d{4})(\d{4})/, '$1 $2 $3'));
    }
    generateAutomaticWaybill();

    $('#btn-finalize-shipment').on('click', function() {
        generatePDF();
    });

    window.switchModalDoc = function(doc) {
        // Hide all docs
        $('#dhl-label, #invoice-doc, #receipt-doc').hide();
        
        // Show target doc
        if (doc === 'label') $('#dhl-label').css('display', 'flex');
        else if (doc === 'invoice') $('#invoice-doc').show();
        else if (doc === 'receipt') $('#receipt-doc').show();
        
        // Update tab buttons
        $('.modal-tab-btn').css({ 'border-color': 'var(--border)', 'color': 'var(--text-muted)' });
        const btnIdx = doc === 'label' ? 0 : (doc === 'invoice' ? 1 : 2);
        $('.modal-tab-btn').eq(btnIdx).css({ 'border-color': 'var(--accent)', 'color': 'var(--accent)' });
    };

    function resetForm() {
        $('#labelForm')[0].reset();
        $('#volumes-list').empty();
        $('#total-vols').text('0');
        $('#total-weight-display').text('0.0');
        $('.summary-card').addClass('empty').removeClass('active');
        $('.summary-card-body').text('Aguardando preenchimento...');
        $('.form-step-container').hide();
        $('#step-shipper').fadeIn();
        generateAutomaticWaybill();
        window.currentShipmentId = null;
    }

    $('#btn-cancel-review').on('click', () => $('#preview-modal').hide());

    function loadHistory() {
        console.log("HISTORY: Using Server-Side Rendering (Refresh page to update list)");
    }

    // Live Search for History
    $(document).on('keyup', '#historySearch', function() {
        const value = $(this).val().toLowerCase();
        $("#history-rows-container tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });

    // 7. HISTÓRICO ACTIONS (EXCLUIR, COPIAR, EDITAR)
    $(document).on('click', '.btn-delete-label', function() {
        const labelId = $(this).data('id');
        Swal.fire({
            title: 'Excluir Etiqueta?',
            text: "Esta ação apagará permanentemente a etiqueta gerada.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#ef4444',
            cancelButtonColor: '#94a3b8',
            confirmButtonText: 'Sim, excluir'
        }).then((result) => {
            if (result.isConfirmed) {
                $.post('api/delete_shipment_label.php', { id: labelId }, function(resp) {
                    if (resp.success) {
                        Swal.fire({ title: 'Excluído!', text: 'Etiqueta removida.', icon: 'success', toast: true, position: 'top-end', timer: 2000, showConfirmButton: false });
                        loadHistory();
                    } else {
                        Swal.fire('Erro', resp.message, 'error');
                    }
                }, 'json');
            }
        });
    });

    $(document).on('click', '.btn-copy-label', function() {
        const textToCopy = $(this).data('text');
        navigator.clipboard.writeText(textToCopy).then(() => {
            Swal.fire({ title: 'Copiado!', text: 'Dados da etiqueta copiados para a área de transferência.', icon: 'success', toast: true, position: 'top-end', timer: 2000, showConfirmButton: false });
        }).catch(err => {
            console.error('Falha ao copiar:', err);
        });
    });

    $(document).on('click', '.btn-edit-label', function() {
        const waybill = $(this).data('waybill');
        const formStr = $(this).attr('data-form');
        let formData = [];
        try { formData = JSON.parse(decodeURIComponent(formStr)); } catch(e){}

        if (formData && formData.length > 0) {
            Swal.fire({
                title: 'Editar Etiqueta',
                text: "Isso carregará os dados antigos no formulário. Você precisará gerar um novo PDF após editar.",
                icon: 'info',
                showCancelButton: true,
                confirmButtonText: 'Continuar'
            }).then((result) => {
                if (result.isConfirmed) {
                    resetForm();
                    $('#waybill').val(waybill);
                    
                    // Restore form values
                    formData.forEach(field => {
                        $(`[name="${field.name}"]`).val(field.value);
                    });
                    
                    // Because there are no dynamic volumes restored seamlessly right now, we just skip to step 1
                    $('.tab-btn[data-tab="new"]').trigger('click');
                    
                    Swal.fire({ title: 'Dados Carregados', text: 'Você pode agora revisar e ajustar os dados.', icon: 'success', toast: true, position: 'top-end', timer: 2000, showConfirmButton: false });
                }
            });
        } else {
            Swal.fire('Aviso', 'Nenhum dado original encontrado para esta etiqueta.', 'warning');
        }
    });
});
