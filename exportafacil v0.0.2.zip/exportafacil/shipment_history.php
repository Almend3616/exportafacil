<?php
require_once 'includes/auth.php';
checkLogin();
require_once 'config/db.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Histórico de Envios - ExportaFácil</title>
    <link rel="stylesheet" href="assets/css/shipment_label.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        body { background: #0a0a0f; color: #fff; padding: 40px; font-family: 'Inter', sans-serif; }
        .history-container { max-width: 1200px; margin: 0 auto; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; border-bottom: 1px solid #1e1e2d; padding-bottom: 20px; }
        .btn-back { background: #1e1e2d; color: #fff; text-decoration: none; padding: 10px 20px; border-radius: 8px; font-size: 0.9rem; transition: 0.3s; }
        .btn-back:hover { background: #2a2a3d; }
        .title h1 { margin: 0; font-size: 1.8rem; }
        .title p { color: #94a3b8; margin: 5px 0 0; }
        .modern-table { width: 100%; border-collapse: separate; border-spacing: 0 10px; margin-top: 20px; }
        .modern-table th { text-align: left; padding: 15px; color: #64748b; font-size: 0.8rem; text-transform: uppercase; }
        .modern-table tbody tr { background: #14141b; border: 1px solid #1e1e2d; }
        .modern-table td { padding: 15px; border-top: 1px solid #1e1e2d; border-bottom: 1px solid #1e1e2d; }
        .modern-table td:first-child { border-left: 1px solid #1e1e2d; border-radius: 12px 0 0 12px; color: #6366f1; font-weight: 700; font-family: monospace; }
        .modern-table td:last-child { border-right: 1px solid #1e1e2d; border-radius: 0 12px 12px 0; }
        .status-badge { padding: 5px 12px; border-radius: 6px; font-size: 0.75rem; font-weight: 700; background: rgba(16, 185, 129, 0.1); color: #10b981; }
        .btn-action { background: #1e1e2d; border: 1px solid #1e1e2d; color: #94a3b8; width: 34px; height: 34px; border-radius: 6px; display: inline-flex; align-items: center; justify-content: center; cursor: pointer; text-decoration: none; transition: 0.2s; }
        .btn-action:hover { background: #6366f1; color: #fff; }
        .btn-action.red:hover { background: #ef4444; }
        .empty-state { text-align: center; padding: 100px; background: #14141b; border-radius: 20px; border: 1px dashed #1e1e2d; }
    </style>
</head>
<body>
    <div class="history-container">
        <div class="header">
            <div class="title">
                <h1>Histórico de Documentos</h1>
                <p>Lista física de etiquetas e faturas geradas.</p>
            </div>
            <a href="shipment_label.php" class="btn-back"><i class='bx bx-plus'></i> Novo Envio</a>
        </div>

        <table class="modern-table">
            <thead>
                <tr>
                    <th>Waybill</th>
                    <th>Data</th>
                    <th>Destinatário</th>
                    <th>País</th>
                    <th>Status</th>
                    <th style="text-align: right;">Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php
                try {
                    $stmt = $pdo->query("SELECT * FROM shipment_labels ORDER BY created_at DESC LIMIT 100");
                    $found = false;
                    while ($row = $stmt->fetch()) {
                        $found = true;
                        $date = date('d/m/Y', strtotime($row['created_at']));
                        ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['waybill']); ?></td>
                            <td style="color: #94a3b8; font-size: 0.85rem;"><?php echo $date; ?></td>
                            <td style="font-weight: 600;"><?php echo htmlspecialchars($row['recipient_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['destination_country']); ?></td>
                            <td><span class="status-badge">SALVO</span></td>
                            <td style="text-align: right;">
                                <a href="<?php echo $row['file_path']; ?>" target="_blank" class="btn-action" title="Download PDF"><i class='bx bxs-file-pdf'></i></a>
                                <button class="btn-action red btn-delete" data-id="<?php echo $row['id']; ?>"><i class='bx bx-trash'></i></button>
                            </td>
                        </tr>
                        <?php
                    }
                    if (!$found) {
                        echo "<tr><td colspan='6'><div class='empty-state'><h3>Nenhum envio encontrado</h3><p>Os documentos aparecerão aqui assim que você finalizar um envio.</p></div></td></tr>";
                    }
                } catch (Exception $e) {
                    echo "<tr><td colspan='6' style='color:red;'>Erro ao acessar banco: " . $e->getMessage() . "</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).on('click', '.btn-delete', function() {
            const id = $(this).data('id');
            const row = $(this).closest('tr');
            Swal.fire({
                title: 'Excluir registro?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                confirmButtonText: 'Sim, apagar'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.post('api/delete_shipment_label.php', { id: id }, function(resp) {
                        if(resp.success) {
                            row.fadeOut();
                        } else {
                            Swal.fire('Erro', resp.message, 'error');
                        }
                    }, 'json');
                }
            });
        });
    </script>
</body>
</html>
