<?php
require_once 'includes/auth.php';
require_once 'config/db.php';
checkLogin();

// Basic stats
$totalQuotes = $pdo->query("SELECT COUNT(*) FROM quotes")->fetchColumn();
$wonQuotes = $pdo->query("SELECT COUNT(*) FROM quotes WHERE status = 'won'")->fetchColumn();
$lostQuotes = $pdo->query("SELECT COUNT(*) FROM quotes WHERE status = 'lost'")->fetchColumn();
$totalRevenue = $pdo->query("SELECT SUM(total_price) FROM quotes WHERE status = 'won'")->fetchColumn() ?: 0;

$conversionRate = $totalQuotes > 0 ? ($wonQuotes / $totalQuotes) * 100 : 0;
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios - Exporta Fácil</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0a0a0c;
            --card-bg: #111116;
            --accent: #6366f1;
            --text: #e2e8f0;
            --muted: #94a3b8;
            --border: rgba(255, 255, 255, 0.1);
        }
        body { background-color: var(--bg); color: var(--text); font-family: 'Poppins', sans-serif; padding: 2rem; margin: 0; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; border-bottom: 1px solid var(--border); padding-bottom: 1rem; }
        .header a { color: var(--accent); text-decoration: none; font-weight: 500; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; }
        .stat-card { background: var(--card-bg); border: 1px solid var(--border); border-radius: 16px; padding: 1.5rem; text-align: center; }
        .stat-card h3 { color: var(--muted); font-size: 0.9rem; margin-bottom: 0.5rem; }
        .stat-card .value { font-size: 2rem; font-weight: 700; color: #fff; }
        .stat-card .accent-value { color: var(--accent); }
    </style>
</head>
<body>
    <div class="header">
        <h1>Relatórios de Cotações</h1>
        <a href="index.php">Voltar ao Dashboard</a>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <h3>Total de Cotações</h3>
            <div class="value"><?php echo $totalQuotes; ?></div>
        </div>
        <div class="stat-card">
            <h3>Cotações Ganhas</h3>
            <div class="value" style="color: #22c55e;"><?php echo $wonQuotes; ?></div>
        </div>
        <div class="stat-card">
            <h3>Cotações Perdidas</h3>
            <div class="value" style="color: #ef4444;"><?php echo $lostQuotes; ?></div>
        </div>
        <div class="stat-card">
            <h3>Taxa de Conversão</h3>
            <div class="value accent-value"><?php echo number_format($conversionRate, 1); ?>%</div>
        </div>
        <div class="stat-card">
            <h3>Receita Confirmada</h3>
            <div class="value" style="color: #22c55e;">R$ <?php echo number_format($totalRevenue, 2, ',', '.'); ?></div>
        </div>
    </div>

    <div style="margin-top: 3rem; text-align: center; color: var(--muted);">
        <p>Mais detalhes e gráficos dinâmicos serão adicionados futuramente.</p>
    </div>
</body>
</html>
