<?php
require_once 'includes/auth.php';
require_once 'config/db.php';
checkLogin();

// Update Actions Logic
if (isset($_GET['action'], $_GET['id'])) {
    $id = (int)$_GET['id'];
    $action = $_GET['action'];
    
    if ($action === 'duplicate') {
        $stmt = $pdo->prepare("UPDATE quotes SET is_duplicate = 1 WHERE id = ?");
        $stmt->execute([$id]);
    } elseif ($action === 'win' && isset($_GET['paid'])) {
        $paid = (float)$_GET['paid'];
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("UPDATE quotes SET status = 'won', paid_value = ? WHERE id = ?");
            $stmt->execute([$paid, $id]);
            
            // Sync to linked shipment if exists
            $stmt = $pdo->prepare("UPDATE shipments SET freight_value = ?, payment_status = 'Pagamento confirmado' WHERE quote_id = ?");
            $stmt->execute([$paid, $id]);
            
            $pdo->commit();
        } catch (Exception $e) {
            $pdo->rollBack();
            die("Erro ao atualizar: " . $e->getMessage());
        }
    } elseif (in_array($action, ['pending', 'won', 'lost', 'follow_up'])) {
        $stmt = $pdo->prepare("UPDATE quotes SET status = ? WHERE id = ?");
        $stmt->execute([$action, $id]);
    }
    header("Location: kanban.php");
    exit;
}

// Filters
$where = ["is_duplicate = 0"];
$params = [];

if (!empty($_GET['user_id'])) {
    $where[] = "user_id = ?";
    $params[] = $_GET['user_id'];
}
if (!empty($_GET['date_start'])) {
    $where[] = "DATE(q.created_at) >= ?";
    $params[] = $_GET['date_start'];
}
if (!empty($_GET['date_end'])) {
    $where[] = "DATE(q.created_at) <= ?";
    $params[] = $_GET['date_end'];
}
if (!empty($_GET['search'])) {
    $search = "%" . $_GET['search'] . "%";
    $where[] = "(q.id LIKE ? OR q.client_name LIKE ? OR q.client_phone LIKE ?)";
    $params[] = $search;
    $params[] = $search;
    $params[] = $search;
}

$whereStr = implode(" AND ", $where);
$quotesQuery = $pdo->prepare("SELECT q.*, u.name as user_name FROM quotes q JOIN users u ON q.user_id = u.id WHERE $whereStr ORDER BY q.created_at DESC");
$quotesQuery->execute($params);
$allQuotes = $quotesQuery->fetchAll();

$users = $pdo->query("SELECT id, name FROM users WHERE status = 'approved' ORDER BY name")->fetchAll();

$statuses = [
    'contact' => 'Entrar em Contato (24h+)',
    'pending' => 'Recentes (Em Aberto)',
    'follow_up' => 'Acompanhamento',
    'won' => 'Cotação Fechada',
    'lost' => 'Perdida'
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Follow-Up (Kanban) - Exporta Fácil</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/boxicons/css/boxicons.min.css" rel="stylesheet">
    <style>
        :root {
            --bg: #050507;
            --column-bg: rgba(17, 17, 22, 0.6);
            --card-bg: #16161c;
            --accent: #6366f1;
            --contact: #f97316;
            --pending: #eab308;
            --follow: #6366f1;
            --won: #22c55e;
            --lost: #ef4444;
            --text: #e2e8f0;
            --muted: #94a3b8;
            --border: rgba(255, 255, 255, 0.08);
        }
        body { 
            background: var(--bg); color: var(--text); font-family: 'Poppins', sans-serif; padding: 1.5rem; margin: 0; 
            background-image: 
                radial-gradient(circle at 10% 10%, rgba(99, 102, 241, 0.05) 0%, transparent 40%),
                radial-gradient(circle at 90% 90%, rgba(168, 85, 247, 0.05) 0%, transparent 40%);
            min-height: 100vh;
        }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; }
        .header h1 { font-size: 1.5rem; font-weight: 700; margin: 0; }
        .header-links { display: flex; gap: 1rem; }
        .header-links a { background: rgba(255,255,255,0.03); color: var(--text); padding: 0.6rem 1.2rem; border-radius: 12px; border: 1px solid var(--border); text-decoration: none; font-size: 0.9rem; transition: all 0.3s; }
        .header-links a:hover { background: var(--accent); border-color: var(--accent); }

        .filters { background: var(--column-bg); border: 1px solid var(--border); border-radius: 16px; padding: 1.2rem; margin-bottom: 2rem; display: flex; gap: 1rem; flex-wrap: wrap; align-items: flex-end; }
        .filter-group { display: flex; flex-direction: column; gap: 0.4rem; }
        .filter-group label { font-size: 0.75rem; color: var(--muted); text-transform: uppercase; font-weight: 600; }
        .filter-group select, .filter-group input { background: #1a1a20; border: 1px solid var(--border); border-radius: 8px; color: #fff; padding: 0.5rem 0.8rem; outline: none; }
        .btn-filter { background: var(--accent); color: #fff; border: none; border-radius: 8px; padding: 0.6rem 1.5rem; font-weight: 600; cursor: pointer; transition: 0.3s; }
        .btn-filter:hover { opacity: 0.9; transform: translateY(-1px); }

        .kanban-board { display: flex; gap: 1rem; overflow-x: auto; padding-bottom: 2rem; min-height: calc(100vh - 250px); }
        .kanban-column { background: var(--column-bg); border-radius: 20px; padding: 1rem; min-width: 300px; flex: 1; border: 1px solid var(--border); backdrop-filter: blur(10px); }
        .column-header { font-weight: 600; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.6rem; font-size: 0.95rem; color: #eee; }
        .quote-card { background: var(--card-bg); border: 1px solid var(--border); border-radius: 16px; padding: 1.2rem; margin-bottom: 1rem; transition: all 0.3s; position: relative; }
        .quote-card:hover { transform: translateY(-4px); border-color: var(--accent); box-shadow: 0 10px 20px rgba(0,0,0,0.3); }
        .quote-client { font-weight: 700; font-size: 1.05rem; display: block; margin-bottom: 0.5rem; color: #fff; }
        .quote-info { font-size: 0.8rem; color: var(--muted); margin-bottom: 0.4rem; display: flex; align-items: center; gap: 0.4rem; }
        .quote-price { font-weight: 800; color: var(--accent); display: block; margin-top: 1rem; font-size: 1.1rem; }
        .quote-id { font-size: 0.75rem; color: var(--accent); font-weight: 700; margin-bottom: 0.2rem; display: block; opacity: 0.8; }
        .quote-user { position: absolute; top: 1.2rem; right: 1.2rem; font-size: 0.7rem; background: var(--border); padding: 2px 8px; border-radius: 100px; color: var(--muted); }

        .quote-actions { display: flex; gap: 0.8rem; border-top: 1px solid var(--border); padding-top: 1rem; margin-top: 1rem; justify-content: center; }
        .quote-actions a { color: var(--muted); font-size: 1.3rem; text-decoration: none; transition: 0.3s; display: flex; }
        .quote-actions a:hover { color: var(--accent); transform: scale(1.2); }
        .quote-actions a.btn-win-modal:hover { color: var(--won); }
        .quote-actions a.btn-dup:hover { color: #888; }
        
        .badge { width: 10px; height: 10px; border-radius: 50%; box-shadow: 0 0 10px currentColor; }
        .badge-contact { background: var(--contact); color: var(--contact); }
        .badge-pending { background: var(--pending); color: var(--pending); }
        .badge-follow { background: var(--follow); color: var(--follow); }
        .badge-won { background: var(--won); color: var(--won); }
        .badge-lost { background: var(--lost); color: var(--lost); }

        /* Modal styling */
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); backdrop-filter: blur(5px); align-items: center; justify-content: center; }
        .modal-content { background: var(--card-bg); border: 1px solid var(--border); border-radius: 24px; padding: 2rem; width: 90%; max-width: 400px; }
        .modal-header { margin-bottom: 1.5rem; border-bottom: 1px solid var(--border); padding-bottom: 1rem; }
        .modal-header h2 { margin: 0; font-size: 1.2rem; color: var(--won); }
        .shipment-link-item { 
            background: rgba(255,255,255,0.03); 
            border: 1px solid var(--border); 
            border-radius: 12px; 
            padding: 1rem; 
            margin-bottom: 0.8rem; 
            cursor: pointer; 
            transition: 0.3s;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .shipment-link-item:hover { background: var(--accent); border-color: var(--accent); }
        .shipment-link-item .info { display: flex; flex-direction: column; }
        .shipment-link-item .id { font-weight: 700; font-size: 0.8rem; color: var(--muted); }
        .shipment-link-item .client { font-weight: 600; font-size: 0.95rem; }

        .price-suggestions { display: flex; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 1rem; }
        .price-chip { 
            background: rgba(255,255,255,0.05); 
            border: 1px solid var(--border); 
            padding: 4px 10px; 
            border-radius: 6px; 
            font-size: 0.8rem; 
            cursor: pointer; 
            transition: 0.3s;
            color: var(--muted);
        }
        .price-chip:hover { background: var(--accent); color: #fff; border-color: var(--accent); }
    </style>
</head>
<body>
    <div class="header">
        <h1><i class='bx bx-git-branch'></i> Follow-Up Kanban</h1>
        <div class="header-links">
            <a href="quote.php"><i class='bx bx-plus'></i> Nova Cotação</a>
            <a href="index.php">Dashboard</a>
        </div>
    </div>

    <form class="filters">
        <div class="filter-group">
            <label>Usuário</label>
            <select name="user_id">
                <option value="">Todos</option>
                <?php foreach($users as $u): ?>
                    <option value="<?php echo $u['id']; ?>" <?php echo (isset($_GET['user_id']) && $_GET['user_id'] == $u['id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($u['name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="filter-group">
            <label>Data Inicial</label>
            <input type="date" name="date_start" value="<?php echo $_GET['date_start'] ?? ''; ?>">
        </div>
        <div class="filter-group">
            <label>Data Final</label>
            <input type="date" name="date_end" value="<?php echo $_GET['date_end'] ?? ''; ?>">
        </div>
        <div class="filter-group">
            <label>Buscar (ID, Nome, Tel)</label>
            <input type="text" name="search" placeholder="Ex: 00123" value="<?php echo $_GET['search'] ?? ''; ?>">
        </div>
        <button type="submit" class="btn-filter"><i class='bx bx-filter-alt'></i> Filtrar</button>
        <a href="kanban.php" style="color: var(--muted); font-size: 0.8rem; text-decoration: none; margin-left: 0.5rem;">Limpar</a>
    </form>

    <div class="kanban-board">
        <?php foreach ($statuses as $statusKey => $statusLabel): ?>
        <div class="kanban-column">
            <div class="column-header">
                <div class="badge badge-<?php echo $statusKey; ?>"></div>
                <?php echo $statusLabel; ?>
            </div>
            
            <div class="cards-container">
                <?php 
                foreach ($allQuotes as $q): 
                    $createdAtStr = $q['created_at'];
                    $createdAt = strtotime($createdAtStr);
                    $isOld = (time() - $createdAt) > 86400; // 24h
                    
                    $targetColumn = $q['status'];
                    if ($q['status'] === 'pending' && $isOld) {
                        $targetColumn = 'contact';
                    }

                    if ($targetColumn !== $statusKey) continue; 
                ?>
                <div class="quote-card">
                    <span class="quote-id">#<?php echo str_pad($q['id'], 5, '0', STR_PAD_LEFT); ?></span>
                    <span class="quote-user"><?php echo htmlspecialchars($q['user_name']); ?></span>
                    <span class="quote-client"><?php echo htmlspecialchars($q['client_name']); ?></span>
                    <span class="quote-info"><i class='bx bxs-map-pin'></i> <?php echo htmlspecialchars($q['origin']); ?> ➔ <?php echo htmlspecialchars($q['destination']); ?></span>
                    <span class="quote-info"><i class='bx bx-calendar'></i> <?php echo date('d/m/Y H:i', $createdAt); ?></span>
                    
                    <?php if($q['paid_value']): ?>
                        <span class="quote-price" style="color: var(--won)">Confirmado: R$ <?php echo number_format($q['paid_value'], 2, ',', '.'); ?></span>
                    <?php else: ?>
                        <span class="quote-price">ORÇADO: R$ <?php echo number_format($q['total_price'], 2, ',', '.'); ?></span>
                    <?php endif; ?>
                    
                    <div class="quote-actions">
                        <a href="shipments.php?quote_id=<?php echo $q['id']; ?>" title="Gerar Remessa"><i class='bx bxs-ship'></i></a>
                        <a href="#" onclick="openLinkModal(<?php echo $q['id']; ?>)" title="Vincular a Remessa Existente"><i class='bx bx-link'></i></a>
                        <a href="kanban.php?action=follow_up&id=<?php echo $q['id']; ?>" title="Acompanhamento"><i class='bx bx-timer'></i></a>
                        <a href="#" onclick="openWinModal(<?php echo $q['id']; ?>, <?php echo $q['total_price']; ?>)" title="Fechar Frete" class="btn-win-modal"><i class='bx bx-check-double'></i></a>
                        <a href="kanban.php?action=lost&id=<?php echo $q['id']; ?>" title="Perdida"><i class='bx bx-x-circle'></i></a>
                        <a href="kanban.php?action=duplicate&id=<?php echo $q['id']; ?>" title="Marcar como Duplicada" class="btn-dup" onclick="return confirm('Marcar esta cotação como duplicada?')"><i class='bx bx-copy'></i></a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Win/Close Modal -->
    <div id="winModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2><i class='bx bx-trophy'></i> Fechar Frete</h2>
            </div>
            <p style="font-size: 0.9rem; color: var(--muted); margin-bottom: 1.5rem;">Confirme o valor final pago pelo cliente para concluir esta venda.</p>
            
            <label style="font-size: 0.75rem; color: var(--muted); text-transform: uppercase; font-weight: 600; display: block; margin-bottom: 0.5rem;">Opções da Cotação</label>
            <div id="win-price-suggestions" class="price-suggestions">
                <!-- Suggestions will be injected here -->
            </div>

            <div class="filter-group" style="margin-bottom: 1.5rem;">
                <label>Valor Pago (R$)</label>
                <input type="number" step="0.01" id="paid_value_input" style="width: 100%; box-sizing: border-box;">
            </div>
            <div style="display: flex; gap: 1rem;">
                <button class="btn-filter" onclick="confirmWin()" style="flex: 1; background: var(--won);">Confirmar</button>
                <button class="btn-filter" onclick="closeWinModal()" style="flex: 1; background: var(--border);">Cancelar</button>
            </div>
        </div>
    </div>

    <!-- Link to Shipment Modal -->
    <div id="linkModal" class="modal">
        <div class="modal-content" style="max-width: 500px;">
            <div class="modal-header">
                <h2><i class='bx bx-link'></i> Vincular à Remessa</h2>
            </div>
            <p style="font-size: 0.9rem; color: var(--muted); margin-bottom: 1.5rem;">Selecione uma remessa existente para vincular a esta cotação.</p>
            <div id="shipments_list" style="max-height: 400px; overflow-y: auto;">
                <!-- Shipments will be listed here -->
                <p style="text-align: center; color: var(--muted);">Carregando remessas...</p>
            </div>
            <div style="margin-top: 1.5rem;">
                <button class="btn-filter" onclick="closeLinkModal()" style="width: 100%; background: var(--border);">Cancelar</button>
            </div>
        </div>
    </div>

    <script>
        let currentQuoteId = null;

        async function openWinModal(id, currentPrice) {
            currentQuoteId = id;
            document.getElementById('paid_value_input').value = currentPrice;
            document.getElementById('winModal').style.display = 'flex';
            
            const suggestions = document.getElementById('win-price-suggestions');
            suggestions.innerHTML = '<span style="font-size: 0.8rem; color: var(--muted);">Carregando opções...</span>';

            try {
                const response = await fetch(`api/get_quote_details.php?id=${id}`);
                const data = await response.json();
                if (data.success) {
                    suggestions.innerHTML = '';
                    if (data.quote.freight_options) {
                        const options = JSON.parse(data.quote.freight_options);
                        options.forEach(opt => {
                            const chip = document.createElement('div');
                            chip.className = 'price-chip';
                            chip.innerText = `R$ ${parseFloat(opt.price).toFixed(2)}`;
                            chip.onclick = () => {
                                document.getElementById('paid_value_input').value = opt.price;
                            };
                            suggestions.appendChild(chip);
                        });
                    } else {
                        suggestions.innerHTML = '<span style="font-size: 0.8rem; color: var(--muted);">Sem opções extras.</span>';
                    }
                }
            } catch (e) {
                suggestions.innerHTML = '';
            }
        }

        function closeWinModal() {
            document.getElementById('winModal').style.display = 'none';
        }

        function confirmWin() {
            const val = document.getElementById('paid_value_input').value;
            window.location.href = `kanban.php?action=win&id=${currentQuoteId}&paid=${val}`;
        }
        
        // Close modal if clicked outside
        window.onclick = function(event) {
            const winModal = document.getElementById('winModal');
            const linkModal = document.getElementById('linkModal');
            if (event.target == winModal) closeWinModal();
            if (event.target == linkModal) closeLinkModal();
        }

        async function openLinkModal(quoteId) {
            currentQuoteId = quoteId;
            document.getElementById('linkModal').style.display = 'flex';
            const list = document.getElementById('shipments_list');
            list.innerHTML = '<p style="text-align: center; color: var(--muted);">Carregando remessas...</p>';

            try {
                const response = await fetch('api/get_shipments.php');
                const data = await response.json();
                
                if (data.success) {
                    if (data.shipments.length === 0) {
                        list.innerHTML = '<p style="text-align: center; color: var(--muted);">Nenhuma remessa encontrada.</p>';
                        return;
                    }
                    
                    list.innerHTML = '';
                    data.shipments.forEach(s => {
                        const item = document.createElement('div');
                        item.className = 'shipment-link-item';
                        item.onclick = () => confirmLink(s.id);
                        
                        const date = new Date(s.shipment_date).toLocaleDateString('pt-BR');
                        
                        item.innerHTML = `
                            <div class="info">
                                <span class="id">#${String(s.id).padStart(5, '0')} - ${date}</span>
                                <span class="client">${s.recipient_name || 'Sem nome'}</span>
                            </div>
                            <i class='bx bx-chevron-right'></i>
                        `;
                        list.appendChild(item);
                    });
                } else {
                    list.innerHTML = `<p style="text-align: center; color: var(--lost);">${data.message}</p>`;
                }
            } catch (error) {
                list.innerHTML = '<p style="text-align: center; color: var(--lost);">Erro ao carregar remessas.</p>';
            }
        }

        function closeLinkModal() {
            document.getElementById('linkModal').style.display = 'none';
        }

        async function confirmLink(shipmentId) {
            if (!confirm('Deseja vincular esta cotação a esta remessa?')) return;

            try {
                const response = await fetch('api/link_quote_shipment.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        quote_id: currentQuoteId,
                        shipment_id: shipmentId
                    })
                });
                
                const result = await response.json();
                alert(result.message);
                if (result.success) {
                    location.reload();
                }
            } catch (error) {
                alert('Erro ao processar o vínculo.');
            }
        }
    </script>
</body>
</html>
