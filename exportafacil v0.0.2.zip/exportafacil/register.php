<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exporta Fácil – Criar Conta</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/auth.css">
</head>
<body>
    <div class="login-container">
        <div class="brand-section">
            <h2>Participe do Exporta Fácil</h2>
            <p>Cadastre-se para começar sua jornada logística.</p>
        </div>

        <div class="login-section">
            <div class="login-form">
                <h1>Criar Conta</h1>
                <p>Preencha os dados abaixo para se cadastrar.</p>

                <div class="input-box">
                    <input type="text" id="fullname" placeholder="Nome Completo" required>
                    <i class="bx bxs-id-card"></i>
                </div>

                <div class="input-box">
                    <input type="text" id="username" placeholder="Usuário" required>
                    <i class="bx bxs-user"></i>
                </div>

                <div class="input-box">
                    <input type="password" id="password" placeholder="Senha" required>
                    <i class="bx bxs-lock-alt"></i>
                </div>

                <button type="button" class="btn" onclick="register()">Cadastrar</button>

                <div class="register-link">
                    Já tem uma conta? <a href="login.php">Faça login</a>
                </div>
            </div>
        </div>
    </div>

    <script>
        async function register() {
            const fullname = document.getElementById("fullname").value.trim();
            const username = document.getElementById("username").value.trim();
            const password = document.getElementById("password").value.trim();

            if (!fullname || !username || !password) {
                alert("Por favor, preencha todos os campos.");
                return;
            }

            try {
                const response = await fetch("api/register.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ fullname, username, password })
                });

                const result = await response.json();
                if (result.success) {
                    alert("Conta criada com sucesso! " + (result.isAdmin ? "Você é o administrador." : "Aguarde a aprovação do administrador."));
                    window.location.href = "login.php";
                } else {
                    alert(result.message);
                }
            } catch (error) {
                alert("Erro ao conectar ao servidor.");
            }
        }
    </script>
</body>
</html>
