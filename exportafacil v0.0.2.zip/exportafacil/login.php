<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exporta Fácil – Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/auth.css">
</head>
<body>
    <div class="login-container">
        <div class="brand-section">
            <h2>Exporta Fácil</h2>
            <p>Sua logística inteligente começa aqui.</p>
        </div>

        <div class="login-section">
            <div class="login-form">
                <h1>Bem-vindo!</h1>
                <p>Faça login para acessar o sistema.</p>

                <div class="input-box">
                    <input type="text" id="username" placeholder="Usuário" required>
                    <i class="bx bxs-user"></i>
                </div>

                <div class="input-box">
                    <input type="password" id="password" placeholder="Senha" required>
                    <i class="bx bxs-lock-alt"></i>
                </div>

                <div class="options">
                    <div class="remember-me">
                        <input type="checkbox" id="showPassword" onclick="togglePass()">
                        <label for="showPassword">Mostrar senha</label>
                    </div>
                    <div class="forgot-password">
                        <a href="#">Esqueci minha senha</a>
                    </div>
                </div>

                <button type="button" class="btn" onclick="login()">Entrar</button>

                <div class="register-link">
                    Não tem uma conta? <a href="register.php">Crie uma agora</a>
                </div>
            </div>
        </div>
    </div>

    <script>
        async function login() {
            const username = document.getElementById("username").value.trim();
            const password = document.getElementById("password").value.trim();

            if (!username || !password) {
                alert("Por favor, preencha todos os campos.");
                return;
            }

            try {
                const response = await fetch("api/login.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ username, password })
                });

                const result = await response.json();
                if (result.success) {
                    window.location.href = "index.php";
                } else {
                    alert(result.message);
                }
            } catch (error) {
                alert("Erro ao conectar ao servidor.");
            }
        }

        function togglePass() {
            const inpt = document.getElementById("password");
            inpt.type = inpt.type === "password" ? "text" : "password";
        }
    </script>
</body>
</html>
