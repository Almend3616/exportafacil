<?php
require_once 'includes/auth.php';
require_once 'config/db.php';
checkLogin();

// Fetch pending users count if admin
$pendingCount = 0;
if (isAdmin()) {
    $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE status = 'pending' AND role = 'user'");
    $pendingCount = $stmt->fetchColumn();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exporta Fácil – Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/auth.css"> <!-- Reusing some styles for consistency -->
    <style>
        body {
            background-color: #0a0a0c;
            color: #e2e8f0;
            display: block;
            padding: 2rem;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .nav-links a {
            color: #6366f1;
            text-decoration: none;
            margin-left: 1.5rem;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .badge-count {
            background: #ef4444;
            color: white;
            font-size: 0.7rem;
            padding: 2px 6px;
            border-radius: 10px;
            font-weight: 700;
            min-width: 14px;
            text-align: center;
        }
        .card {
            background: #111116;
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 16px;
            padding: 2rem;
            margin-top: 1rem;
            transition: all 0.3s ease;
        }
        .card:hover { border-color: #6366f1; transform: translateY(-3px); box-shadow: 0 10px 20px rgba(0,0,0,0.4); }
        .btn-logout {
            background: #ef4444;
            color: white;
            padding: 8px 16px;
            border-radius: 8px;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Dashboard - Exporta Fácil</h1>
        <div class="nav-links">
            <span>Olá, <?php echo htmlspecialchars($_SESSION['name']); ?></span>
            <?php if (isAdmin()): ?>
                <a href="user_management.php">
                    Gerenciar Usuários
                    <?php if ($pendingCount > 0): ?>
                        <span class="badge-count"><?php echo $pendingCount; ?></span>
                    <?php endif; ?>
                </a>
            <?php endif; ?>
            <a href="logout.php" class="btn-logout">Sair</a>
        </div>
    </div>

    <div class="card">
        <h2>Bem-vindo ao sistema de exportação.</h2>
        <p>Abaixo estão as ferramentas organizadas por categorias.</p>
        
        <!-- Camada: Cotação -->
        <h3 style="margin-top: 2rem; border-left: 4px solid #6366f1; padding-left: 10px; color: #6366f1;">Cotação</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-top: 1rem;">
            <a href="quote.php" class="card" style="text-decoration: none; text-align: center; border-color: rgba(99, 102, 241, 0.3); margin-top: 0;">
                <i class='bx bx-calculator' style="font-size: 2.5rem; color: #6366f1;"></i>
                <h3 style="margin-top: 0.5rem; color: #fff;">Nova Cotação</h3>
            </a>
            <a href="kanban.php" class="card" style="text-decoration: none; text-align: center; border-color: rgba(34, 197, 94, 0.3); margin-top: 0;">
                <i class='bx bx-columns' style="font-size: 2.5rem; color: #22c55e;"></i>
                <h3 style="margin-top: 0.5rem; color: #fff;">Follow-Up (Kanban)</h3>
            </a>
            <?php if (isAdmin()): ?>
                <a href="carriers.php" class="card" style="text-decoration: none; text-align: center; border-color: rgba(234, 179, 8, 0.3); margin-top: 0;">
                    <i class='bx bxs-truck' style="font-size: 2.5rem; color: #eab308;"></i>
                    <h3 style="margin-top: 0.5rem; color: #fff;">Transportadoras</h3>
                </a>
            <?php endif; ?>
        </div>

        <!-- Camada: Remessas -->
        <h3 style="margin-top: 2rem; border-left: 4px solid #a855f7; padding-left: 10px; color: #a855f7;">Remessas</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-top: 1rem;">
            <a href="shipments.php" class="card" style="text-decoration: none; text-align: center; border-color: rgba(168, 85, 247, 0.3); margin-top: 0;">
                <i class='bx bxs-ship' style="font-size: 2.5rem; color: #a855f7;"></i>
                <h3 style="margin-top: 0.5rem; color: #fff;">Gerenciador de Remessas</h3>
            </a>
        </div>

        <!-- Camada: Clientes -->
        <h3 style="margin-top: 2rem; border-left: 4px solid #3b82f6; padding-left: 10px; color: #3b82f6;">Clientes</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-top: 1rem;">
            <a href="customers.php" class="card" style="text-decoration: none; text-align: center; border-color: rgba(59, 130, 246, 0.3); margin-top: 0;">
                <i class='bx bxs-user-detail' style="font-size: 2.5rem; color: #3b82f6;"></i>
                <h3 style="margin-top: 0.5rem; color: #fff;">Gerenciar Clientes</h3>
            </a>
        </div>

        <!-- Camada: Envios -->
        <h3 style="margin-top: 2rem; border-left: 4px solid #ef4444; padding-left: 10px; color: #ef4444;">Envios</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-top: 1rem;">
            <a href="shipment_label.php" class="card" style="text-decoration: none; text-align: center; border-color: rgba(239, 68, 68, 0.3); margin-top: 0;">
                <i class='bx bxs-printer' style="font-size: 2.5rem; color: #ef4444;"></i>
                <h3 style="margin-top: 0.5rem; color: #fff;">Gerar Etiqueta</h3>
            </a>
        </div>

        <?php if (isAdmin()): ?>
        <!-- Camada: Administração -->
        <h3 style="margin-top: 2rem; border-left: 4px solid #f97316; padding-left: 10px; color: #f97316;">Administração</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-top: 1rem;">
            <a href="user_management.php" class="card" style="text-decoration: none; text-align: center; border-color: rgba(249, 115, 22, 0.3); margin-top: 0; position: relative;">
                <?php if ($pendingCount > 0): ?>
                    <span class="badge-count" style="position: absolute; top: 15px; right: 15px; font-size: 0.9rem; padding: 4px 10px;"><?php echo $pendingCount; ?></span>
                <?php endif; ?>
                <i class='bx bxs-user-account' style="font-size: 2.5rem; color: #f97316;"></i>
                <h3 style="margin-top: 0.5rem; color: #fff;">Gerenciar Usuários</h3>
            </a>
            <a href="carriers.php" class="card" style="text-decoration: none; text-align: center; border-color: rgba(234, 179, 8, 0.3); margin-top: 0;">
                <i class='bx bxs-truck' style="font-size: 2.5rem; color: #eab308;"></i>
                <h3 style="margin-top: 0.5rem; color: #fff;">Transportadoras</h3>
            </a>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>
