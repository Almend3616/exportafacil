<?php
require_once 'includes/auth.php';
require_once 'config/db.php';
checkAdmin();

if (!isset($_GET['method_id'])) {
    header("Location: carriers.php");
    exit;
}

$method_id = (int)$_GET['method_id'];
$method = $pdo->prepare("SELECT sm.*, c.name as carrier_name FROM shipping_methods sm JOIN carriers c ON sm.carrier_id = c.id WHERE sm.id = ?");
$method->execute([$method_id]);
$method = $method->fetch();

if (!$method) {
    header("Location: carriers.php");
    exit;
}

// Handle Rate CRUD
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_rate'])) {
        $weight = (float)$_POST['weight_up_to'];
        $price = (float)$_POST['price'];
        $stmt = $pdo->prepare("INSERT INTO shipping_rates (method_id, weight_up_to, price) VALUES (?, ?, ?)");
        $stmt->execute([$method_id, $weight, $price]);
    } elseif (isset($_POST['delete_rate'])) {
        $id = (int)$_POST['rate_id'];
        $stmt = $pdo->prepare("DELETE FROM shipping_rates WHERE id = ?");
        $stmt->execute([$id]);
    }
    header("Location: rates.php?method_id=$method_id");
    exit;
}

$rates = $pdo->prepare("SELECT * FROM shipping_rates WHERE method_id = ? ORDER BY weight_up_to ASC");
$rates->execute([$method_id]);
$rates = $rates->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Preços - <?php echo htmlspecialchars($method['name']); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { background-color: #0a0a0c; color: #e2e8f0; font-family: 'Poppins', sans-serif; padding: 2rem; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; border-bottom: 1px solid rgba(255, 255, 255, 0.1); padding-bottom: 1rem; }
        .header a { color: #6366f1; text-decoration: none; font-weight: 500; }
        .card { background: #111116; border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 16px; padding: 1.5rem; margin-bottom: 2rem; }
        .form-inline { display: flex; gap: 1rem; align-items: flex-end; }
        .form-group { flex: 1; }
        .form-group label { display: block; margin-bottom: 0.5rem; color: #94a3b8; }
        .form-group input { width: 100%; padding: 0.75rem; background: #1e1e24; border: 1px solid #333; border-radius: 8px; color: #fff; }
        .btn { border: none; padding: 0.75rem 1.5rem; border-radius: 8px; cursor: pointer; font-weight: 600; }
        .btn-primary { background: #6366f1; color: #fff; }
        .btn-danger { background: #ef4444; color: #fff; padding: 0.4rem 0.8rem; border-radius: 4px; }
        table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
        th, td { padding: 1rem; text-align: left; border-bottom: 1px solid rgba(255, 255, 255, 0.05); }
    </style>
</head>
<body>
    <div class="header">
        <h1>Tabela de Preços: <?php echo htmlspecialchars($method['carrier_name'] . " - " . $method['name']); ?></h1>
        <a href="carriers.php">Voltar para Transportadoras</a>
    </div>

    <div class="card">
        <h2>Adicionar Novo Patamar de Peso</h2>
        <form method="POST" class="form-inline">
            <div class="form-group">
                <label>Peso Até (kg)</label>
                <input type="number" name="weight_up_to" step="0.01" required placeholder="Ex: 0.5">
            </div>
            <div class="form-group">
                <label>Preço (R$)</label>
                <input type="number" name="price" step="0.01" required placeholder="Ex: 120.50">
            </div>
            <button type="submit" name="add_rate" class="btn btn-primary">Salvar</button>
        </form>
    </div>

    <div class="card">
        <h2>Tabela de Valores</h2>
        <table>
            <thead>
                <tr>
                    <th>Até o Peso (Kg)</th>
                    <th>Valor (R$)</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rates as $r): ?>
                <tr>
                    <td><?php echo number_format($r['weight_up_to'], 2, ',', '.'); ?> kg</td>
                    <td>R$ <?php echo number_format($r['price'], 2, ',', '.'); ?></td>
                    <td>
                        <form method="POST" onsubmit="return confirm('Excluir este preço?')">
                            <input type="hidden" name="rate_id" value="<?php echo $r['id']; ?>">
                            <button type="submit" name="delete_rate" class="btn btn-danger">Excluir</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($rates)): ?>
                <tr><td colspan="3" style="text-align:center; color:#94a3b8;">Nenhum preço cadastrado ainda.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
