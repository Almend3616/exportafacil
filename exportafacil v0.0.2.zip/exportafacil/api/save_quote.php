<?php
session_start();
header('Content-Type: application/json');
require_once '../config/db.php';

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Usuário não autenticado.']);
    exit;
}

if (!$data || !isset($data['client_name'], $data['total_weight'], $data['total_price'])) {
    echo json_encode(['success' => false, 'message' => 'Dados incompletos.']);
    exit;
}

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("INSERT INTO quotes (user_id, client_name, client_phone, origin, destination, total_weight, total_price, freight_options, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
    $stmt->execute([
        $_SESSION['user_id'],
        $data['client_name'],
        $data['client_phone'] ?? '',
        $data['origin'] ?? '',
        $data['destination'] ?? '',
        $data['total_weight'],
        $data['total_price'],
        isset($data['all_options']) ? json_encode($data['all_options']) : null
    ]);
    
    $quote_id = $pdo->lastInsertId();

    if (isset($data['volumes']) && is_array($data['volumes'])) {
        $stmt_item = $pdo->prepare("INSERT INTO quote_items (quote_id, height, width, length, actual_weight, cubed_weight) VALUES (?, ?, ?, ?, ?, ?)");
        foreach ($data['volumes'] as $vol) {
            $stmt_item->execute([
                $quote_id,
                $vol['h'],
                $vol['w'],
                $vol['l'],
                $vol['weight'],
                $vol['considered']
            ]);
        }
    }

    $pdo->commit();
    echo json_encode(['success' => true, 'quote_id' => $quote_id]);
} catch (Exception $e) {
    if($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'Erro ao salvar cotação: ' . $e->getMessage()]);
}
?>
