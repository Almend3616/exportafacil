<?php
header('Content-Type: application/json');
require_once '../config/db.php';

$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['fullname'], $data['username'], $data['password'])) {
    echo json_encode(['success' => false, 'message' => 'Dados incompletos.']);
    exit;
}

$fullname = trim($data['fullname']);
$username = trim($data['username']);
$password = password_hash($data['password'], PASSWORD_DEFAULT);

try {
    // Check if user already exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Este usuário já existe.']);
        exit;
    }

    // Check if this is the first user
    $stmt = $pdo->query("SELECT COUNT(*) FROM users");
    $count = $stmt->fetchColumn();

    $role = ($count == 0) ? 'admin' : 'user';
    $status = ($count == 0) ? 'approved' : 'pending';

    $stmt = $pdo->prepare("INSERT INTO users (name, username, password, role, status) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$fullname, $username, $password, $role, $status]);

    echo json_encode([
        'success' => true, 
        'isAdmin' => ($role == 'admin'),
        'message' => 'Cadastro realizado com sucesso.'
    ]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Erro no servidor: ' . $e->getMessage()]);
}
?>
