<?php
header('Content-Type: application/json');
require_once '../config/db.php';
require_once '../includes/auth.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado.']);
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

if (!$id) {
    echo json_encode(['success' => false, 'message' => 'ID da cotação é obrigatório.']);
    exit;
}

try {
    // Get quote basics
    $stmt = $pdo->prepare("SELECT * FROM quotes WHERE id = ?");
    $stmt->execute([$id]);
    $quote = $stmt->fetch();

    if (!$quote) {
        echo json_encode(['success' => false, 'message' => 'Cotação não encontrada.']);
        exit;
    }

    // Get items (dimensions)
    $stmtItems = $pdo->prepare("SELECT * FROM quote_items WHERE quote_id = ?");
    $stmtItems->execute([$id]);
    $items = $stmtItems->fetchAll();

    echo json_encode(['success' => true, 'quote' => $quote, 'items' => $items]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erro: ' . $e->getMessage()]);
}
?>
