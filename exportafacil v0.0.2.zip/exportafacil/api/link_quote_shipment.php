<?php
session_start();
header('Content-Type: application/json');
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Usuário não autenticado.']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['quote_id'], $data['shipment_id'])) {
    echo json_encode(['success' => false, 'message' => 'Dados incompletos.']);
    exit;
}

$quote_id = (int)$data['quote_id'];
$shipment_id = (int)$data['shipment_id'];

try {
    // Check if shipment exists
    $stmt = $pdo->prepare("SELECT id FROM shipments WHERE id = ?");
    $stmt->execute([$shipment_id]);
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Remessa não encontrada.']);
        exit;
    }

    // Get current values for sync (Phase 8.2)
    $stmt = $pdo->prepare("SELECT freight_value FROM shipments WHERE id = ?");
    $stmt->execute([$shipment_id]);
    $shipment = $stmt->fetch();

    $stmt = $pdo->prepare("SELECT paid_value, total_price FROM quotes WHERE id = ?");
    $stmt->execute([$quote_id]);
    $quote = $stmt->fetch();

    // Update shipment with quote_id
    $stmt = $pdo->prepare("UPDATE shipments SET quote_id = ? WHERE id = ?");
    $stmt->execute([$quote_id, $shipment_id]);

    // Initial Sync Logic
    if ($quote && $quote['paid_value'] > 0) {
        // If quote is already "won/paid", update shipment
        $stmt = $pdo->prepare("UPDATE shipments SET freight_value = ? WHERE id = ?");
        $stmt->execute([$quote['paid_value'], $shipment_id]);
    } elseif ($shipment && $shipment['freight_value'] > 0) {
        // Otherwise, if shipment has a value, update quote's paid_value and status
        $stmt = $pdo->prepare("UPDATE quotes SET paid_value = ?, status = 'won' WHERE id = ?");
        $stmt->execute([$shipment['freight_value'], $quote_id]);
    }

    echo json_encode(['success' => true, 'message' => 'Cotação vinculada à remessa com sucesso!']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Erro ao vincular: ' . $e->getMessage()]);
}
?>
