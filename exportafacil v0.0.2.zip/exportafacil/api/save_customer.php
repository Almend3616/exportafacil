<?php
header('Content-Type: application/json');
require_once '../config/db.php';
require_once '../includes/auth.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : null;
    $name = $_POST['name'] ?? '';
    $document = $_POST['document'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $email = $_POST['email'] ?? '';
    $address_line1 = $_POST['address_line1'] ?? '';
    $address_line2 = $_POST['address_line2'] ?? '';
    $address_line3 = $_POST['address_line3'] ?? '';
    $zip_code = $_POST['zip_code'] ?? '';
    $city = $_POST['city'] ?? '';
    $state = $_POST['state'] ?? '';
    $country = $_POST['country'] ?? '';
    $observations = $_POST['observations'] ?? '';

    if (empty($name)) {
        echo json_encode(['success' => false, 'message' => 'O nome do cliente é obrigatório.']);
        exit;
    }

    try {
        if ($id) {
            $stmt = $pdo->prepare("UPDATE customers SET name = ?, document = ?, phone = ?, email = ?, address_line1 = ?, address_line2 = ?, address_line3 = ?, zip_code = ?, city = ?, state = ?, country = ?, observations = ? WHERE id = ?");
            $stmt->execute([$name, $document, $phone, $email, $address_line1, $address_line2, $address_line3, $zip_code, $city, $state, $country, $observations, $id]);
            echo json_encode(['success' => true, 'message' => 'Cliente atualizado com sucesso!', 'id' => $id]);
        }
        else {
            $stmt = $pdo->prepare("INSERT INTO customers (name, document, phone, email, address_line1, address_line2, address_line3, zip_code, city, state, country, observations) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$name, $document, $phone, $email, $address_line1, $address_line2, $address_line3, $zip_code, $city, $state, $country, $observations]);
            echo json_encode(['success' => true, 'message' => 'Cliente cadastrado com sucesso!', 'id' => $pdo->lastInsertId()]);
        }
    }
    catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Erro ao salvar cliente: ' . $e->getMessage()]);
    }
}
else {
    echo json_encode(['success' => false, 'message' => 'Método não suportado.']);
}
?>
