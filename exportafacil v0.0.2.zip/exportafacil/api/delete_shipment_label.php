<?php
session_start();
header('Content-Type: application/json');
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado.']);
    exit;
}

$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

if (!$id) {
    echo json_encode(['success' => false, 'message' => 'ID inválido.']);
    exit;
}

try {
    // Pegar caminho do arquivo antes de excluir do banco
    $stmt = $pdo->prepare("SELECT file_path FROM shipment_labels WHERE id = ?");
    $stmt->execute([$id]);
    $label = $stmt->fetch();

    if ($label) {
        $stmtDel = $pdo->prepare("DELETE FROM shipment_labels WHERE id = ?");
        if ($stmtDel->execute([$id])) {
            
            // Tentar excluir fisicamente o arquivo se existir
            if (!empty($label['file_path'])) {
                $physicalPath = '../' . $label['file_path'];
                if (file_exists($physicalPath)) {
                    @unlink($physicalPath);
                }
            }
            
            echo json_encode(['success' => true, 'message' => 'Etiqueta excluída com sucesso.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao excluir do banco de dados.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Etiqueta não encontrada.']);
    }

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erro interno: ' . $e->getMessage()]);
}
?>
