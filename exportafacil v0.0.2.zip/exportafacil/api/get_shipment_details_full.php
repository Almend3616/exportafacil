<?php
session_start();
header('Content-Type: application/json');
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado.']);
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

if (!$id) {
    echo json_encode(['success' => false, 'message' => 'ID da remessa é obrigatório.']);
    exit;
}

try {
    // Get shipment
    $stmt = $pdo->prepare("SELECT * FROM shipments WHERE id = ?");
    $stmt->execute([$id]);
    $shipment = $stmt->fetch();

    if (!$shipment) {
        echo json_encode(['success' => false, 'message' => 'Remessa não encontrada.']);
        exit;
    }

    // Get notes with their possible attachments
    $stmtNotes = $pdo->prepare("
        SELECT n.*, f.file_path, f.file_name, f.file_type 
        FROM shipment_notes n 
        LEFT JOIN shipment_files f ON n.id = f.note_id 
        WHERE n.shipment_id = ? 
        ORDER BY n.created_at ASC
    ");
    $stmtNotes->execute([$id]);
    $notes = $stmtNotes->fetchAll();

    // Get files
    $stmtFiles = $pdo->prepare("SELECT * FROM shipment_files WHERE shipment_id = ? ORDER BY uploaded_at DESC");
    $stmtFiles->execute([$id]);
    $files = $stmtFiles->fetchAll();

    // Check for quote image
    $quote_image = null;
    if ($shipment['quote_id']) {
        $quote_path = "uploads/quotes/quote_" . $shipment['quote_id'] . ".png";
        if (file_exists("../" . $quote_path)) {
            $quote_image = [
                'file_path' => $quote_path,
                'file_name' => 'Imagem da Cotação',
                'file_type' => 'image/png'
            ];
        }
    }

    echo json_encode([
        'success' => true, 
        'shipment' => $shipment, 
        'notes' => $notes,
        'files' => $files,
        'quote_image' => $quote_image
    ]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erro: ' . $e->getMessage()]);
}
?>
