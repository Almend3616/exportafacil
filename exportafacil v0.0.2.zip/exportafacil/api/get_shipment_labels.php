<?php
session_start();
header('Content-Type: application/json');
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado.']);
    exit;
}

try {
    // Garantir que a tabela existe (Auto-fix) para evitar erro quando nenhum envio foi feito ainda
    $pdo->exec("CREATE TABLE IF NOT EXISTS shipment_labels (
        id INT AUTO_INCREMENT PRIMARY KEY,
        shipment_id INT NULL,
        waybill VARCHAR(50) NOT NULL,
        sender_name VARCHAR(255),
        recipient_name VARCHAR(255),
        destination_country VARCHAR(100),
        file_path VARCHAR(255),
        status ENUM('Envio feito', 'Em Rota', 'Entregue') DEFAULT 'Envio feito',
        form_data TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // Get labels, most recent first
    $stmt = $pdo->query("SELECT * FROM shipment_labels ORDER BY created_at DESC LIMIT 50");
    $labels = $stmt->fetchAll(PDO::FETCH_ASSOC);

    error_log("GET_LABELS: Found " . count($labels) . " labels in DB.");
    echo json_encode(['success' => true, 'labels' => $labels, 'debug_count' => count($labels)]);
} catch (PDOException $e) {
    error_log("GET_LABELS_ERROR: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Erro ao buscar etiquetas: ' . $e->getMessage()]);
}
?>
