<?php
session_start();
header('Content-Type: application/json');
require_once '../config/db.php';

$results = [
    'db_connection' => 'OK',
    'table_exists' => false,
    'row_count' => 0,
    'uploads_dir' => [
        'path' => '../uploads/labels/',
        'exists' => false,
        'writable' => false
    ],
    'labels' => []
];

try {
    // Check table
    $stmt = $pdo->query("SHOW TABLES LIKE 'shipment_labels'");
    $results['table_exists'] = ($stmt->rowCount() > 0);
    
    if ($results['table_exists']) {
        $stmt = $pdo->query("SELECT COUNT(*) FROM shipment_labels");
        $results['row_count'] = (int)$stmt->fetchColumn();
        
        $stmt = $pdo->query("SELECT * FROM shipment_labels ORDER BY created_at DESC LIMIT 5");
        $results['labels'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        // Try creating it now if it doesn't exist
        $pdo->exec("CREATE TABLE IF NOT EXISTS shipment_labels (
            id INT AUTO_INCREMENT PRIMARY KEY,
            shipment_id INT NULL,
            waybill VARCHAR(50) NOT NULL,
            sender_name VARCHAR(255),
            recipient_name VARCHAR(255),
            destination_country VARCHAR(100),
            file_path VARCHAR(255),
            status ENUM('Envio feito', 'Em Rota', 'Entregue') DEFAULT 'Envio feito',
            form_data TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
        $results['table_exists'] = true;
        $results['created_now'] = true;
    }
    
    // Check directory
    $dir = '../uploads/labels/';
    $results['uploads_dir']['exists'] = is_dir($dir);
    if ($results['uploads_dir']['exists']) {
        $results['uploads_dir']['writable'] = is_writable($dir);
    } else {
        if (mkdir($dir, 0777, true)) {
            $results['uploads_dir']['exists'] = true;
            $results['uploads_dir']['writable'] = is_writable($dir);
        }
    }
    
    echo json_encode(['success' => true, 'report' => $results]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
