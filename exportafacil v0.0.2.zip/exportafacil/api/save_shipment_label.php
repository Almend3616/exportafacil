<?php
session_start();
header('Content-Type: application/json');
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado.']);
    exit;
}

// Increase limits for Large PDF
ini_set('memory_limit', '512M');
set_time_limit(120);

// Global Error Handler to avoid 500s hiding the real issue
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    if (!(error_reporting() & $errno)) return;
    echo json_encode(['success' => false, 'message' => "PHP Error [$errno]: $errstr em $errfile:$errline"]);
    exit;
});

$isFormData = isset($_POST['waybill']);

if ($isFormData) {
    $waybill = $_POST['waybill'];
    $shipment_id = !empty($_POST['shipment_id']) ? (int)$_POST['shipment_id'] : null;
    $sender_name = $_POST['sender_name'] ?? '';
    $recipient_name = $_POST['recipient_name'] ?? '';
    $destination_country = $_POST['destination_country'] ?? '';
    $status = $_POST['status'] ?? 'Envio feito';
    $form_all = $_POST['form_all'] ?? null;
    
    if (!isset($_FILES['pdf_file']) || $_FILES['pdf_file']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['success' => false, 'message' => 'Erro crítico: Arquivo PDF não recebido via POST File Upload.']);
        exit;
    }
    $pdf_content = file_get_contents($_FILES['pdf_file']['tmp_name']);
} else {
    // Get the raw POST data (Legacy JSON fallback)
    $rawData = file_get_contents('php://input');
    $data = json_decode($rawData, true);

    if (!$data) {
        echo json_encode(['success' => false, 'message' => 'Erro ao decodificar JSON (Payload excede o limite). Tamanho: ' . strlen($rawData)]);
        exit;
    }

    if (!isset($data['pdf_base64']) || !isset($data['waybill'])) {
        echo json_encode(['success' => false, 'message' => 'Dados incompletos (PDF ou Waybill ausentes).']);
        exit;
    }

    $waybill = $data['waybill'];
    $shipment_id = isset($data['shipment_id']) ? (int)$data['shipment_id'] : null;
    $sender_name = $data['sender_name'] ?? '';
    $recipient_name = $data['recipient_name'] ?? '';
    $destination_country = $data['destination_country'] ?? '';
    $status = $data['status'] ?? 'Envio feito';
    $form_all = isset($data['form_all']) ? json_encode($data['form_all']) : null;
    $pdf_content = base64_decode(preg_replace('#^data:application/pdf;base64,#i', '', $data['pdf_base64']));
}

// Create directory if not exists
$uploadDir = '../uploads/labels/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

$fileName = 'label_' . preg_replace('/[^A-Za-z0-9]/', '', $waybill) . '_' . time() . '.pdf';
$filePath = $uploadDir . $fileName;

if (file_put_contents($filePath, $pdf_content)) {
    // 0. Garantir que a tabela existe (Auto-fix) - SEMPRE FORA DA TRANSACTION (Implicit Commit no MySQL!)
    $pdo->exec("CREATE TABLE IF NOT EXISTS shipment_labels (
        id INT AUTO_INCREMENT PRIMARY KEY,
        shipment_id INT NULL,
        waybill VARCHAR(50) NOT NULL,
        sender_name VARCHAR(255),
        recipient_name VARCHAR(255),
        destination_country VARCHAR(100),
        file_path VARCHAR(255),
        status ENUM('Envio feito', 'Em Rota', 'Entregue') DEFAULT 'Envio feito',
        form_data TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    try {
        $pdo->beginTransaction();

        // 1. Insert into shipment_labels (History)
        $stmt = $pdo->prepare("INSERT INTO shipment_labels (shipment_id, waybill, sender_name, recipient_name, destination_country, file_path, status, form_data) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $webPath = 'uploads/labels/' . $fileName;
        $stmt->execute([$shipment_id, $waybill, $sender_name, $recipient_name, $destination_country, $webPath, $status, $form_all]);
        $label_id = $pdo->lastInsertId();

        // 2. If it's linked to a shipment
        if ($shipment_id) {
            // Update shipment status
            $stmtStatus = $pdo->prepare("UPDATE shipments SET status = 'Aguardando Coleta' WHERE id = ?");
            $stmtStatus->execute([$shipment_id]);
        }

        $pdo->commit();
        error_log("SAVE_LABEL_SUCCESS: Waybill $waybill saved ID $label_id");
        echo json_encode(['success' => true, 'message' => 'Etiqueta salva com sucesso!', 'label_id' => $label_id]);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            try { @$pdo->rollBack(); } catch(Throwable $e2){}
        }
        error_log("SAVE_LABEL_FATAL: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine());
        echo json_encode(['success' => false, 'message' => 'Erro Fatal no Servidor: ' . $e->getMessage() . ' na linha ' . $e->getLine()]);
    }
} else {
    error_log("SAVE_LABEL_FILE_ERROR: Could not save PDF to $filePath. Check directory permissions.");
    echo json_encode(['success' => false, 'message' => 'Erro ao salvar arquivo PDF físico via file_put_contents. Permissão de pasta?']);
}
?>
