<?php
header('Content-Type: application/json');
require_once '../config/db.php';
require_once '../includes/auth.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado.']);
    exit;
}

try {
    // FIX: Automagically recover any shipments stranded in the non-existent 'Aguardando Finalização' state
    $pdo->exec("UPDATE shipments SET status = 'Aguardando Coleta' WHERE status = 'Aguardando Finalização'");

    $sql = "SELECT s.*, 
            COALESCE(NULLIF(s.sender_name, ''), c1.name) as sender_name,
            COALESCE(NULLIF(s.sender_phone, ''), c1.phone) as sender_phone,
            COALESCE(NULLIF(s.recipient_name, ''), c2.name) as recipient_name,
            COALESCE(NULLIF(s.recipient_phone, ''), c2.phone) as recipient_phone,
            q.client_name as quote_client_name
            FROM shipments s
            LEFT JOIN customers c1 ON s.sender_id = c1.id
            LEFT JOIN customers c2 ON s.recipient_id = c2.id
            LEFT JOIN quotes q ON s.quote_id = q.id
            ORDER BY s.shipment_date DESC";
    
    $stmt = $pdo->query($sql);
    $shipments = $stmt->fetchAll();
    
    echo json_encode(['success' => true, 'shipments' => $shipments]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erro ao buscar remessas: ' . $e->getMessage()]);
}
?>
