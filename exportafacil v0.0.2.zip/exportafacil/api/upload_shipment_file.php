<?php
session_start();
header('Content-Type: application/json');
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado.']);
    exit;
}

if (!isset($_POST['shipment_id']) || !isset($_FILES['file'])) {
    echo json_encode(['success' => false, 'message' => 'Dados incompletos.']);
    exit;
}

$shipment_id = (int)$_POST['shipment_id'];
$file = $_FILES['file'];

$uploadDir = '../uploads/shipments/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

$extension = pathinfo($file['name'], PATHINFO_EXTENSION);
$fileName = 'shipment_' . $shipment_id . '_' . time() . '_' . uniqid() . '.' . $extension;
$targetPath = $uploadDir . $fileName;

if (move_uploaded_file($file['tmp_name'], $targetPath)) {
    try {
        $stmt = $pdo->prepare("INSERT INTO shipment_files (shipment_id, note_id, file_path, file_name, file_type) VALUES (?, NULL, ?, ?, ?)");
        // Save relative path for web access
        $webPath = 'uploads/shipments/' . $fileName;
        $stmt->execute([$shipment_id, $webPath, $file['name'], $file['type']]);

        echo json_encode(['success' => true, 'message' => 'Arquivo enviado!']);
    }
    catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Erro ao salvar no banco: ' . $e->getMessage()]);
    }
}
else {
    echo json_encode(['success' => false, 'message' => 'Erro ao mover arquivo.']);
}
?>
