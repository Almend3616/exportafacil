<?php
header('Content-Type: application/json');
require_once '../config/db.php';
require_once '../includes/auth.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : null;
    $quote_id = !empty($_POST['quote_id']) ? (int)$_POST['quote_id'] : null;
    $sender_id = !empty($_POST['sender_id']) ? (int)$_POST['sender_id'] : null;
    $recipient_id = !empty($_POST['recipient_id']) ? (int)$_POST['recipient_id'] : null;
    $sender_name = $_POST['sender_name'] ?? '';
    $sender_phone = $_POST['sender_phone'] ?? '';
    $recipient_name = $_POST['recipient_name'] ?? '';
    $recipient_phone = $_POST['recipient_phone'] ?? '';
    
    $responsible_name = $_POST['responsible_name'] ?? '';
    $responsible_phone = $_POST['responsible_phone'] ?? '';
    $description = $_POST['description'] ?? '';
    $declared_value = !empty($_POST['declared_value']) ? (float)$_POST['declared_value'] : 0;
    
    $status = $_POST['status'] ?? 'Aguardando';
    $delivery_person = $_POST['delivery_person'] ?? '';
    $responsible_salesperson = $_POST['responsible_salesperson'] ?? '';
    $received_by = $_SESSION['name'] ?? 'System'; // Preenchido pelo sistema
    $quantity = !empty($_POST['quantity']) ? (int)$_POST['quantity'] : 0;
    $dimensions = $_POST['dimensions'] ?? '';
    $weight = !empty($_POST['weight']) ? (float)$_POST['weight'] : 0;
    $destination_country = $_POST['destination_country'] ?? '';
    $freight_value = !empty($_POST['freight_value']) ? (float)$_POST['freight_value'] : 0;
    $payment_status = $_POST['payment_status'] ?? 'Aguardando Pagamento';
    $payment_type = $_POST['payment_type'] ?? null;

    $shipment_photo = '';
    // Handle file upload
    if (isset($_FILES['shipment_photo']) && $_FILES['shipment_photo']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../assets/uploads/shipments/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        $fileName = time() . '_' . basename($_FILES['shipment_photo']['name']);
        $targetPath = $uploadDir . $fileName;
        if (move_uploaded_file($_FILES['shipment_photo']['tmp_name'], $targetPath)) {
            $shipment_photo = 'assets/uploads/shipments/' . $fileName;
        }
    }

    // Workflow Automation Logic
    $has_measures = ($weight > 0 && !empty($dimensions));
    $has_all_data = $has_measures && 
                    !empty($sender_id) && 
                    !empty($recipient_id) && 
                    !empty($description) && 
                    $declared_value > 0;

    $statuses_order = [
        'Aguardando' => 0,
        'Juntando mercadorias' => 1,
        'Aguardando Dados' => 2,
        'Preparar Envio' => 3,
        'Aguardando Coleta' => 4,
        'Rastreio' => 5,
        'Entregues' => 6
    ];

    if ($payment_status === 'Pagamento confirmado') {
        $current_index = $statuses_order[$status] ?? 0;
        $new_index = 0;
        
        if ($has_all_data) {
            $new_index = 3; // Preparar Envio
        } elseif ($has_measures) {
            $new_index = 2; // Aguardando Dados
        }

        if ($new_index > $current_index) {
            $status = array_search($new_index, $statuses_order);
        }
    }

    try {
        if ($id) {
            $sql = "UPDATE shipments SET quote_id = ?, sender_id = ?, recipient_id = ?, sender_name = ?, sender_phone = ?, recipient_name = ?, recipient_phone = ?, responsible_name = ?, responsible_phone = ?, description = ?, declared_value = ?, status = ?, delivery_person = ?, responsible_salesperson = ?, quantity = ?, dimensions = ?, weight = ?, destination_country = ?, freight_value = ?, payment_status = ?, payment_type = ?";
            $params = [$quote_id, $sender_id, $recipient_id, $sender_name, $sender_phone, $recipient_name, $recipient_phone, $responsible_name, $responsible_phone, $description, $declared_value, $status, $delivery_person, $responsible_salesperson, $quantity, $dimensions, $weight, $destination_country, $freight_value, $payment_status, $payment_type];
            
            if ($shipment_photo) {
                $sql .= ", shipment_photo = ?";
                $params[] = $shipment_photo;
            }
            
            $sql .= " WHERE id = ?";
            $params[] = $id;
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);

            // Sync to linked quote if exists
            if ($quote_id) {
                if ($payment_status === 'Pagamento confirmado') {
                    $stmtQ = $pdo->prepare("UPDATE quotes SET paid_value = ?, status = 'won' WHERE id = ?");
                    $stmtQ->execute([$freight_value, $quote_id]);
                } else {
                    $stmtQ = $pdo->prepare("UPDATE quotes SET status = 'follow_up' WHERE id = ? AND status = 'won'");
                    $stmtQ->execute([$quote_id]);
                }
            }

            echo json_encode(['success' => true, 'message' => 'Remessa atualizada com sucesso!', 'id' => $id]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO shipments (quote_id, sender_id, recipient_id, sender_name, sender_phone, recipient_name, recipient_phone, responsible_name, responsible_phone, description, declared_value, status, delivery_person, responsible_salesperson, received_by, quantity, dimensions, weight, destination_country, freight_value, payment_status, payment_type, shipment_photo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$quote_id, $sender_id, $recipient_id, $sender_name, $sender_phone, $recipient_name, $recipient_phone, $responsible_name, $responsible_phone, $description, $declared_value, $status, $delivery_person, $responsible_salesperson, $received_by, $quantity, $dimensions, $weight, $destination_country, $freight_value, $payment_status, $payment_type, $shipment_photo]);
            $new_shipment_id = $pdo->lastInsertId();

            // Sync to linked quote if exists
            if ($quote_id) {
                if ($payment_status === 'Pagamento confirmado') {
                    $stmtQ = $pdo->prepare("UPDATE quotes SET paid_value = ?, status = 'won' WHERE id = ?");
                    $stmtQ->execute([$freight_value, $quote_id]);
                } else {
                    $stmtQ = $pdo->prepare("UPDATE quotes SET status = 'follow_up' WHERE id = ? AND status = 'won'");
                    $stmtQ->execute([$quote_id]);
                }
            }

            echo json_encode(['success' => true, 'message' => 'Remessa criada com sucesso!', 'id' => $new_shipment_id]);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Erro ao salvar remessa: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Método não suportado.']);
}
?>
