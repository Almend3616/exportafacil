<?php
session_start();
header('Content-Type: application/json');
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado.']);
    exit;
}

$shipment_id = isset($_POST['shipment_id']) ? (int)$_POST['shipment_id'] : null;
$note = isset($_POST['note']) ? trim($_POST['note']) : '';

if (!$shipment_id || empty($note)) {
    echo json_encode(['success' => false, 'message' => 'Dados incompletos.']);
    exit;
}

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("INSERT INTO shipment_notes (shipment_id, note, user_name) VALUES (?, ?, ?)");
    $stmt->execute([$shipment_id, $note, $_SESSION['name'] ?? 'Sistema']);
    $note_id = $pdo->lastInsertId();

    // Handle file upload if present
    if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../uploads/shipments/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

        $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
        $fileName = "shipment_{$shipment_id}_note_{$note_id}_" . time() . "." . $ext;
        $targetPath = $uploadDir . $fileName;

        if (move_uploaded_file($_FILES['file']['tmp_name'], $targetPath)) {
            $dbPath = 'uploads/shipments/' . $fileName;
            $fileStmt = $pdo->prepare("INSERT INTO shipment_files (shipment_id, note_id, file_path, file_name, file_type) VALUES (?, ?, ?, ?, ?)");
            $fileStmt->execute([$shipment_id, $note_id, $dbPath, $_FILES['file']['name'], $_FILES['file']['type']]);
        }
    }

    $pdo->commit();
    echo json_encode(['success' => true, 'message' => 'Nota adicionada!']);
} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'Erro: ' . $e->getMessage()]);
}
?>
