<?php
header('Content-Type: application/json');
require_once '../config/db.php';

if (!isset($_GET['weight'])) {
    echo json_encode(['success' => false, 'message' => 'Peso não informado.']);
    exit;
}

$totalWeight = (float)$_GET['weight'];
$carrierFilter = isset($_GET['carriers']) && !empty($_GET['carriers']) ? explode(',', $_GET['carriers']) : [];

try {
    $whereClause = "WHERE sr.weight_up_to = (
            SELECT MIN(weight_up_to) 
            FROM shipping_rates 
            WHERE method_id = sm.id AND weight_up_to >= ?
        )";
    
    $params = [$totalWeight];

    if (!empty($carrierFilter)) {
        $placeholders = implode(',', array_fill(0, count($carrierFilter), '?'));
        $whereClause .= " AND c.id IN ($placeholders)";
        $params = array_merge($params, $carrierFilter);
    }

    $query = "
        SELECT 
            c.name as carrier, 
            c.logo as carrier_logo,
            sm.name as method, 
            sm.delivery_time, 
            sr.price 
        FROM shipping_rates sr
        JOIN shipping_methods sm ON sr.method_id = sm.id
        JOIN carriers c ON sm.carrier_id = c.id
        $whereClause
        ORDER BY sr.price ASC
    ";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $options = $stmt->fetchAll();

    if ($options) {
        echo json_encode(['success' => true, 'options' => $options]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Nenhum preço encontrado.']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Erro no servidor: ' . $e->getMessage()]);
}
?>
