<?php
require_once 'config/db.php';

try {
    echo "<h2>Iniciando Migração de Histórico de Etiquetas...</h2>";

    // 1. Update shipments status enum (adding 'Aguardando Finalização')
    // Note: SQLite doesn't support ALTER TABLE ... MODIFY. For MySQL/MariaDB:
    $pdo->exec("ALTER TABLE shipments MODIFY COLUMN status ENUM('Aguardando', 'Juntando Mercadoria', 'Preparar Remessa', 'Preparar Envio', 'Aguardando Finalização', 'Aguardando Pagamento', 'Aguardando Coleta', 'Coletado') DEFAULT 'Aguardando'");
    echo "✅ Status 'Aguardando Finalização' adicionado à tabela 'shipments'.<br>";

    // 2. Create shipment_labels table
    $sqlLabels = "CREATE TABLE IF NOT EXISTS shipment_labels (
        id INT AUTO_INCREMENT PRIMARY KEY,
        shipment_id INT NULL,
        waybill VARCHAR(50) NOT NULL,
        sender_name VARCHAR(255),
        recipient_name VARCHAR(255),
        destination_country VARCHAR(100),
        file_path VARCHAR(255) NOT NULL,
        form_data TEXT, -- JSON blob of the full form
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (shipment_id) REFERENCES shipments(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
    
    $pdo->exec($sqlLabels);
    echo "✅ Tabela 'shipment_labels' criada com sucesso.<br>";

    echo "<br><h3 style='color: green;'>Migração concluída!</h3>";
    echo "<p><a href='shipment_label.php'>Voltar para Gerador de Etiquetas</a></p>";

} catch (PDOException $e) {
    echo "<br><h3 style='color: red;'>Erro na migração:</h3>";
    echo "<pre>" . $e->getMessage() . "</pre>";
}
?>
