<?php
require_once 'config/db.php';

echo "<h2>Iniciando configuração do Banco de Dados...</h2>";

try {
    $sql = file_get_contents('sql/schema.sql');

    // Split SQL by semicolon to execute multiple statements
    $statements = array_filter(array_map('trim', explode(';', $sql)));

    foreach ($statements as $stmt) {
        if (!empty($stmt)) {
            $pdo->exec($stmt);
            // Extract table name for better feedback
            if (preg_match('/CREATE TABLE IF NOT EXISTS (\w+)/i', $stmt, $matches)) {
                echo "✅ Tabela '<b>" . $matches[1] . "</b>' verificada/criada.<br>";
            }
        }
    }

    echo "<br><h3 style='color: green;'>Configuração concluída com sucesso!</h3>";
    echo "<p>Agora você pode <a href='register.php'>CRIAR A SUA CONTA</a> (A primeira conta será o ADMIN).</p>";
}
catch (Exception $e) {
    echo "<br><h3 style='color: red;'>Erro ao configurar banco de dados:</h3>";
    echo "<pre>" . $e->getMessage() . "</pre>";
    echo "<p>Verifique se os dados em <b>config/db.php</b> estão corretos.</p>";
}
?>
