<?php
require_once 'includes/auth.php';
checkLogin();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exporta Fácil – Clientes</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/auth.css">
    <style>
        body {
            background-color: #0a0a0c;
            color: #e2e8f0;
            display: block;
            padding: 2rem;
            min-height: 100vh;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .nav-links a {
            color: #6366f1;
            text-decoration: none;
            margin-left: 1.5rem;
            font-weight: 500;
        }
        .main-container {
            max-width: 1200px;
            margin: 0 auto;
        }
        .card {
            background: #111116;
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 16px;
            padding: 2rem;
            margin-top: 1rem;
        }
        .btn {
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
            cursor: pointer;
            border: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }
        .btn-primary {
            background: #6366f1;
            color: white;
        }
        .btn-primary:hover {
            background: #4f46e5;
            transform: translateY(-2px);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1.5rem;
        }
        th, td {
            text-align: left;
            padding: 12px 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }
        th {
            background: rgba(255, 255, 255, 0.02);
            font-weight: 600;
            color: #94a3b8;
        }
        tr:hover {
            background: rgba(255, 255, 255, 0.02);
        }
        .action-btns {
            display: flex;
            gap: 10px;
        }
        .action-btn {
            background: none;
            border: none;
            color: #94a3b8;
            cursor: pointer;
            font-size: 1.2rem;
            transition: color 0.3s;
        }
        .action-btn:hover {
            color: #6366f1;
        }
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(5px);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            background: #111116;
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 2rem;
            width: 90%;
            max-width: 800px;
            max-height: 90vh;
            overflow-y: auto;
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }
        .close-modal {
            background: none;
            border: none;
            color: #94a3b8;
            font-size: 1.5rem;
            cursor: pointer;
        }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1.5rem;
        }
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .form-group label {
            font-size: 0.9rem;
            color: #94a3b8;
            font-weight: 500;
        }
        .form-group input, .form-group select, .form-group textarea {
            background: #0a0a0c;
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 10px 12px;
            color: #fff;
            outline: none;
        }
        .form-group input:focus {
            border-color: #6366f1;
        }
        .btn-group {
            grid-column: span 2;
            display: flex;
            justify-content: flex-end;
            gap: 1rem;
            margin-top: 1rem;
        }
    </style>
</head>
<body>
    <div class="main-container">
        <div class="header">
            <div style="display: flex; align-items: center; gap: 1rem;">
                <a href="index.php" style="color: #94a3b8; text-decoration: none; font-size: 1.5rem;"><i class='bx bx-arrow-back'></i></a>
                <h1>Clientes</h1>
            </div>
            <div class="nav-links">
                <button class="btn btn-primary" onclick="openModal()">
                    <i class='bx bx-plus'></i> Novo Cliente
                </button>
            </div>
        </div>

        <div class="card">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                <h2>Lista de Clientes</h2>
                <div style="position: relative;">
                    <i class='bx bx-search' style="position: absolute; left: 10px; top: 12px; color: #94a3b8;"></i>
                    <input type="text" id="searchInput" placeholder="Buscar cliente..." style="background: #0a0a0c; border: 1px solid rgba(255, 255, 255, 0.1); padding: 10px 10px 10px 35px; border-radius: 8px; color: #fff; outline: none; width: 300px;">
                </div>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Documento</th>
                        <th>Telefone</th>
                        <th>E-mail</th>
                        <th>Cidade/Estado</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody id="customersTableBody">
                    <!-- Clientes serão carregados aqui -->
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal Adicionar/Editar Cliente -->
    <div id="customerModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modalTitle">Cadastrar Novo Cliente</h2>
                <button class="close-modal" onclick="closeModal()"><i class='bx bx-x'></i></button>
            </div>
            <form id="customerForm">
                <input type="hidden" id="customerId" name="id">
                <div class="form-grid">
                    <div class="form-group" style="grid-column: span 2;">
                        <label>Nome Completo *</label>
                        <input type="text" id="name" name="name" required placeholder="Nome do cliente">
                    </div>
                    <div class="form-group">
                        <label>Documento (CPF, NIF, DUT, RUT...)</label>
                        <input type="text" id="document" name="document" placeholder="Documento">
                    </div>
                    <div class="form-group">
                        <label>Telefone</label>
                        <input type="text" id="phone" name="phone" placeholder="Telefone de contato">
                    </div>
                    <div class="form-group">
                        <label>E-mail</label>
                        <input type="email" id="email" name="email" placeholder="E-mail">
                    </div>
                    <div class="form-group">
                        <label>CEP ou ZIPCODE</label>
                        <input type="text" id="zip_code" name="zip_code" placeholder="CEP">
                    </div>
                    <div class="form-group" style="grid-column: span 2;">
                        <label>Endereço Linha 1</label>
                        <input type="text" id="address_line1" name="address_line1" placeholder="Rua, número, complemento">
                    </div>
                    <div class="form-group">
                        <label>Cidade</label>
                        <input type="text" id="city" name="city" placeholder="Cidade">
                    </div>
                    <div class="form-group">
                        <label>Estado</label>
                        <input type="text" id="state" name="state" placeholder="Estado">
                    </div>
                    <div class="form-group">
                        <label>País</label>
                        <input type="text" id="country" name="country" placeholder="País">
                    </div>
                    <div class="form-group">
                        <label>Observações</label>
                        <textarea id="observations" name="observations" rows="3" placeholder="Notas sobre o cliente"></textarea>
                    </div>
                    <div class="btn-group">
                        <button type="button" class="btn" style="background: rgba(255,255,255,0.05); color: #fff;" onclick="closeModal()">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Salvar Cliente</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        let allCustomers = [];

        $(document).ready(function() {
            loadCustomers();

            $('#customerForm').on('submit', function(e) {
                e.preventDefault();
                const formData = $(this).serialize();
                $.post('api/save_customer.php', formData, function(response) {
                    if (response.success) {
                        alert(response.message);
                        closeModal();
                        loadCustomers();
                    } else {
                        alert(response.message);
                    }
                }, 'json');
            });

            $('#searchInput').on('input', function() {
                const term = $(this).val().toLowerCase();
                const filtered = allCustomers.filter(c => 
                    c.name.toLowerCase().includes(term) || 
                    (c.document && c.document.toLowerCase().includes(term)) ||
                    (c.email && c.email.toLowerCase().includes(term))
                );
                renderCustomers(filtered);
            });
        });

        function loadCustomers() {
            $.get('api/get_customers.php', function(response) {
                if (response.success) {
                    allCustomers = response.customers;
                    renderCustomers(allCustomers);
                }
            }, 'json');
        }

        function renderCustomers(customers) {
            const tbody = $('#customersTableBody');
            tbody.empty();
            if (customers.length === 0) {
                tbody.append('<tr><td colspan="6" style="text-align: center;">Nenhum cliente encontrado.</td></tr>');
                return;
            }
            customers.forEach(c => {
                tbody.append(`
                    <tr>
                        <td>${c.name}</td>
                        <td>${c.document || '-'}</td>
                        <td>${c.phone || '-'}</td>
                        <td>${c.email || '-'}</td>
                        <td>${c.city || ''}${c.state ? ' / ' + c.state : ''}</td>
                        <td class="action-btns">
                            <button class="action-btn edit-btn" onclick='editCustomer(${JSON.stringify(c)})'><i class='bx bx-edit-alt'></i></button>
                        </td>
                    </tr>
                `);
            });
        }

        function openModal() {
            $('#modalTitle').text('Cadastrar Novo Cliente');
            $('#customerForm')[0].reset();
            $('#customerId').val('');
            $('#customerModal').css('display', 'flex');
        }

        function closeModal() {
            $('#customerModal').hide();
        }

        function editCustomer(customer) {
            $('#modalTitle').text('Editar Cliente');
            $('#customerId').val(customer.id);
            $('#name').val(customer.name);
            $('#document').val(customer.document);
            $('#phone').val(customer.phone);
            $('#email').val(customer.email);
            $('#zip_code').val(customer.zip_code);
            $('#address_line1').val(customer.address_line1);
            $('#city').val(customer.city);
            $('#state').val(customer.state);
            $('#country').val(customer.country);
            $('#observations').val(customer.observations);
            $('#customerModal').css('display', 'flex');
        }

        // Fechar modal ao clicar fora
        window.onclick = function(event) {
            const modal = document.getElementById('customerModal');
            if (event.target == modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>
