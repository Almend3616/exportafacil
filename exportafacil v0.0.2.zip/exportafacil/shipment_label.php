<?php
require_once 'includes/auth.php';
checkLogin();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exporta Fácil – Gerar Etiqueta</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/shipment_label.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <div class="app-layout">
        <!-- Column 1: Left Navigation -->
        <aside class="sidebar-left">
            <div class="sidebar-header">
                <i class='bx bxs-ship logo-icon'></i>
                <span>Agilize Envio</span>
            </div>
            <nav class="sidebar-nav">
                <a href="index.php" class="nav-item">
                    <i class='bx bx-grid-alt'></i>
                    <span>Dashboard</span>
                </a>
                <a href="#" class="nav-item active">
                    <i class='bx bx-plus-circle'></i>
                    <span>Novo Envio</span>
                </a>
                <a href="customers.php" class="nav-item">
                    <i class='bx bx-user'></i>
                    <span>Clientes</span>
                </a>
            </nav>
            <div class="sidebar-footer" style="margin-top: auto;">
                <a href="logout.php" class="nav-item logout">
                    <i class='bx bx-log-out'></i>
                    <span>Sair</span>
                </a>
            </div>
        </aside>

        <!-- Column 2: Center Form Area -->
        <main class="main-content">
            <div class="tabs-container">
                <button class="tab-btn active" style="cursor: default;">Novo Envio</button>
                <a href="shipment_history.php" class="tab-btn" style="text-decoration:none; display:inline-flex; align-items:center; gap:8px;">
                    <i class='bx bx-list-ul'></i> VER TODOS OS ENVIOS (HISTÓRICO)
                </a>
            </div>

            <!-- Tab 1: New Shipment Form -->
            <div id="tab-new" class="tab-content active">
                <div class="form-header-top">
                    <h1>Gerar Etiqueta Internacional</h1>
                    <p>Preencha os dados abaixo seguindo o fluxo sequencial.</p>
                </div>

            <div class="form-scroll-area">
                <form id="labelForm">
                    <!-- Section 1: Shipper -->
                    <section class="form-step-container active" id="step-shipper">
                        <div class="step-card">
                            <div class="step-card-header">
                                <span class="step-number">01</span>
                                <h2>Informações do Remetente</h2>
                            </div>
                            <div class="step-card-body">
                                <div class="form-group">
                                    <label>Buscar Remetente Cadastrado</label>
                                    <div class="search-container">
                                        <i class='bx bx-search'></i>
                                        <input type="text" id="shipperSearch" placeholder="Digite nome da empresa ou contato...">
                                        <div id="shipper-search-results" class="search-results"></div>
                                    </div>
                                </div>
                                <div class="form-group"><label>Nome / Empresa</label><input type="text" id="r_nome" name="r_nome" value="EXPORTA FACIL LTDA" required placeholder="Ex: Exporta Fácil"></div>
                                <div class="form-group"><label>Endereço Completo</label><input type="text" id="r_l1" name="r_l1" value="AVENIDA BRASIL, 123" required placeholder="Rua, número, complemento..."></div>
                                <div class="row">
                                    <div class="form-group"><label>Cidade</label><input type="text" id="r_cidade" name="r_cidade" value="SAO PAULO" required></div>
                                    <div class="form-group"><label>Estado</label><input type="text" id="r_estado" name="r_estado" value="SP" required></div>
                                </div>
                                <div class="row">
                                    <div class="form-group"><label>CEP</label><input type="text" id="r_cep" name="r_cep" value="01001-000" required></div>
                                    <div class="form-group"><label>País</label><input type="text" id="r_pais" name="r_pais" value="BRAZIL" required></div>
                                </div>
                                <div class="row">
                                    <div class="form-group"><label>Telefone de Contato</label><input type="text" id="r_tel" name="r_tel" value="+55 11 99999-9999" required></div>
                                    <div class="form-group"><label>CNPJ / CPF (Tax ID)</label><input type="text" id="r_taxid" name="r_taxid" value="00.000.000/0001-00"></div>
                                </div>
                                <div class="step-actions" style="margin-top: 2rem; display: flex; justify-content: flex-end;">
                                    <button type="button" class="btn btn-primary btn-next-step" data-current="shipper" data-next="receiver">Confirmar e Continuar <i class='bx bx-right-arrow-alt'></i></button>
                                </div>
                            </div>
                        </div>
                    </section>

                    <!-- Section 2: Receiver -->
                    <section class="form-step-container" id="step-receiver" style="display:none;">
                        <div class="step-card">
                            <div class="step-card-header">
                                <span class="step-number">02</span>
                                <h2>Informações do Destinatário</h2>
                            </div>
                            <div class="step-card-body">
                                <div class="form-group">
                                    <label>Buscar Cliente Cadastrado</label>
                                    <div class="search-container">
                                        <i class='bx bx-search'></i>
                                        <input type="text" id="customerSearch" placeholder="Digite nome ou documento...">
                                        <div id="search-results" class="search-results"></div>
                                    </div>
                                </div>
                                <div class="form-group"><label>Nome / Empresa</label><input type="text" id="d_nome" name="d_nome" required></div>
                                <div class="form-group"><label>Endereço</label><input type="text" id="d_l1" name="d_l1" required></div>
                                <div class="row">
                                    <div class="form-group"><label>Cidade</label><input type="text" id="d_cidade" name="d_cidade" required></div>
                                    <div class="form-group"><label>Estado</label><input type="text" id="d_estado" name="d_estado" required></div>
                                </div>
                                <div class="row">
                                    <div class="form-group"><label>ZIPCODE / CEP</label><input type="text" id="d_zip" name="d_zip" required></div>
                                    <div class="form-group"><label>País</label><input type="text" id="d_pais" name="d_pais" required></div>
                                </div>
                                <div class="row">
                                    <div class="form-group"><label>Telefone</label><input type="text" id="d_tel" name="d_tel" required></div>
                                    <div class="form-group"><label>Tax ID / VAT / CPF</label><input type="text" id="d_taxid" name="d_taxid"></div>
                                </div>
                                <div class="step-actions" style="margin-top: 2rem; display: flex; justify-content: flex-end;">
                                    <button type="button" class="btn btn-primary btn-next-step" data-current="receiver" data-next="shipment">Confirmar e Continuar <i class='bx bx-right-arrow-alt'></i></button>
                                </div>
                            </div>
                        </div>
                    </section>

                    <!-- Section 3: Shipment -->
                    <section class="form-step-container" id="step-shipment" style="display:none;">
                        <div class="step-card">
                            <div class="step-card-header">
                                <span class="step-number">03</span>
                                <h2>Detalhes da Remessa</h2>
                            </div>
                            <div class="step-card-body">
                                <div class="form-group">
                                    <label>Puxar de Remessa Cadastrada (Peso/Volumes)</label>
                                    <div class="search-container">
                                        <i class='bx bx-package'></i>
                                        <input type="text" id="shipmentDataSearch" placeholder="Digite o ID da remessa ou nome do cliente...">
                                        <div id="shipment-search-results" class="search-results"></div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group"><label>Waybill (Rastreio)</label><input type="text" id="waybill" name="waybill" class="readonly-field" readonly></div>
                                    <div class="form-group">
                                        <label>Tipo de Conteúdo</label>
                                        <select id="content" name="content" required>
                                            <option value="">Selecione...</option>
                                            <option value="DOCUMENTO PESSOAL">DOCUMENTO PESSOAL</option>
                                            <option value="PRESENTE">PRESENTE</option>
                                            <option value="COURIER">COURIER</option>
                                            <option value="FORMAL">FORMAL</option>
                                            <option value="AMOSTRA">AMOSTRA</option>
                                            <option value="RETORNO PARA REPARO">RETORNO PARA REPARO</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group">
                                        <label>Motivo da Exportação</label>
                                        <select id="export_reason" name="export_reason">
                                            <option value="SALE">VENDA (COMMERCIAL SALE)</option>
                                            <option value="GIFT">PRESENTE (GIFT)</option>
                                            <option value="SAMPLE">AMOSTRA (COMMERCIAL SAMPLE)</option>
                                            <option value="REPAIR">RETORNO PARA REPARO (REPAIR/RETURN)</option>
                                            <option value="PERSONAL">USO PESSOAL (PERSONAL EFFECTS)</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Incoterms</label>
                                        <select id="incoterms" name="incoterms">
                                            <option value="DAP">DAP (Delivered at Place) - Padrão</option>
                                            <option value="DDP">DDP (Delivered Duty Paid)</option>
                                            <option value="CPT">CPT (Carriage Paid To)</option>
                                            <option value="FCA">FCA (Free Carrier)</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="volumes-section">
                                    <div class="vol-section-header">
                                        <h3>Embalagens / Volumes</h3>
                                        <button type="button" class="btn btn-secondary btn-sm" id="btn-add-volume">+ Adicionar Caixa</button>
                                    </div>
                                    <div id="volumes-header" class="volumes-header" style="display: none;">
                                        <div class="vol-col-idx">#</div>
                                        <div class="vol-col-qty">QTD</div>
                                        <div class="vol-col-dim">COMP</div>
                                        <div class="vol-col-dim">LARG</div>
                                        <div class="vol-col-dim">ALT</div>
                                        <div class="vol-col-weight">PESO</div>
                                        <div class="vol-col-actions"></div>
                                    </div>
                                    <div id="volumes-list" class="volumes-list">
                                        <!-- Vigorously Managed by JS -->
                                    </div>
                                    <div class="volumes-total-bar">
                                        <span>Volumes: <strong id="total-vols">0</strong></span>
                                        <span>Peso Total: <strong id="total-weight-display">0.0</strong> kg</span>
                                        <input type="hidden" id="weight" name="weight">
                                    </div>
                                </div>

                                <div class="step-actions" style="margin-top: 2rem; display: flex; justify-content: flex-end;">
                                    <button type="button" class="btn btn-primary btn-next-step" data-current="shipment" data-next="invoice">Revisar Invoice <i class='bx bx-right-arrow-alt'></i></button>
                                </div>
                            </div>
                        </div>
                    </section>

                    <!-- Section 4: Invoice Review -->
                    <section class="form-step-container" id="step-invoice" style="display:none; max-width: 1200px;">
                        <div class="step-card">
                            <div class="step-card-header">
                                <span class="step-number">04</span>
                                <h2>Revisão da Invoice Comercial</h2>
                            </div>
                            <div class="step-card-body">
                                <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 20px;">Esta é a invoice profissional que será gerada. Verifique os dados antes de finalizar o envio.</p>
                                
                                <div class="invoice-preview-container" style="background: #fff; padding: 20px; border-radius: 12px; overflow-x: auto;">
                                    <!-- The Invoice Template (Same as before but visible as a step) -->
                                    <div id="invoice-doc-step" class="invoice-step-doc" style="width: 1000px; margin: 0 auto; color: #000; background: #fff; padding: 40px; border: 1px solid #eee;">
                                        <div class="invoice-header">
                                            <div>
                                                <h1>COMMERCIAL INVOICE</h1>
                                                <p style="margin: 0; color: #666; font-size: 12px;">Exportação de Mercadorias / Export Documentation</p>
                                            </div>
                                            <div class="invoice-meta">
                                                <div>INVOICE #: <span id="inv_step_number">---</span></div>
                                                <div>DATE: <span id="inv_step_date">---</span></div>
                                                <div>AWB: <span id="inv_step_awb">---</span></div>
                                            </div>
                                        </div>

                                        <div class="invoice-grid">
                                            <div class="info-box">
                                                <h3>Exporter / Shipper</h3>
                                                <p><strong id="inv_step_shipper_name">---</strong></p>
                                                <p id="inv_step_shipper_addr">---</p>
                                                <p id="inv_step_shipper_country">---</p>
                                                <p>Phone: <span id="inv_step_shipper_tel">---</span></p>
                                                <p>Tax ID: <span id="inv_step_shipper_tax">---</span></p>
                                            </div>
                                            <div class="info-box">
                                                <h3>Consignee / Receiver</h3>
                                                <p><strong id="inv_step_receiver_name">---</strong></p>
                                                <p id="inv_step_receiver_addr">---</p>
                                                <p id="inv_step_receiver_country">---</p>
                                                <p>Phone: <span id="inv_step_receiver_tel">---</span></p>
                                                <p>Tax ID: <span id="inv_step_receiver_tax">---</span></p>
                                            </div>
                                        </div>

                                        <table class="invoice-table">
                                            <thead>
                                                <tr>
                                                    <th style="width: 50px;">Qty</th>
                                                    <th>Description of Goods</th>
                                                    <th style="width: 100px;">HS Code</th>
                                                    <th style="width: 80px;">Origin</th>
                                                    <th style="width: 100px;">Unit Value</th>
                                                    <th style="width: 120px;">Total Value</th>
                                                </tr>
                                            </thead>
                                            <tbody id="inv_step_items_body">
                                                <!-- Items Dynamically Filled -->
                                            </tbody>
                                        </table>

                                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 40px;">
                                            <div class="info-box">
                                                <h3>Shipment Details</h3>
                                                <p>Reason for Export: <span id="inv_step_reason">---</span></p>
                                                <p>Incoterms: <span id="inv_step_incoterms">---</span></p>
                                                <p>Total Weight: <span id="inv_step_total_weight">---</span></p>
                                                <p>Total Volumes: <span id="inv_step_total_vols">---</span></p>
                                            </div>
                                            <div class="invoice-totals">
                                                <table class="totals-table">
                                                    <tr>
                                                        <td>Subtotal Value:</td>
                                                        <td style="text-align: right;"><span id="inv_step_subtotal">---</span></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Shipping / Freight:</td>
                                                        <td style="text-align: right;">INCLUDED</td>
                                                    </tr>
                                                    <tr class="grand-total">
                                                        <td>TOTAL VALUE:</td>
                                                        <td style="text-align: right;"><span id="inv_step_total_grand">---</span></td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="step-actions" style="margin-top: 2rem; display: flex; gap: 1rem;">
                                    <button type="button" class="btn btn-secondary btn-edit-summary" data-step="shipment" style="flex: 1; justify-content: center;">Voltar e Ajustar</button>
                                    <button type="button" class="btn btn-success" id="btn-finalize-shipment" style="flex: 2; justify-content: center; font-weight: 700;">
                                        <i class='bx bx-check-double'></i> Finalizar e Gerar Envio Oficial
                                    </button>
                                </div>
                            </div>
                        </div>
                    </section>
                </form>
            </div>
            
            <!-- Tab 2: Shipment History -->
            <div id="tab-history" class="tab-content">
                <div class="form-header-top">
                    <div style="display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 1rem;">
                        <div>
                            <h1>Histórico de Envios</h1>
                            <p>Gerencie e acompanhe todas as etiquetas geradas.</p>
                        </div>
                        <div class="history-search-wrapper">
                            <i class='bx bx-search'></i>
                            <input type="text" id="historySearch" placeholder="Buscar por Waybill, Destinatário ou País...">
                        </div>
                    </div>
                </div>

                <div class="history-table-container">
                    <table class="modern-history-table">
                        <thead>
                            <tr>
                                <th>Waybill</th>
                                <th>Data</th>
                                <th>Destinatário</th>
                                <th>Destino</th>
                                <th style="text-align: center;">Status</th>
                                <th style="text-align: right;">Ações</th>
                            </tr>
                        </thead>
                        <tbody id="history-rows-container">
                            <tr>
                                <td colspan="6" style="text-align:center; padding: 5rem; color: #fff;">
                                    <h1 style="color: var(--accent);">TESTE DE VISIBILIDADE</h1>
                                    <p>Se você está vendo isso, o PHP e o HTML do histórico estão carregando.</p>
                                    <p style="color: var(--text-muted);">Vou agora reinserir o banco de dados passo a passo.</p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>

        <!-- Column 3: Right Summary List -->
        <aside class="sidebar-right">
            <div class="sidebar-title">
                <i class='bx bx-list-check'></i>
                <span>Resumo do Envio</span>
            </div>
            <div id="summary-list" class="summary-list">
                <div class="summary-card empty" id="summary-shipper-card">
                    <div class="summary-card-header">
                        <span><i class='bx bx-建物'></i> Remetente</span>
                    </div>
                    <div class="summary-card-body">Aguardando preenchimento...</div>
                </div>
                <div class="summary-card empty" id="summary-receiver-card">
                    <div class="summary-card-header">
                        <span><i class='bx bx-user'></i> Destinatário</span>
                    </div>
                    <div class="summary-card-body">Aguardando preenchimento...</div>
                </div>
                <div class="summary-card empty" id="summary-shipment-card">
                    <div class="summary-card-header">
                        <span><i class='bx bx-package'></i> Detalhes</span>
                    </div>
                    <div class="summary-card-body">Aguardando preenchimento...</div>
                </div>
            </div>
            <div class="sidebar-right-footer" style="padding-top: 2rem; border-top: 1px solid rgba(255,255,255,0.05); margin-top: auto;">
                <p style="font-size: 0.75rem; color: #666; text-align: center;">O Waybill será gerado permanentemente após a finalização.</p>
            </div>
        </aside>
    </div>

    <!-- Confirmation Modal -->
    <div id="preview-modal" class="modal-overlay" style="display: none;">
        <div class="modal-card">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; border-bottom: 1px solid var(--border); padding-bottom: 1rem;">
                <div>
                    <h2 style="color: #fff; font-size: 1.2rem; margin:0;">Revisar Documentação</h2>
                    <p style="color: #94a3b8; font-size: 0.9rem; margin:0;">Confirme os dados antes de gerar o PDF final.</p>
                </div>
                <div style="display: flex; gap: 0.5rem;" id="modal-tabs">
                    <button type="button" class="btn btn-secondary btn-sm active modal-tab-btn" onclick="switchModalDoc('label')" style="padding: 8px 16px; border-color: var(--accent); color: var(--accent);">1. Etiqueta</button>
                    <button type="button" class="btn btn-secondary btn-sm modal-tab-btn" onclick="switchModalDoc('invoice')" style="padding: 8px 16px;">2. Invoice</button>
                    <button type="button" class="btn btn-secondary btn-sm modal-tab-btn" onclick="switchModalDoc('receipt')" style="padding: 8px 16px;">3. Recibo</button>
                </div>
            </div>
            
            <div class="label-preview-wrapper" style="overflow-x: auto; background: rgba(0,0,0,0.5); border-radius: 12px; display: flex; flex-direction: column; align-items: center; gap: 40px; padding: 40px; min-height: 500px;">
                <!-- Actual Landscape A4 Label Container (2 Columns) -->
                <div id="dhl-label" class="landscape-a4-label" style="width: 1122px; height: 793px; background: #fff; color: #000; font-family: 'Arial Narrow', sans-serif; display: flex; box-sizing: border-box; border: 1px solid #000; margin: 0; padding: 0;">
                    
                    <!-- LEFT COLUMN: Shipping Label -->
                    <div id="dhl-left-col" style="width: 50%; border-right: 2px dashed #ccc; padding: 20px; box-sizing: border-box; display: flex; flex-direction: column;">
                        <div style="display: flex; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 10px;">
                            <div style="width: 70%; font-weight: 900; font-size: 20px;">EXPRESS WORLDWIDE <span style="border: 2px solid #000; padding: 0 8px;">DOX</span></div>
                            <div style="width: 30%; text-align: right; font-size: 32px; font-weight: 900; font-style: italic;">DHL</div>
                        </div>
                        
                        <div style="display: flex; border-bottom: 2px solid #000; margin-bottom: 10px;">
                            <div style="width: 70%; border-right: 2px solid #000; padding: 10px;">
                                <span style="font-size: 10px; font-weight: bold; display: block; text-transform: uppercase;">From:</span>
                                <div id="prev_r_nome" style="font-size: 13px; font-weight: 700;"></div>
                                <div id="prev_r_addr" style="font-size: 12px;"></div>
                                <div id="prev_r_city" style="font-size: 12px;"></div>
                                <div id="prev_r_country" style="font-size: 13px; font-weight: 700;"></div>
                                <div id="prev_r_tel" style="font-size: 12px; margin-top: 4px;"></div>
                            </div>
                            <div style="width: 30%; padding: 10px; text-align: center; display: flex; flex-direction: column; justify-content: center;">
                                <span style="font-size: 10px; font-weight: bold;">Origin:</span>
                                <div id="prev_origin" style="font-size: 36px; font-weight: 900;">GRU</div>
                            </div>
                        </div>

                        <div style="display: flex; border-bottom: 2px solid #000; margin-bottom: 10px;">
                            <div style="width: 70%; border-right: 2px solid #000; padding: 10px; min-height: 140px;">
                                <span style="font-size: 10px; font-weight: bold; display: block; text-transform: uppercase;">To:</span>
                                <div id="prev_d_nome" style="font-size: 18px; font-weight: 900; margin-bottom: 4px;"></div>
                                <div id="prev_d_addr" style="font-size: 14px;"></div>
                                <div id="prev_d_city" style="font-size: 14px;"></div>
                                <div id="prev_d_country" style="font-size: 18px; font-weight: 900; margin-top: 4px;"></div>
                                <div id="prev_d_tel" style="font-size: 12px; margin-top: 6px;"></div>
                            </div>
                            <div style="width: 30%; padding: 10px; text-align: center; display: flex; flex-direction: column; justify-content: center;">
                                <span style="font-size: 10px; font-weight: bold;">Ph:</span>
                                <div id="prev_d_ph" style="font-size: 14px; font-weight: 700;"></div>
                                <div id="prev_d_phone_label" style="font-size: 14px; font-weight: 700;"></div>
                            </div>
                        </div>

                        <div style="border-bottom: 2px solid #000; text-align: center; padding: 15px 0; margin-bottom: 10px;">
                            <div id="prev_dest_code" style="font-size: 32px; font-weight: 900; border: 5px solid #000; display: inline-block; padding: 5px 25px; letter-spacing: 1px;">CA-YHM-GTW</div>
                        </div>

                        <div style="display: flex; border-bottom: 2px solid #000; margin-bottom: 20px;">
                            <div style="width: 50%; border-right: 2px solid #000; padding: 10px;">
                                <span style="font-size: 10px; font-weight: bold;">Contents:</span>
                                <div id="prev_content" style="font-size: 13px; font-weight: 700;"></div>
                            </div>
                            <div style="width: 25%; border-right: 2px solid #000; padding: 10px; text-align: center;">
                                <span style="font-size: 10px; font-weight: bold;">Weight:</span>
                                <div id="prev_weight" style="font-size: 13px; font-weight: 700;"></div>
                            </div>
                            <div style="width: 25%; border-right: 2px solid #000; padding: 10px; text-align: center;">
                                <span style="font-size: 10px; font-weight: bold;">Dims:</span>
                                <div id="prev_dims" style="font-size: 11px; font-weight: 700;"></div>
                            </div>
                            <div style="width: 25%; padding: 10px; text-align: center;">
                                <span style="font-size: 10px; font-weight: bold;">Piece:</span>
                                <div id="prev_piece" style="font-size: 13px; font-weight: 700;">1 / 1</div>
                            </div>
                        </div>

                        <div style="flex: 1; display: flex; flex-direction: column; justify-content: center; align-items: center; padding: 20px 0;">
                            <canvas id="barcode-waybill" style="max-width: 450px; height: 100px;"></canvas>
                            <div id="prev_waybill_title" style="font-size: 16px; font-weight: 900; margin-top: 10px; letter-spacing: 2px;">WAYBILL 00 0000 0000</div>
                        </div>
                    </div>

                    <!-- RIGHT COLUMN: Terms and Conditions -->
                    <div id="dhl-right-col" style="width: 50%; padding: 30px; box-sizing: border-box; background: #fafafa; display: flex; flex-direction: column; font-family: 'Segoe UI', Arial, sans-serif;">
                        <h3 style="margin-top: 0; color: #d40511; border-bottom: 2px solid #d40511; padding-bottom: 5px; font-size: 18px;">TERMOS E CONDIÇÕES DE ENVIO</h3>
                        <div style="font-size: 11px; line-height: 1.6; color: #333; text-align: justify; overflow-y: auto;">
                            <p><strong>1. OBJETO E ACEITAÇÃO:</strong> Ao contratar os serviços da Exporta Fácil, o remetente declara estar de acordo com todos os termos e condições aqui estabelecidos. Este documento constitui o contrato de transporte entre as partes.</p>
                            
                            <p><strong>2. SEGURO E RESPONSABILIDADE:</strong> Todas as remessas estão sujeitas às regras internacionais de transporte. A Exporta Fácil oferece opções de seguro complementar que devem ser solicitadas no ato da postagem. Em caso de extravio ou dano sem seguro contratado, a indenização seguirá os limites estabelecidos pela convenção postal internacional.</p>
                            
                            <p><strong>3. FISCALIZAÇÃO E ALFÂNDEGA:</strong> O remetente é o único responsável pela veracidade das informações declaradas sobre o conteúdo. Toda remessa internacional está sujeita a fiscalização pelos órgãos anuentes (Receita Federal, ANVISA, VIGIAGRO, etc.) e autoridades alfandegárias do país de destino. <strong>Atenção:</strong> Remessas com conteúdo proibido ou subfaturado podem ser apreendidas ou multadas.</p>
                            
                            <p><strong>4. TAXAS E IMPOSTOS:</strong> Taxas de importação, impostos governamentais e despesas de despacho no destino são de inteira responsabilidade do destinatário, salvo indicação contrária prévia. Caso o destinatário se recuse a pagar, os custos serão repassados ao remetente.</p>
                            
                            <p><strong>5. ITENS PROIBIDOS:</strong> Não serão aceitos materiais inflamáveis, explosivos, corrosivos, gases sob pressão, valores em espécie, joias de alto valor ou quaisquer itens que infrinjam as normas de segurança da aviação civil ou leis locais.</p>
                            
                            <p><strong>6. CANCELAMENTOS E DEVOLUÇÕES:</strong> Remessas devolvidas por endereço incorreto ou ausência do destinatário gerarão custos adicionais de frete de retorno que deverão ser quitados pelo remetente.</p>

                            <div style="margin-top: 30px; padding: 15px; border: 1px dashed #666; background: #fff; font-size: 10px;">
                                <p style="margin: 0; text-align: center;"><strong>DECLARAÇÃO DO REMETENTE</strong></p>
                                <p style="margin-bottom: 30px;">Confirmo que esta remessa não contém itens perigosos ou proibidos e que as informações de peso e conteúdo são verdadeiras.</p>
                                <div style="border-top: 1px solid #000; width: 80%; margin: 0 auto; text-align: center; padding-top: 5px;">Assinatura do Responsável</div>
                            </div>
                            
                            <div style="margin-top: auto; text-align: center; color: #999; font-size: 9px;">
                                Exporta Fácil - Soluções Logísticas Internacionais<br>
                                Gerado em: <?php echo date('d/m/Y H:i'); ?>
                            </div>
                        </div>
                    </div>

                    <!-- COMMERCIAL INVOICE TEMPLATE -->
                    <div id="invoice-doc" class="document-page" style="margin-top: 20px;">
                        <div class="invoice-header">
                            <div>
                                <h1>COMMERCIAL INVOICE</h1>
                                <p style="margin: 0; color: #666; font-size: 12px;">Exportação de Mercadorias / Export Documentation</p>
                            </div>
                            <div class="invoice-meta">
                                <div>INVOICE #: <span id="inv_number">---</span></div>
                                <div>DATE: <span id="inv_date">---</span></div>
                                <div>AWB: <span id="inv_awb">---</span></div>
                            </div>
                        </div>

                        <div class="invoice-grid">
                            <div class="info-box">
                                <h3>Exporter / Shipper</h3>
                                <p><strong id="inv_shipper_name">---</strong></p>
                                <p id="inv_shipper_addr">---</p>
                                <p id="inv_shipper_country">---</p>
                                <p>Phone: <span id="inv_shipper_tel">---</span></p>
                                <p>Tax ID: <span id="inv_shipper_tax">---</span></p>
                            </div>
                            <div class="info-box">
                                <h3>Consignee / Receiver</h3>
                                <p><strong id="inv_receiver_name">---</strong></p>
                                <p id="inv_receiver_addr">---</p>
                                <p id="inv_receiver_country">---</p>
                                <p>Phone: <span id="inv_receiver_tel">---</span></p>
                                <p>Tax ID: <span id="inv_receiver_tax">---</span></p>
                            </div>
                        </div>

                        <table class="invoice-table">
                            <thead>
                                <tr>
                                    <th style="width: 50px;">Qty</th>
                                    <th>Description of Goods</th>
                                    <th style="width: 100px;">HS Code</th>
                                    <th style="width: 80px;">Origin</th>
                                    <th style="width: 100px;">Unit Value</th>
                                    <th style="width: 120px;">Total Value</th>
                                </tr>
                            </thead>
                            <tbody id="inv_items_body">
                                <!-- Items will be injected here -->
                            </tbody>
                        </table>

                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 40px;">
                            <div class="info-box">
                                <h3>Shipment Details</h3>
                                <p>Reason for Export: <span id="inv_reason">SALE / GIFT</span></p>
                                <p>Incoterms: <span id="inv_incoterms">DAP (Delivered at Place)</span></p>
                                <p>Total Weight: <span id="inv_total_weight">---</span></p>
                                <p>Total Volumes: <span id="inv_total_vols">---</span></p>
                            </div>
                            <div class="invoice-totals">
                                <table class="totals-table">
                                    <tr>
                                        <td>Subtotal Value:</td>
                                        <td style="text-align: right;"><span id="inv_subtotal">---</span></td>
                                    </tr>
                                    <tr>
                                        <td>Shipping / Freight:</td>
                                        <td style="text-align: right;">INCLUDED</td>
                                    </tr>
                                    <tr class="grand-total">
                                        <td>TOTAL VALUE:</td>
                                        <td style="text-align: right;"><span id="inv_total_grand">---</span></td>
                                    </tr>
                                </table>
                            </div>
                        </div>

                        <div class="invoice-footer">
                            <div>
                                <p>I declare that all the information mentioned above is true and correct to the best of my knowledge.</p>
                                <div style="margin-top: 20px; border-top: 1px solid #000; width: 250px; padding-top: 5px; text-align: center;">Authorized Signature</div>
                            </div>
                            <div style="text-align: right;">
                                Generated by Exporta Fácil System
                            </div>
                        </div>
                    </div>

                    <!-- CLIENT RECEIPT TEMPLATE -->
                    <div id="receipt-doc" class="document-page" style="margin-top: 20px;">
                        <div class="receipt-brand">
                            <i class='bx bxs-check-circle'></i>
                            <div>
                                <div class="name">Exporta Fácil</div>
                                <div style="font-size: 12px; color: #64748b;">Comprovante de Envio Internacional</div>
                            </div>
                        </div>

                        <div class="receipt-main">
                            <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 1px solid #e2e8f0; padding-bottom: 20px;">
                                <div>
                                    <h2 style="margin: 0; font-size: 20px;">Resumo do Envio</h2>
                                    <span class="receipt-status-badge">Pagamento Confirmado</span>
                                </div>
                                <div style="text-align: right;">
                                    <div style="font-size: 12px; color: #64748b;">Waybill / Rastreio</div>
                                    <div style="font-size: 24px; font-weight: 800; color: #6366f1;" id="rec_waybill">---</div>
                                </div>
                            </div>

                            <div class="receipt-grid">
                                <div class="receipt-item">
                                    <label>Destinatário</label>
                                    <span id="rec_receiver">---</span>
                                </div>
                                <div class="receipt-item">
                                    <label>País de Destino</label>
                                    <span id="rec_country">---</span>
                                </div>
                                <div class="receipt-item">
                                    <label>Data do Envio</label>
                                    <span id="rec_date">---</span>
                                </div>
                                <div class="receipt-item">
                                    <label>Volumes / Conteúdo</label>
                                    <span id="rec_details">---</span>
                                </div>
                                <div class="receipt-item">
                                    <label>Peso Total</label>
                                    <span id="rec_weight">---</span>
                                </div>
                                <div class="receipt-item">
                                    <label>Valor do Frete</label>
                                    <span id="rec_freight">---</span>
                                </div>
                            </div>
                        </div>

                        <div style="margin-top: 40px; display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
                            <div class="info-box">
                                <h3>Informações de Pagamento</h3>
                                <p>Método de Pagamento: <span id="rec_pay_method">---</span></p>
                                <p>Status: <strong style="color: #10b981;">CONCLUÍDO</strong></p>
                            </div>
                            <div class="info-box">
                                <h3>Suporte e Rastreio</h3>
                                <p>Para rastrear seu objeto, utilize o código acima no site da nossa transportadora parceira ou em nosso portal oficial.</p>
                            </div>
                        </div>

                        <div class="receipt-footer-terms">
                            <p><strong>Atenção:</strong> Prazos de entrega são estimados e dependem da liberação alfandegária no país de destino. Impostos de importação são de responsabilidade do destinatário, salvo acordos prévios. Em caso de dúvidas, entre em contato através do nosso WhatsApp oficial ou e-mail de suporte.</p>
                        </div>

                        <div style="position: absolute; bottom: 40px; left: 40px; right: 40px; text-align: center; font-size: 10px; color: #94a3b8;">
                            Exporta Fácil - Logística Internacional & Global Shipping Solutions
                        </div>
                    </div>

                </div>
            </div>

            <div style="display: flex; gap: 1rem; width: 100%; margin-top: 1rem;">
                <button type="button" class="btn btn-success" id="btn-final-save" style="flex: 2; justify-content: center;">Confirmar e Salvar PDF</button>
                <button type="button" class="btn btn-secondary" id="btn-cancel-review" style="flex: 1; justify-content: center;">Voltar</button>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="assets/js/shipment_label.js?v=<?php echo time(); ?>"></script>
</body>
</html>
