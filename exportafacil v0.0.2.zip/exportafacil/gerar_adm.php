<?php
// Configurações de conexão (ajuste se necessário)
$host = 'localhost'; // Usually localhost on Hostinger
$db   = 'u800760756_exportafacil';
$user = 'u800760756_AgzEF';
$pass = '1;KkMR:WIf';
$charset = 'utf8mb4';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    
    $name = 'Administrador';
    $username = 'ADM';
    $password = 'adm123';
    $role = 'admin';
    $status = 'approved';

    // Aqui o PHP gera o hash EXATO que o seu sistema entende
    $hash = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (name, username, password, role, status) VALUES (?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$name, $username, $hash, $role, $status]);

    echo "Usuário ADM criado com sucesso!";
} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage();
}
?>