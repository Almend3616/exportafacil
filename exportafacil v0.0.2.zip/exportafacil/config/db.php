<?php
// Configuration for Exporta Fácil Database
$host = 'localhost'; // Usually localhost on Hostinger
$db   = 'u800760756_exportafacil';
$user = 'u800760756_AgzEF';
$pass = '1;KkMR:WIf';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
     $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
     // Check if we are in an API call to return JSON instead of plain death
     $isApi = (strpos($_SERVER['REQUEST_URI'], '/api/') !== false) || (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false);
     if ($isApi) {
         header('Content-Type: application/json');
         echo json_encode(['success' => false, 'message' => 'Erro de Conexão DB: ' . $e->getMessage()]);
         exit;
     }
     die("Erro crítico de banco de dados: " . $e->getMessage());
}
?>
