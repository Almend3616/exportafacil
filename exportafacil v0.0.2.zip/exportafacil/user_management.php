<?php
require_once 'includes/auth.php';
require_once 'config/db.php';
checkAdmin();

$message = "";

// Handle Actions
if (isset($_GET['action'], $_GET['id'])) {
    $action = $_GET['action'];
    $id = (int)$_GET['id'];

    if ($action === 'approve') {
        $stmt = $pdo->prepare("UPDATE users SET status = 'approved' WHERE id = ?");
        $stmt->execute([$id]);
        $message = "Usuário aprovado com sucesso!";
    } elseif ($action === 'delete') {
        if ($id != $_SESSION['user_id']) {
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$id]);
            $message = "Usuário removido do sistema!";
        }
    } elseif ($action === 'reset' && isset($_POST['new_password'])) {
        $newPass = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->execute([$newPass, $id]);
        $message = "Senha redefinida com sucesso!";
    }
    
    if ($action !== 'reset') {
        header("Location: user_management.php?msg=" . urlencode($message));
        exit;
    }
}

$msg = $_GET['msg'] ?? "";

// Fetch All Users
$stmt = $pdo->query("SELECT id, name, username, role, status, created_at FROM users ORDER BY role ASC, status ASC, created_at DESC");
$users = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciador de Usuários | Exporta Fácil</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/boxicons/css/boxicons.min.css" rel="stylesheet">
    <style>
        :root { 
            --primary: #6366f1; 
            --primary-hover: #4f46e5;
            --danger: #ef4444; 
            --success: #22c55e; 
            --warning: #f59e0b;
            --bg: #0a0a0c; 
            --card: #111116; 
            --text: #e2e8f0;
            --text-muted: #94a3b8;
        }
        
        body { 
            background-color: var(--bg); 
            color: var(--text); 
            font-family: 'Poppins', sans-serif; 
            padding: 2rem; 
            margin: 0;
            line-height: 1.6;
        }

        .container { 
            max-width: 1100px; 
            margin: 0 auto; 
            animation: fadeIn 0.5s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .header { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            margin-bottom: 2.5rem; 
            padding-bottom: 1.5rem; 
            border-bottom: 1px solid rgba(255, 255, 255, 0.1); 
        }

        .header h1 {
            font-size: 1.8rem;
            font-weight: 700;
            margin: 0;
            background: linear-gradient(135deg, #6366f1 0%, #a855f7 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .btn-back { 
            color: var(--text-muted); 
            text-decoration: none; 
            display: flex; 
            align-items: center; 
            gap: 8px; 
            transition: color 0.3s;
            font-weight: 500;
        }
        
        .btn-back:hover { color: var(--primary); }
        
        .alert { 
            background: rgba(34, 197, 94, 0.1); 
            color: var(--success); 
            padding: 1rem 1.5rem; 
            border-radius: 12px; 
            margin-bottom: 2rem; 
            border: 1px solid rgba(34, 197, 94, 0.2); 
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .table-wrapper {
            background: var(--card);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.05);
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 1.25rem 1.5rem; text-align: left; border-bottom: 1px solid rgba(255, 255, 255, 0.05); }
        th { background: rgba(255, 255, 255, 0.02); color: var(--text-muted); font-size: 0.8rem; text-transform: uppercase; letter-spacing: 1.5px; font-weight: 600; }
        
        .user-info { display: flex; align-items: center; gap: 12px; }
        .user-avatar { width: 40px; height: 40px; border-radius: 50%; background: rgba(99, 102, 241, 0.1); display: flex; align-items: center; justify-content: center; color: var(--primary); font-size: 1.2rem; }
        
        .status-pill { 
            padding: 4px 12px; 
            border-radius: 20px; 
            font-size: 0.75rem; 
            font-weight: 600; 
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .status-pending { background: rgba(245, 158, 11, 0.1); color: var(--warning); border: 1px solid rgba(245, 158, 11, 0.2); }
        .status-approved { background: rgba(34, 197, 94, 0.1); color: var(--success); border: 1px solid rgba(34, 197, 94, 0.2); }
        
        .role-badge { 
            font-size: 0.7rem; 
            padding: 2px 8px; 
            border-radius: 6px; 
            background: rgba(99, 102, 241, 0.1); 
            color: var(--primary); 
            font-weight: 600;
        }

        .role-admin { background: rgba(168, 85, 247, 0.1); color: #a855f7; }

        .actions { display: flex; gap: 10px; }
        .btn-action { 
            width: 36px; 
            height: 36px; 
            border-radius: 10px; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            border: none; 
            background: rgba(255,255,255,0.03); 
            color: var(--text-muted); 
            cursor: pointer; 
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            text-decoration: none;
        }
        .btn-action:hover { transform: translateY(-2px); }
        .btn-approve:hover { background: var(--success); color: #fff; box-shadow: 0 4px 12px rgba(34, 197, 148, 0.3); }
        .btn-reset:hover { background: var(--primary); color: #fff; box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3); }
        .btn-delete:hover { background: var(--danger); color: #fff; box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3); }

        /* Modal Redesign */
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.85); backdrop-filter: blur(5px); z-index: 1000; align-items: center; justify-content: center; }
        .modal-content { 
            background: var(--card); 
            padding: 2.5rem; 
            border-radius: 24px; 
            width: 100%;
            max-width: 400px; 
            border: 1px solid rgba(255,255,255,0.1); 
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        }
        .modal-content h3 { margin: 0 0 0.5rem 0; font-size: 1.4rem; }
        .modal-content p { color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1.5rem; }
        
        .form-group { margin-bottom: 1.5rem; position: relative; }
        .form-group i { position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: var(--text-muted); }
        .modal input { 
            width: 100%; 
            padding: 12px 15px 12px 45px; 
            background: rgba(0,0,0,0.2); 
            border: 1px solid rgba(255,255,255,0.1); 
            border-radius: 12px; 
            color: #fff; 
            box-sizing: border-box; 
            outline: none;
            transition: border-color 0.3s;
        }
        .modal input:focus { border-color: var(--primary); }
        
        .modal-btns { display: flex; gap: 12px; }
        .btn-save { background: var(--primary); color: #fff; border: none; padding: 12px; border-radius: 12px; flex: 2; cursor: pointer; font-weight: 600; transition: background 0.3s; }
        .btn-save:hover { background: var(--primary-hover); }
        .btn-cancel { background: rgba(255,255,255,0.05); color: #fff; border: 1px solid rgba(255,255,255,0.1); padding: 12px; border-radius: 12px; flex: 1; cursor: pointer; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div>
                <h1>Gerenciador de Usuários</h1>
                <p style="color: var(--text-muted); margin: 5px 0 0 0;">Aprove e gerencie o acesso à plataforma.</p>
            </div>
            <a href="index.php" class="btn-back"><i class='bx bx-arrow-back'></i> Painel Principal</a>
        </div>

        <?php if ($msg): ?>
            <div class="alert">
                <i class='bx bxs-check-circle'></i>
                <?php echo htmlspecialchars($msg); ?>
            </div>
        <?php endif; ?>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Usuário</th>
                        <th>Cargo</th>
                        <th>Status</th>
                        <th>Criado em</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                    <tr>
                        <td>
                            <div class="user-info">
                                <div class="user-avatar">
                                    <i class='bx bxs-user'></i>
                                </div>
                                <div>
                                    <div style="font-weight: 600;"><?php echo htmlspecialchars($user['name']); ?></div>
                                    <div style="color: var(--text-muted); font-size: 0.8rem;">@<?php echo htmlspecialchars($user['username']); ?></div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="role-badge <?php echo $user['role'] == 'admin' ? 'role-admin' : ''; ?>">
                                <?php echo $user['role'] == 'admin' ? 'Administrador' : 'Funcionário'; ?>
                            </span>
                        </td>
                        <td>
                            <span class="status-pill status-<?php echo $user['status']; ?>">
                                <i class='bx bx-<?php echo $user['status'] == 'pending' ? 'time-five' : 'check-double'; ?>'></i>
                                <?php echo $user['status'] == 'pending' ? 'Pendente' : 'Ativo'; ?>
                            </span>
                        </td>
                        <td style="color: var(--text-muted); font-size: 0.85rem;">
                            <?php echo date('d/m/Y', strtotime($user['created_at'])); ?>
                        </td>
                        <td class="actions">
                            <?php if ($user['status'] == 'pending'): ?>
                                <a href="user_management.php?action=approve&id=<?php echo $user['id']; ?>" class="btn-action btn-approve" title="Aprovar Usuário">
                                    <i class='bx bx-check'></i>
                                </a>
                            <?php endif; ?>
                            
                            <button class="btn-action btn-reset" onclick="openReset(<?php echo $user['id']; ?>, '<?php echo $user['username']; ?>')" title="Alterar Senha">
                                <i class='bx bx-key'></i>
                            </button>

                            <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                <a href="user_management.php?action=delete&id=<?php echo $user['id']; ?>" class="btn-action btn-delete" title="Excluir Usuário" onclick="return confirm('Excluir permanentemente @<?php echo $user['username']; ?>?')">
                                    <i class='bx bx-trash'></i>
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Password Reset Modal -->
    <div id="resetModal" class="modal">
        <div class="modal-content">
            <h3>Redefinir Senha</h3>
            <p id="resetUserText"></p>
            <form id="resetForm" method="POST">
                <div class="form-group">
                    <i class='bx bxs-lock-open'></i>
                    <input type="password" name="new_password" placeholder="Nova Senha" required minlength="4">
                </div>
                <div class="modal-btns">
                    <button type="submit" class="btn-save">Salvar Senha</button>
                    <button type="button" class="btn-cancel" onclick="closeReset()">Sair</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openReset(id, username) {
            document.getElementById('resetModal').style.display = 'flex';
            document.getElementById('resetUserText').innerText = 'Defina uma nova senha para @' + username;
            document.getElementById('resetForm').action = 'user_management.php?action=reset&id=' + id;
        }
        function closeReset() {
            document.getElementById('resetModal').style.display = 'none';
        }
        window.onclick = function(event) {
            if (event.target == document.getElementById('resetModal')) closeReset();
        }
    </script>
</body>
</html>
