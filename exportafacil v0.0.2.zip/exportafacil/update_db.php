<?php
require_once 'config/db.php';

try {
    $sqlCustomers = "CREATE TABLE IF NOT EXISTS customers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        document VARCHAR(50),
        phone VARCHAR(50),
        email VARCHAR(255),
        address_line1 VARCHAR(255),
        address_line2 VARCHAR(255),
        address_line3 VARCHAR(255),
        zip_code VARCHAR(20),
        city VARCHAR(100),
        state VARCHAR(100),
        country VARCHAR(100),
        observations TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

    $sqlShipments = "CREATE TABLE IF NOT EXISTS shipments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        quote_id INT NULL,
        sender_id INT,
        recipient_id INT,
        status VARCHAR(100) DEFAULT 'Aguardando',
        delivery_person VARCHAR(255),
        shipment_photo VARCHAR(255),
        responsible_salesperson VARCHAR(100),
        shipment_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        received_by VARCHAR(100),
        quantity INT,
        dimensions VARCHAR(100), -- Format: AxLxC
        weight DECIMAL(10, 2),
        destination_country VARCHAR(100),
        freight_value DECIMAL(10, 2),
        payment_status ENUM('Aguardando Pagamento', 'Pago, aguardando confirmação', 'Pagamento confirmado', 'Faturado') DEFAULT 'Aguardando Pagamento',
        payment_type ENUM('PIX', 'Credito', 'Debito', 'Boleto', 'Faturado', 'Link', 'Pagamento internacional'),
        responsible_name VARCHAR(255),
        responsible_phone VARCHAR(50),
        description TEXT,
        declared_value DECIMAL(10, 2),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (quote_id) REFERENCES quotes(id) ON DELETE SET NULL,
        FOREIGN KEY (sender_id) REFERENCES customers(id) ON DELETE SET NULL,
        FOREIGN KEY (recipient_id) REFERENCES customers(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

    $pdo->exec($sqlCustomers);
    echo "Tabela 'customers' criada ou já existe.<br>";
    
    $pdo->exec($sqlShipments);
    echo "Tabela 'shipments' criada ou já existe.<br>";

    // Adicionar colunas para entrada manual se não existirem
    $manualColumns = [
        "sender_name" => "VARCHAR(255)",
        "sender_phone" => "VARCHAR(50)",
        "recipient_name" => "VARCHAR(255)",
        "recipient_phone" => "VARCHAR(50)",
        "responsible_name" => "VARCHAR(255)",
        "responsible_phone" => "VARCHAR(50)",
        "description" => "TEXT",
        "declared_value" => "DECIMAL(10, 2)"
    ];

    foreach ($manualColumns as $col => $type) {
        try {
            $pdo->exec("ALTER TABLE shipments ADD COLUMN $col $type");
            echo "Coluna '$col' adicionada.<br>";
        } catch (PDOException $e) {
            echo "Nota: Coluna '$col' já existe ou erro.<br>";
        }
    }

    // Add options column to quotes if not exists
    try {
        $pdo->exec("ALTER TABLE quotes ADD COLUMN freight_options TEXT NULL");
        echo "Coluna 'freight_options' adicionada à tabela 'quotes'.<br>";
    } catch (PDOException $e) {
        echo "Nota: Coluna 'freight_options' já existe ou erro.<br>";
    }

    // Alter shipments status column to accommodate custom statuses
    try {
        $pdo->exec("ALTER TABLE shipments MODIFY COLUMN status VARCHAR(100) DEFAULT 'Aguardando'");
        echo "Coluna 'status' em 'shipments' modificada para VARCHAR(100).<br>";
    } catch (PDOException $e) {
        echo "Nota: Erro ao modificar 'status': " . $e->getMessage() . "<br>";
    }

    // Phase 6: Shipment Notes
    $sqlNotes = "CREATE TABLE IF NOT EXISTS shipment_notes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        shipment_id INT NOT NULL,
        user_name VARCHAR(255) NULL,
        note TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (shipment_id) REFERENCES shipments(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
    
    $pdo->exec($sqlNotes);
    echo "Tabela 'shipment_notes' criada ou já existe.<br>";

    // Ensure user_name exists if table was already there
    try {
        $pdo->exec("ALTER TABLE shipment_notes ADD COLUMN user_name VARCHAR(255) NULL AFTER shipment_id");
        echo "Coluna 'user_name' adicionada à 'shipment_notes'.<br>";
    } catch (PDOException $e) {
        // Column likely exists
    }

    // Phase 6: Shipment Files
    $sqlFiles = "CREATE TABLE IF NOT EXISTS shipment_files (
        id INT AUTO_INCREMENT PRIMARY KEY,
        shipment_id INT NOT NULL,
        note_id INT NULL,
        file_path VARCHAR(255) NOT NULL,
        file_name VARCHAR(255) NOT NULL,
        file_type VARCHAR(50),
        uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (shipment_id) REFERENCES shipments(id) ON DELETE CASCADE,
        FOREIGN KEY (note_id) REFERENCES shipment_notes(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

    $pdo->exec($sqlFiles);
    echo "Tabela 'shipment_files' criada ou já existe.<br>";

    try {
        $pdo->exec("ALTER TABLE shipment_files ADD COLUMN note_id INT NULL AFTER shipment_id");
        $pdo->exec("ALTER TABLE shipment_files ADD CONSTRAINT fk_note FOREIGN KEY (note_id) REFERENCES shipment_notes(id) ON DELETE SET NULL");
        echo "Coluna 'note_id' vinculada a 'shipment_files'.<br>";
    } catch (PDOException $e) {
        // Exists
    }

} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage();
}
?>
