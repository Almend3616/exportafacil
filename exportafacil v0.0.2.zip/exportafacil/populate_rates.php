<?php
require_once 'config/db.php';
require_once 'includes/auth.php';
checkAdmin();

echo "<h2>Povoando Tabela de Preços...</h2>";

try {
    // Buscar todos os métodos de todas as transportadoras
    $methods = $pdo->query("SELECT sm.id, sm.name, c.name as carrier_name FROM shipping_methods sm JOIN carriers c ON sm.carrier_id = c.id")->fetchAll();

    if (empty($methods)) {
        die("<p style='color: red;'>Nenhum método de envio encontrado. Cadastre as transportadoras primeiro!</p>");
    }

    $pdo->beginTransaction();

    foreach ($methods as $m) {
        echo "Limpando e gerando preços para: <b>{$m['carrier_name']} - {$m['name']}</b><br>";

        // Limpa preços existentes para este método
        $stmtDel = $pdo->prepare("DELETE FROM shipping_rates WHERE method_id = ?");
        $stmtDel->execute([$m['id']]);

        $currentPrice = rand(80, 150); // Preço inicial aleatório para 0.5kg

        // Inserir 0.5kg
        $stmtIns = $pdo->prepare("INSERT INTO shipping_rates (method_id, weight_up_to, price) VALUES (?, ?, ?)");
        $stmtIns->execute([$m['id'], 0.5, $currentPrice]);

        // Gerar de 1kg até 50kg
        for ($w = 1; $w <= 50; $w++) {
            $increment = rand(10, 30); // Incremento aleatório por kg
            $currentPrice += $increment;

            $stmtIns->execute([$m['id'], $w, $currentPrice]);
        }
        echo "✅ " . ($w + 1) . " faixas de peso geradas.<br><br>";
    }

    $pdo->commit();
    echo "<h3 style='color: green;'>Sucesso! Todos os preços foram gerados até 50kg.</h3>";
    echo "<p><a href='index.php'>Voltar ao Dashboard</a></p>";

}
catch (Exception $e) {
    if ($pdo->inTransaction())
        $pdo->rollBack();
    echo "<p style='color: red;'>Erro: " . $e->getMessage() . "</p>";
}
?>
