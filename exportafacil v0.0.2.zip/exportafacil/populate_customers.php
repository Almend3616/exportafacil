<?php
require_once 'config/db.php';

echo "<h2>Populating Customers for Testing...</h2>";

$brazilian_names = ["João Silva", "Maria Oliveira", "Pedro Santos", "Ana Souza", "Lucas Pereira", "Julia Ferreira", "Gabriel Rodrigues", "Beatriz Costa", "Mateus Almeida", "Larissa Carvalho"];
$international_names = ["John Smith", "Emma Wilson", "Hans Müller", "Chen Wei", "Giuseppe Rossi", "Marie Dubois", "Yuki Tanaka", "Ahmed Hassan", "Elena Petrov", "Carlos Hernandez"];

$countries = ["Estados Unidos", "China", "Portugal", "Espanha", "Itália", "França", "Canadá", "México", "Alemanha", "Japão", "Reino Unido", "Austrália"];

$goiania_addresses = [
    ["address" => "Av. Jamel Cecílio, 3300", "zip" => "74810-907", "city" => "Goiânia", "state" => "GO", "country" => "Brasil", "obs" => "Próximo ao Flamboyant Shopping"],
    ["address" => "Praça Cívica, s/n", "zip" => "74003-010", "city" => "Goiânia", "state" => "GO", "country" => "Brasil", "obs" => "Centro Histórico"],
    ["address" => "Av. T-63, 1200", "zip" => "74230-100", "city" => "Goiânia", "state" => "GO", "country" => "Brasil", "obs" => "Setor Bueno"],
    ["address" => "Av. 85, 2500", "zip" => "74160-010", "city" => "Goiânia", "state" => "GO", "country" => "Brasil", "obs" => "Setor Marista"],
    ["address" => "Rua 4, 515", "zip" => "74020-060", "city" => "Goiânia", "state" => "GO", "country" => "Brasil", "obs" => "Próximo ao Parthenon Center"]
];

$international_cities = [
    ["city" => "Miami", "state" => "FL", "country" => "Estados Unidos"],
    ["city" => "New York", "state" => "NY", "country" => "Estados Unidos"],
    ["city" => "Lisboa", "state" => "Lisboa", "country" => "Portugal"],
    ["city" => "Madrid", "state" => "Madrid", "country" => "Espanha"],
    ["city" => "Paris", "state" => "Île-de-France", "country" => "França"],
    ["city" => "London", "state" => "Greater London", "country" => "Reino Unido"],
    ["city" => "Shanghai", "state" => "Shanghai", "country" => "China"]
];

try {
    $stmt = $pdo->prepare("INSERT INTO customers (name, document, phone, email, address_line1, zip_code, city, state, country, observations) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $count = 0;

    // Generate 15 Goiânia customers
    for ($i = 0; $i < 15; $i++) {
        $name = $brazilian_names[array_rand($brazilian_names)] . " " . chr(rand(65, 90));
        $doc = rand(100, 999) . "." . rand(100, 999) . "." . rand(100, 999) . "-" . rand(10, 99);
        $phone = "+55 (62) 9" . rand(8000, 9999) . "-" . rand(1000, 9999);
        $email = strtolower(str_replace(' ', '.', $name)) . "@exemplo.com.br";
        
        $addr = $goiania_addresses[array_rand($goiania_addresses)];
        
        $stmt->execute([$name, $doc, $phone, $email, $addr['address'], $addr['zip'], $addr['city'], $addr['state'], $addr['country'], $addr['obs']]);
        $count++;
    }

    // Generate 15 International customers
    for ($i = 0; $i < 15; $i++) {
        $name = $international_names[array_rand($international_names)] . " " . chr(rand(65, 90));
        $doc = "ID-" . rand(100000, 999999);
        $phone = "+" . rand(1, 99) . " " . rand(100, 999) . "-" . rand(1000, 9999);
        $email = strtolower(str_replace(' ', '.', $name)) . "@testmail.com";
        
        $city_data = $international_cities[array_rand($international_cities)];
        $addr_line = rand(100, 9999) . " Main St";
        $zip = rand(10000, 99999);
        
        $stmt->execute([$name, $doc, $phone, $email, $addr_line, $zip, $city_data['city'], $city_data['state'], $city_data['country'], "International Test Customer"]);
        $count++;
    }

    echo "<h3 style='color: green;'>Successfully added $count customers!</h3>";
    echo "<p><a href='customers.php'>Voltar para Clientes</a></p>";

} catch (Exception $e) {
    echo "<h3 style='color: red;'>Error: " . $e->getMessage() . "</h3>";
}
?>
